/**
 * Permission system using proto-generated enums.
 * This file re-exports the proto enums and provides helper functions
 * for permission checking in the frontend.
 */
export { OrganizationPermissionOperation, SitePermissionOperation } from "./generated/permission";
import { OrganizationPermissionOperation, SitePermissionOperation } from "./generated/permission";
import { UserType } from "./generated/user";
import { OrganizationRole, OrganizationType, OrganizationWithUserRole } from "./generated/organization";
import { GoCommonConfig } from "./config/types";
export declare const OrgPermission: typeof OrganizationPermissionOperation;
export declare const SitePermission: typeof SitePermissionOperation;
/**
 * Organization-type capabilities enforced by backend org-type thresholds.
 */
export declare enum OrganizationTypeCapability {
    LIST_MEMBERS = "list_members",
    INVITE_MEMBERS = "invite_members",
    ADD_MEMBERS = "add_members",
    REMOVE_MEMBERS = "remove_members",
    UPDATE_MEMBER_ROLES = "update_member_roles",
    VIEW_INVITATIONS = "view_invitations",
    CANCEL_INVITATION = "cancel_invitation",
    MANAGE_EMAIL_DOMAINS = "manage_email_domains",
    WORKSPACE_NAVIGATION = "workspace_navigation",
    CREATE_CHILD_ORGANIZATIONS = "create_child_organizations",
    BULK_MEMBER_MANAGEMENT = "bulk_member_management"
}
/**
 * Backend normalizes unspecified organization types to BUSINESS_TIER_0.
 */
export declare function normalizeOrganizationType(organizationType?: OrganizationType): OrganizationType;
/**
 * Get the org-type threshold required for a capability.
 */
export declare function getRequiredOrganizationType(config: GoCommonConfig, capability: OrganizationTypeCapability): OrganizationType;
/**
 * Check whether an organization type allows the given capability.
 */
export declare function hasOrganizationTypeCapability(config: GoCommonConfig, organizationType: OrganizationType | undefined, capability: OrganizationTypeCapability): boolean;
/**
 * Get the required UserType threshold for an organization operation. Organization-role-only
 * operations (the inference policy operations) have no user-type threshold and return
 * USER_TYPE_UNSPECIFIED; `hasOrgPermission` never grants them by user type.
 */
export declare function getRequiredUserType(config: GoCommonConfig, operation: OrganizationPermissionOperation): UserType;
/**
 * Get the required OrganizationRole threshold for an operation at a given depth.
 */
export declare function getRequiredOrgRole(config: GoCommonConfig, operation: OrganizationPermissionOperation, depth?: number): OrganizationRole;
/**
 * Check if a user has permission for an organization operation.
 * Uses two-tier check: global UserType first, then OrganizationRole. Organization-role-only
 * operations skip the UserType tier, so they require a role in the organization.
 *
 * @param config - GoCommon configuration
 * @param operation - The permission operation to check
 * @param userType - User's global type (optional)
 * @param orgRole - User's role in the organization (optional)
 * @param depth - Organization depth, or the prospective child's depth for CREATE_CHILD
 * @returns True if user has permission
 */
export declare function hasOrgPermission(config: GoCommonConfig, operation: OrganizationPermissionOperation, userType?: UserType, orgRole?: OrganizationRole, depth?: number): boolean;
/**
 * Map organization permission operations to their corresponding org-type capability.
 * Returns undefined when the operation has no backend org-type gate.
 */
export declare function getOrganizationTypeCapabilityForOperation(operation: OrganizationPermissionOperation): OrganizationTypeCapability | undefined;
/**
 * Check if creator should be auto-added when creating child org at depth.
 */
export declare function shouldAutoAddCreatorOnChildCreate(config: GoCommonConfig, depth?: number): boolean;
/**
 * Check whether a member may run org-scoped user search in an organization.
 * Mirrors the backend rule: the member's effective role meets
 * `userSearchMinOrgRole` at the organization's depth, or their user type meets
 * `userSearchMinUserType`. Non-members are never offered org-scoped search.
 *
 * @param config - GoCommon configuration
 * @param userType - User's global type (optional)
 * @param organization - The organization with the user's role in it
 * @returns True if org-scoped search is allowed
 */
export declare function canSearchUsersInOrganization(config: GoCommonConfig, userType: UserType | undefined, organization: OrganizationWithUserRole): boolean;
/** An organization offered as a user-search scope. */
export interface SearchableOrganizationOption {
    id: bigint;
    /** The organization's name, or "Organization {id}" when it has none. */
    name: string;
}
/**
 * The viewer's organizations in which org-scoped user search may run, in the given order. Empty
 * unless the configuration enables both user search and organizations; each organization must
 * pass {@link canSearchUsersInOrganization}.
 *
 * @param config - GoCommon configuration
 * @param userType - User's global type (optional)
 * @param organizations - The viewer's organizations with their role in each
 */
export declare function searchableOrganizationOptions(config: GoCommonConfig, userType: UserType | undefined, organizations: readonly OrganizationWithUserRole[] | undefined): SearchableOrganizationOption[];
//# sourceMappingURL=permission.d.ts.map