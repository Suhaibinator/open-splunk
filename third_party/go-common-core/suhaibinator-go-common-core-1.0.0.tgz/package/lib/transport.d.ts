export type MaybePromise<T> = T | Promise<T>;
export interface ProtobufEncoder<T> {
    encode(message: T): {
        finish(): Uint8Array;
    };
}
export interface ProtobufDecoder<T> {
    decode(bytes: Uint8Array): T;
}
export type TransportHeadersProvider = () => MaybePromise<HeadersInit>;
export interface TransportLogEvent {
    level: "debug" | "warn" | "error";
    phase: "request" | "response" | "error";
    method: string;
    /** Endpoint path with query and fragment removed. */
    path: string;
    statusCode?: number;
    durationMs?: number;
    requestBytes?: number;
    responseBytes?: number;
    errorCode?: string;
}
/**
 * Receives deliberately bounded request metadata. Headers and bodies are never
 * included, which prevents session cookies and authorization values from being
 * logged by the transport.
 */
export type TransportLogger = (event: TransportLogEvent) => void;
export interface ProtobufTransportConfig {
    /** API origin, optionally resolved lazily for browser/server bundles. */
    baseUrl: string | (() => string);
    /** API path prefix. Defaults to `/api/v1`. */
    apiPrefix?: string;
    /** Fetch credentials mode. Defaults to `include`. */
    credentials?: RequestCredentials;
    /** Default request timeout in milliseconds. Defaults to 30 seconds. */
    timeout?: number;
    /** Static headers included with every request. */
    headers?: HeadersInit;
    /**
     * Per-request asynchronous headers. SSR adapters should read request-scoped
     * cookies and forwarding headers here rather than caching them globally.
     */
    headersProvider?: TransportHeadersProvider;
    /**
     * Callback invoked after a 401 response is decoded. Every 401 also raises the
     * process-wide {@link reportUnauthorizedResponse} signal, which `AuthProvider`
     * uses to revalidate the session; this hook is for anything app-specific on
     * top of that.
     */
    onUnauthorized?: () => void;
    /** Injectable fetch implementation for tests and alternate runtimes. */
    fetch?: typeof globalThis.fetch;
    /** Optional structured logger. It never receives headers or bodies. */
    logger?: TransportLogger;
}
export interface HttpRequestOptions {
    method: string;
    url: string;
    headers?: Record<string, string>;
    body?: Uint8Array | FormData;
    timeout?: number;
    credentials?: RequestCredentials;
    signal?: AbortSignal;
    cache?: RequestCache;
}
export interface HttpResponse {
    data: Uint8Array;
    status: number;
    headers: Record<string, string>;
}
/** Low-level injectable HTTP seam used by ProtobufTransport. */
export interface HttpClient {
    request(options: HttpRequestOptions): Promise<HttpResponse>;
}
export declare class RequestTimeoutError extends Error {
    readonly timeoutMs: number;
    constructor(timeoutMs: number);
}
export declare class RequestAbortedError extends Error {
    constructor();
}
/** Default fetch-backed implementation of the low-level HTTP seam. */
export declare class FetchHttpClient implements HttpClient {
    private readonly fetchImpl;
    constructor(fetchImpl?: typeof globalThis.fetch);
    request(options: HttpRequestOptions): Promise<HttpResponse>;
}
/**
 * Typed API error shared by GoCommonClient and application-owned protobuf
 * clients.
 */
export declare class ApiError extends Error {
    readonly statusCode: number;
    readonly code?: string | undefined;
    readonly details?: any;
    readonly headers: Readonly<Record<string, string>>;
    constructor(message: string, statusCode: number, code?: string | undefined, details?: any, headers?: Readonly<Record<string, string>>);
    getHeader(name: string): string | undefined;
}
export declare function isApiStatus(error: unknown, statusCode: number): error is ApiError;
export interface ProtobufBytesRequest {
    path: string;
    method?: string;
    body?: Uint8Array | FormData;
    headers?: HeadersInit;
    timeout?: number;
    credentials?: RequestCredentials;
    signal?: AbortSignal;
    cache?: RequestCache;
    /** Require protobuf Content-Type on a non-empty successful response. Defaults to true. */
    expectProtobuf?: boolean;
}
export interface ProtobufRequest<TRequest, TResponse> extends Omit<ProtobufBytesRequest, "body"> {
    request: TRequest;
    requestCodec: ProtobufEncoder<TRequest>;
    responseCodec: ProtobufDecoder<TResponse>;
}
/**
 * Framework-neutral protobuf transport shared by go-common and consuming apps.
 * It owns wire encoding, timeout/error normalization, and safe request metadata;
 * framework adapters supply environment URLs and request-scoped headers.
 */
export declare class ProtobufTransport {
    private readonly config;
    private readonly httpClient;
    constructor(config: ProtobufTransportConfig, httpClient?: HttpClient);
    getBaseUrl(): string;
    getApiPrefix(): string;
    /** URL a request for `path` is sent to. */
    getRequestUrl(path: string): string;
    request<TRequest, TResponse>(options: ProtobufRequest<TRequest, TResponse>): Promise<TResponse>;
    requestBytes(options: ProtobufBytesRequest): Promise<Uint8Array>;
    private resolveHeaders;
    private log;
}
//# sourceMappingURL=transport.d.ts.map