/**
 * MIME type detection utilities for secure file type validation
 *
 * This module provides reliable MIME type detection by:
 * 1. Reading file magic bytes (file signatures)
 * 2. Validating against file extensions
 * 3. Enforcing an allowlist of acceptable types
 *
 * Security Notice:
 * Browser-provided MIME types (file.type) cannot be trusted as they are:
 * - Often based solely on file extension
 * - Inconsistent across browsers
 * - Can be empty for unknown types
 * - Can be spoofed by malicious actors
 *
 * This module uses magic byte detection to verify actual file content,
 * providing a more secure and reliable way to determine file types.
 */
export declare const ALLOWED_MIME_TYPES: {
    profilePicture: string[];
    attachment: string[];
};
/**
 * Get reliable MIME type for a file
 *
 * @param file The file to check
 * @param context The context for validation ('profilePicture' or 'attachment')
 * @returns Promise resolving to the detected MIME type
 * @throws Error if the file type is not allowed or cannot be determined
 */
export declare function getMimeType(file: File, context?: keyof typeof ALLOWED_MIME_TYPES): Promise<string>;
/**
 * Validate file size
 */
export declare function validateFileSize(file: File, maxSizeBytes: number): void;
/**
 * Get human-readable file type name
 */
export declare function getFileTypeName(mimeType: string): string;
//# sourceMappingURL=mime-utils.d.ts.map