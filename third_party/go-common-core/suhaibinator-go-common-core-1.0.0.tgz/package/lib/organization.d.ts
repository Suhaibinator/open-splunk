import type { Organization } from "./generated/organization";
/**
 * The owner and hierarchy fields needed to classify an organization without
 * coupling callers to its remaining generated transport fields.
 */
export type PersonalOrganizationLike = Pick<Organization, "personalOwnerUserId" | "parentOrganizationId">;
/**
 * Classifies solely by authoritative owner-field presence. Loose null checks
 * match Go's nil-pointer semantics: an explicit JSON null is "no owner".
 */
export declare function isPersonalOrganization(organization: PersonalOrganizationLike | null | undefined): boolean;
/** A personal workspace root has an owner and no parent organization. */
export declare function isPersonalWorkspaceRoot(organization: PersonalOrganizationLike | null | undefined): boolean;
/** A present organization without an owner marker is shared. */
export declare function isSharedOrganization(organization: PersonalOrganizationLike | null | undefined): boolean;
//# sourceMappingURL=organization.d.ts.map