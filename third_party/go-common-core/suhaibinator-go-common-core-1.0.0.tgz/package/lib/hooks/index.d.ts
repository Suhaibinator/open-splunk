/**
 * React hooks for go-common API client
 *
 * These hooks provide a convenient way to use the go-common client
 * in React applications with proper state management and lifecycle handling.
 */
import { GoCommonClient, ApiError } from "../client";
export { useIsMobile } from "./use-mobile";
/**
 * Hook state for async operations
 */
export interface AsyncState<T> {
    data: T | null;
    loading: boolean;
    error: string | null;
}
/**
 * Options for async hooks
 */
export interface AsyncHookOptions {
    onSuccess?: (data: any) => void;
    onError?: (error: ApiError) => void;
    retry?: boolean;
    retryCount?: number;
}
/**
 * Authentication hook
 */
export declare function useAuth(client: GoCommonClient): {
    user: any;
    loading: any;
    isAuthenticated: any;
    login: any;
    logout: any;
    register: any;
    refetch: () => Promise<void>;
};
/**
 * Generic async operation hook
 */
export declare function useAsync<T, Args extends any[]>(asyncFunction: (...args: Args) => Promise<T>, options?: AsyncHookOptions): {
    execute: (...args: Args) => Promise<void>;
    state: AsyncState<T>;
    reset: () => void;
};
/**
 * User settings hook
 */
export declare function useUserSettings(client: GoCommonClient): {
    settings: any;
    loading: any;
    error: any;
    updateSettings: any;
    refetch: any;
};
/**
 * Contact form hook
 */
export declare function useContactForm(client: GoCommonClient): {
    submit: (name: string, email: string, subject: string, message: string) => Promise<void>;
    submitting: boolean;
    referenceId: string | null;
    error: string | null;
    reset: () => void;
};
/**
 * OAuth sign-in hook. `authorize` creates the server-issued state and resolves
 * to the provider authorization URL to navigate to; `authenticate` completes
 * the callback with the query's code and state.
 */
export declare function useOAuth(client: GoCommonClient): {
    authenticate: any;
    authorize: any;
    processing: any;
    error: any;
};
//# sourceMappingURL=index.d.ts.map