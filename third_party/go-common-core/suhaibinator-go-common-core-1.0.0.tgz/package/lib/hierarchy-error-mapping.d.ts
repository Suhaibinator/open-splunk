/**
 * Hierarchy Error Mapping
 *
 * Maps backend hierarchy-specific errors to user-friendly i18n keys.
 * Use mapHierarchyError() to convert API errors into localized messages.
 */
/**
 * Error codes for hierarchy-specific backend errors.
 */
export declare enum HierarchyErrorCode {
    /** The selected parent organization is invalid */
    PARENT_INVALID = "PARENT_INVALID",
    /** The parent organization could not be found */
    PARENT_NOT_FOUND = "PARENT_NOT_FOUND",
    /** Organization hierarchy depth exceeds configured limit */
    HIERARCHY_DEPTH_EXCEEDED = "HIERARCHY_DEPTH_EXCEEDED",
    /** Membership in all ancestor organizations is required */
    ANCESTOR_MEMBERSHIP_REQUIRED = "ANCESTOR_MEMBERSHIP_REQUIRED",
    /** Insufficient permissions to create child organization */
    CREATE_CHILD_NOT_ALLOWED = "CREATE_CHILD_NOT_ALLOWED",
    /** Insufficient permissions to self-join organization */
    SELF_JOIN_NOT_ALLOWED = "SELF_JOIN_NOT_ALLOWED"
}
/**
 * Configuration for mapping a backend error to an i18n key.
 */
export interface HierarchyErrorMapping {
    /** HTTP status code for this error */
    statusCode: number;
    /** Regex pattern to match against error message */
    pattern: RegExp;
    /** Error code classification */
    code: HierarchyErrorCode;
    /** i18n key for the user-facing message */
    i18nKey: string;
}
/**
 * Mappings from backend error patterns to i18n keys.
 * Order matters - first match wins.
 */
export declare const HIERARCHY_ERROR_MAPPINGS: HierarchyErrorMapping[];
/**
 * Result of mapping a backend error.
 */
export interface HierarchyErrorResult {
    /** Error code if recognized, null otherwise */
    code: HierarchyErrorCode | null;
    /** i18n key for the error message */
    i18nKey: string;
    /** Original error message as fallback */
    fallbackMessage: string;
}
/**
 * Maps a backend error to an i18n key for user-friendly display.
 *
 * @param error - The error from the API (can be Error, object with statusCode/message, etc.)
 * @returns Object with error code, i18n key, and fallback message
 *
 * @example
 * ```typescript
 * try {
 *   await apiClient.organizations.create({ parentOrganizationId: invalidId, ... });
 * } catch (error) {
 *   const { i18nKey, fallbackMessage } = mapHierarchyError(error);
 *   const message = t(i18nKey) || fallbackMessage;
 *   showError(message);
 * }
 * ```
 */
export declare function mapHierarchyError(error: unknown): HierarchyErrorResult;
//# sourceMappingURL=hierarchy-error-mapping.d.ts.map