/**
 * Utility functions for go-common API client
 */
import { User, UserType } from "./generated/user";
import { OrganizationRole } from "./generated/organization";
import { GoCommonConfig } from "./config/types";
import { type Faro, type EventAttributes, LogLevel } from "@grafana/faro-web-sdk";
/**
 * Rate limiter for API calls
 */
export declare class RateLimiter {
    private maxConcurrent;
    private minDelay;
    private queue;
    private running;
    constructor(maxConcurrent?: number, minDelay?: number);
    limit<T>(fn: () => Promise<T>): Promise<T>;
}
/**
 * Exponential backoff retry logic
 */
export declare function withRetry<T>(fn: () => Promise<T>, options?: {
    maxRetries?: number;
    initialDelay?: number;
    maxDelay?: number;
    shouldRetry?: (error: any) => boolean;
}): Promise<T>;
/**
 * Local storage wrapper with encryption support
 */
export declare class SecureStorage {
    private prefix;
    private storage;
    constructor(prefix?: string);
    /**
     * Clear all stored data
     */
    clear(): void;
}
/**
 * File validation utilities
 */
export declare const FileValidation: {
    /**
     * Validate file size
     */
    validateSize(file: File, maxSizeBytes: number): boolean;
    /**
     * Validate file type
     */
    validateType(file: File, allowedTypes: string[]): boolean;
    /**
     * Common image validation
     */
    isValidImage(file: File, maxSizeMB?: number): boolean;
};
/**
 * Debounced function interface with cleanup capability
 */
export interface DebouncedFunction<T extends (...args: any[]) => any> {
    (...args: Parameters<T>): void;
    cancel(): void;
    flush(): ReturnType<T> | undefined;
    pending(): boolean;
}
/**
 * Create a debounced version of a function with cleanup capabilities
 *
 * @param fn - The function to debounce
 * @param delay - The delay in milliseconds
 * @param options - Optional configuration
 * @returns Debounced function with cancel, flush, and pending methods
 *
 * **Behavior modes:**
 * - `{leading: false, trailing: true}` (default): Classic debounce - only last call fires after idle period
 * - `{leading: true, trailing: true}`: Fires immediately on first call, then after idle period if more calls occurred
 * - `{leading: true, trailing: false}`: Throttle-like - fires immediately, then ignores calls during cooldown
 * - `{leading: false, trailing: false}`: Invalid - throws error
 *
 * **Note:** In leading+trailing mode, the trailing call only fires if new arguments arrive after the leading call.
 * This matches Lodash behavior and prevents duplicate executions.
 *
 * @example
 * ```typescript
 * const debouncedSearch = debounce(searchFunction, 300);
 *
 * // Use the debounced function
 * debouncedSearch('query');
 *
 * // Cancel pending execution
 * debouncedSearch.cancel();
 *
 * // Execute immediately if pending, returns the result
 * const result = debouncedSearch.flush();
 *
 * // Check if execution is pending
 * if (debouncedSearch.pending()) {
 *   console.log('Execution is pending');
 * }
 * ```
 */
export declare function debounce<T extends (...args: any[]) => any>(fn: T, delay: number, { leading, trailing }?: {
    leading?: boolean;
    trailing?: boolean;
}): DebouncedFunction<T>;
/**
 * Get a cookie value by name
 * @param name The name of the cookie to get
 * @returns The cookie value or null if not found
 */
export declare function getCookie(name: string): string | null;
/**
 * Set a cookie with the given name and value
 * @param name The name of the cookie
 * @param value The value to set
 * @param options Optional cookie options
 */
export declare function setCookie(name: string, value: string, options?: {
    path?: string;
    expires?: Date | number;
    maxAge?: number;
    domain?: string;
    secure?: boolean;
    httpOnly?: boolean;
    sameSite?: "strict" | "lax" | "none";
}): void;
/**
 * Remove a cookie by setting its expiration date to the past
 * @param name The name of the cookie to remove
 * @param options Optional cookie options
 */
export declare function removeCookie(name: string, options?: {
    path?: string;
    domain?: string;
}): void;
/**
 * Derive a cookie domain from a URL for cross-subdomain cookie sharing.
 * Strips any 'api.' prefix and prepends a dot.
 * Returns undefined for localhost/127.0.0.1 or invalid URLs.
 */
export declare function getCookieDomainFromUrl(url: string): string | undefined;
declare global {
    interface Window {
        __FARO__?: Faro;
    }
}
export declare function initTelemetry(): Faro | undefined;
type ErrorContext = Record<string, string | number | boolean | null>;
export declare function captureError(error: Error, context?: ErrorContext): void;
export declare function captureEvent(name: string, attributes?: EventAttributes): void;
export declare function setTelemetryUser(user: {
    id?: string;
    email?: string;
    [key: string]: any;
}): void;
export declare function logTelemetryMessage(message: string, level?: LogLevel, context?: Record<string, any>): void;
/**
 * Permission utility functions for user type and organization role checking
 * These functions mirror the backend permission system for consistent authorization
 */
/**
 * Check if a user type meets or exceeds the required permission level
 * @param userType - The user's current type
 * @param requiredType - The minimum required user type
 * @returns True if the user has sufficient permissions
 */
export declare function hasUserTypePermission(userType: UserType | undefined, requiredType: UserType): boolean;
/**
 * Check if an organization role meets or exceeds the required permission level
 * @param organizationRole - The user's current organization role
 * @param requiredRole - The minimum required organization role
 * @returns True if the user has sufficient organization permissions
 */
export declare function hasOrganizationRolePermission(organizationRole: OrganizationRole | undefined, requiredRole: OrganizationRole): boolean;
/**
 * UI Display utilities using GoCommonConfig
 * These functions provide consistent user display behavior based on configuration
 */
/**
 * Get user display text based on GoCommon UI configuration
 * @param config - GoCommon configuration with UI settings
 * @param user - User data object with various identifier fields
 * @returns Display text for the user
 */
export declare function getUserDisplayText(config: GoCommonConfig, user: User): string;
/**
 * Get avatar fallback text based on GoCommon UI configuration
 * @param config - GoCommon configuration with UI settings
 * @param user - User data object with various identifier fields
 * @returns Fallback text for avatars (1 or 2 characters)
 */
export declare function getAvatarFallbackText(config: GoCommonConfig, user: User): string;
export {};
//# sourceMappingURL=utils.d.ts.map