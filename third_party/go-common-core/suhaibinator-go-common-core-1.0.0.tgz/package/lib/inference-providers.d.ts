/**
 * Stable IDs for providers bundled with go-common.
 *
 * Provider IDs remain open strings: applications can configure custom
 * providers and should pass their IDs directly where a provider ID is needed.
 */
export declare const INFERENCE_PROVIDER_IDS: {
    readonly OPENAI: "openai";
    readonly OPENROUTER: "openrouter";
    readonly ANTHROPIC: "anthropic";
    readonly BASETEN: "baseten";
    readonly OLLAMA_CLOUD: "ollama-cloud";
    readonly GOOGLE_AI_STUDIO: "google-ai-studio";
    readonly VERTEX_AI: "vertex-ai";
    readonly AZURE_OPENAI: "azure-openai";
    readonly AWS_BEDROCK: "aws-bedrock";
};
export type BuiltInInferenceProviderId = (typeof INFERENCE_PROVIDER_IDS)[keyof typeof INFERENCE_PROVIDER_IDS];
//# sourceMappingURL=inference-providers.d.ts.map