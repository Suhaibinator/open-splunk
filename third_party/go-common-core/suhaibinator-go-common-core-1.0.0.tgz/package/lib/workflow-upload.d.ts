/** Result of the browser-owned initialize/upload/complete workflow. */
export type WorkflowUploadResult<TResult> = {
    status: "completed";
    result: TResult;
} | {
    status: "canceled";
};
export declare class WorkflowUploadError extends Error {
    readonly cause: unknown;
    readonly cleanupSucceeded: boolean;
    readonly originalError: unknown;
    constructor(originalError: unknown, cleanupSucceeded: boolean);
}
export interface WorkflowUploadOptions<TInitialized, TResult> {
    initialize: () => Promise<TInitialized>;
    /** Observer failures after initialization also require compensation. */
    onInitialized?: (initialized: TInitialized) => unknown;
    upload: (initialized: TInitialized) => Promise<void>;
    complete: (initialized: TInitialized) => Promise<TResult>;
    /** Must be guarded by the server against canceling already-completed uploads. */
    cancel: (initialized: TInitialized) => Promise<void>;
    /** True only when an explicit cancellation has succeeded. */
    isCanceled: (initialized: TInitialized) => boolean;
}
/**
 * Compensates failures after initialization while preserving their original cause.
 * Explicit cancellation suppresses late failures. A rejected complete call can mean
 * the response was lost after the server committed: callers must refresh authoritative
 * state after WorkflowUploadError, regardless of cleanupSucceeded.
 */
export declare function runWorkflowUpload<TInitialized, TResult>(options: WorkflowUploadOptions<TInitialized, TResult>): Promise<WorkflowUploadResult<TResult>>;
//# sourceMappingURL=workflow-upload.d.ts.map