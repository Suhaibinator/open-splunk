import { ApiError } from "./transport";
export declare const REAUTHENTICATION_REQUIRED_ERROR_CODE = "REAUTHENTICATION_REQUIRED";
export declare const REAUTHENTICATION_REQUIRED_ERROR_MESSAGE = "Please reauthenticate to continue";
/**
 * Type guard to check if an error has a message property
 */
export declare function hasErrorMessage(error: unknown): error is {
    message: string;
};
/**
 * Extract error message from various error types
 *
 * @param error The error to extract a message from
 * @param defaultMessage Default message to use if no error message can be extracted
 * @returns A string error message
 */
export declare function getErrorMessage(error: unknown, defaultMessage?: string): string;
/**
 * Type guard to check if an error is an API error
 */
export declare function isApiError(error: unknown): error is ApiError;
/**
 * Detects the backend's "reauthentication required" 403. The backend prefers a
 * machine-readable `code` (REAUTHENTICATION_REQUIRED_ERROR_CODE); when the error
 * transport cannot carry a code we fall back to matching the known 403 messages.
 * The backend messages are a stable client-detected contract — see the
 * ErrReauthenticationRequired mapping in pkg/common_api/errors.go before changing
 * their wording.
 */
export declare function isReauthenticationRequiredError(error: unknown): boolean;
/**
 * 409 message of an edit or removal of agent input that is no longer queued: the agent received
 * it (it is a chat message now), it was removed or discarded, or it never existed. A stable
 * contract with the ErrChatAgentQueuedInputNotQueued mapping in pkg/common_api/errors.go.
 */
export declare const AGENT_QUEUED_INPUT_NOT_QUEUED_ERROR_MESSAGE = "This message is no longer queued for the agent";
/**
 * 409 message of a thread reply also sent to the channel while an agent session it reaches is
 * busy or suspended: one send never splits into a message now and queued input. A stable contract
 * with the ErrChatAgentBroadcastWouldWait mapping in pkg/common_api/errors.go.
 */
export declare const AGENT_BROADCAST_WOULD_WAIT_ERROR_MESSAGE = "The agent is busy, so this reply cannot also be sent to the channel";
/**
 * Detects an edit or removal of agent input that is no longer queued: the agent received it, it
 * was removed or discarded, or it never existed. Refetch the queue.
 */
export declare function isAgentQueuedInputNotQueuedError(error: unknown): boolean;
/**
 * Detects a thread reply also sent to the channel that was refused because an agent session it
 * reaches would make it wait. Nothing was sent; it can be sent to the thread alone.
 */
export declare function isAgentBroadcastWouldWaitError(error: unknown): boolean;
/**
 * 400 message of an inference policy save naming a model whose provider a parent organization's
 * allowlist blocks. A stable contract with the ErrInferenceAncestorProviderBlocked mapping in
 * pkg/common_api/errors.go.
 */
export declare const INFERENCE_ANCESTOR_PROVIDER_BLOCKED_ERROR_MESSAGE = "A parent organization's provider allowlist blocks this model";
/**
 * 403 message of a session re-target, or a MOVE session action, under an operation whose
 * re-targeting gate does not allow it. A stable contract with the
 * ErrInferenceSessionRetargetNotAllowed mapping in pkg/common_api/errors.go.
 */
export declare const INFERENCE_SESSION_RETARGET_NOT_ALLOWED_ERROR_MESSAGE = "Re-targeting is not allowed for this operation";
/**
 * 403 message prefix of an inference.BlockError, followed by the block reason's proto name. A
 * stable contract with the BlockError mapping in pkg/common_api/errors.go.
 */
export declare const INFERENCE_BLOCKED_ERROR_MESSAGE_PREFIX = "Inference is blocked by the current routing policy: ";
/** Detects a policy save rejected because a parent organization blocks a model's provider. */
export declare function isInferenceAncestorProviderBlockedError(error: unknown): boolean;
/** Detects a re-target the operation's re-targeting gate does not allow. */
export declare function isInferenceSessionRetargetNotAllowedError(error: unknown): boolean;
/**
 * The block reason's proto name (such as `INFERENCE_BLOCK_REASON_PROVIDER_NOT_ALLOWED`) an
 * inference.BlockError 403 names, or undefined for any other error.
 */
export declare function getInferenceBlockedErrorReasonName(error: unknown): string | undefined;
/**
 * Standardized error object interface
 */
export interface StandardError {
    message: string;
    code?: string | number;
    details?: Record<string, unknown>;
    stack?: string;
}
/**
 * Convert any error to a standardized error object
 *
 * @param error The error to standardize
 * @param defaultMessage Default message if none can be extracted
 * @returns Standardized error object
 */
export declare function standardizeError(error: unknown, defaultMessage?: string): StandardError;
/**
 * Error handling options for API calls
 */
export interface ErrorHandlingOptions {
    /** Default message to use if error message cannot be extracted */
    defaultMessage?: string;
    /** Whether to include error details in the result */
    includeDetails?: boolean;
    /** Custom error handler function */
    onError?: (error: StandardError) => void;
}
/**
 * Handle API errors with standardized processing
 * Returns a standardized error object instead of directly showing toasts
 * This allows the UI layer to decide how to display the error
 *
 * @param error The error to handle
 * @param options Error handling options
 * @returns Standardized error object
 */
export declare function handleApiError(error: unknown, options?: ErrorHandlingOptions): StandardError;
/**
 * Utility to create consistent error responses
 */
export declare function createErrorResponse(message: string, code?: string | number, details?: Record<string, unknown>): StandardError;
/**
 * Check if an error indicates a network/connectivity issue
 */
export declare function isNetworkError(error: unknown): boolean;
/**
 * Check if an error indicates an authentication issue
 */
export declare function isAuthError(error: unknown): boolean;
/**
 * Check if an error indicates a validation issue
 */
export declare function isValidationError(error: unknown): boolean;
//# sourceMappingURL=error-handling.d.ts.map