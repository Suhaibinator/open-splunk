import { UserType, UserIdentifierType } from "../generated/user";
import { OrganizationRole, OrganizationType } from "../generated/organization";
/**
 * Value that can be scalar (same for all depths) or array (indexed by depth).
 * Used for depth-indexed organization hierarchy permissions.
 */
export type DepthIndexedValue<T> = T | T[];
/**
 * Type guard to check if a value is depth-indexed (array) vs scalar
 */
export declare function isDepthIndexed<T>(value: DepthIndexedValue<T>): value is T[];
/**
 * UI configuration enum defines what information to display as the primary user identifier
 */
export declare enum UserDisplayType {
    /**
     * Display the username (e.g., "user123")
     */
    USERNAME = "username",
    /**
     * Display the email address (e.g., "user@example.com")
     */
    EMAIL = "email",
    /**
     * Display the first name only (e.g., "John")
     */
    FIRST_NAME = "firstName",
    /**
     * Display full name (e.g., "John Doe")
     */
    FULL_NAME = "fullName"
}
/**
 * Frontend configuration interface for go-common packages.
 * This mirrors the backend configuration structure to ensure consistency
 * between frontend and backend feature enablement and settings.
 */
export interface GoCommonConfig {
    /** Enable email-based authentication endpoints and components */
    enableEmailAuth: boolean;
    /** Enable OAuth authentication endpoints and components */
    enableOAuth: boolean;
    /** Enable contact form endpoints and components */
    enableContacts: boolean;
    /** Enable careers endpoints and components */
    enableCareers: boolean;
    /** Enable file attachment endpoints and components */
    enableAttachments: boolean;
    /** Enable user settings endpoints and components */
    enableUserSettings: boolean;
    /** Enable user profile endpoints and components */
    enableUserProfiles: boolean;
    /** Enable user search endpoints and components */
    enableUserSearch: boolean;
    /** Enable Faro telemetry endpoints and components */
    enableFaro: boolean;
    /** Enable admin API endpoints and components */
    enableAdminAPI: boolean;
    /** Enable organization endpoints and components */
    enableOrganizations: boolean;
    /**
     * Offer the channel owner's public access menu and show the Public badge (mirrors backend
     * chat.enable_public_chat_read). Off by default, as on the server, which ignores every
     * channel's public level while its flag is off.
     */
    enablePublicChatRead?: boolean;
    /** Minimum user type required for global user search */
    userSearchMinUserType: UserType;
    /** Minimum organization role required for org-scoped user search, one entry per depth [depth0, depth1, ...] */
    userSearchMinOrgRole: OrganizationRole[];
    /** Enable suggestions when query is empty */
    userSearchEnableSuggestions: boolean;
    /** When user search is disabled, allow fallback to user-id input */
    userSearchFallbackToUserIdInput: boolean;
    /** Interval between typing pings sent over websocket */
    chatTypingSendIntervalMs: number;
    /** Idle timeout before sending typing stop */
    chatTypingIdleTimeoutMs: number;
    /** Time before incoming typing indicators expire */
    chatTypingExpiryMs: number;
    /** Sweep interval for pruning expired typing indicators */
    chatTypingSweepIntervalMs: number;
    /** Maximum chat channel name length (mirrors backend ChatMaxChannelNameLength) */
    chatMaxChannelNameLength: number;
    /** Maximum chat channel description length (mirrors backend ChatMaxChannelDescriptionLength) */
    chatMaxChannelDescriptionLength: number;
    /** Whether username field is required during registration */
    requireUsername: boolean;
    /** Whether name fields (first/last) are required during registration */
    requireName: boolean;
    /** Controls OAuth signup behavior for new accounts */
    oauthSignupMode?: "legacy" | "disabled" | "prefixed" | "email_local_part";
    /** Prefix used for system-generated usernames when OAuth signup mode is prefixed */
    oauthDefaultUsernamePrefix?: string;
    /** Base URL for the API server (e.g., "https://api.example.com") */
    apiBaseUrl: string;
    /** Path prefix for all API endpoints (e.g., "/api/v1") */
    apiPathPrefix: string;
    /** Default theme for the application */
    defaultTheme: "light" | "dark" | "system";
    /** Minimum password length (mirrors backend SanitizerPasswordMinLength) */
    passwordMinLength: number;
    /** Maximum password length (mirrors backend SanitizerPasswordMaxLength) */
    passwordMaxLength: number;
    /** Whether passwords must contain an uppercase letter (mirrors backend SanitizerPasswordRequireUppercase) */
    passwordRequireUppercase: boolean;
    /** Whether passwords must contain a lowercase letter (mirrors backend SanitizerPasswordRequireLowercase) */
    passwordRequireLowercase: boolean;
    /** Whether passwords must contain a number (mirrors backend SanitizerPasswordRequireNumber) */
    passwordRequireNumber: boolean;
    /** Whether passwords must contain a special character (mirrors backend SanitizerPasswordRequireSpecial) */
    passwordRequireSpecial: boolean;
    /** Set of characters considered special for password validation (mirrors backend SanitizerPasswordSpecialChars) */
    passwordSpecialChars?: string;
    /** Maximum email address length (mirrors backend SanitizerMaxEmailLength) */
    emailMaxLength: number;
    /** Minimum username length (mirrors backend SanitizerUsernameMinLength) */
    usernameMinLength: number;
    /** Maximum username length (mirrors backend SanitizerUsernameMaxLength) */
    usernameMaxLength: number;
    /** Minimum length for first_name and last_name fields (mirrors backend SanitizerRealNameMinLength) */
    realNameMinLength: number;
    /** Maximum length for first_name and last_name fields (mirrors backend SanitizerRealNameMaxLength) */
    realNameMaxLength: number;
    /** Default region/country code for parsing phone numbers (mirrors backend PhoneNumberDefaultRegion) */
    phoneNumberDefaultRegion: string;
    /** Maximum file size for attachments in bytes (should align with backend AttachmentDefaultMaxSize) */
    attachmentMaxSize: number;
    /** List of allowed MIME types for attachments */
    attachmentAllowedTypes: string[];
    /** Maximum login attempts before rate limiting (mirrors backend LoginMaxAttempts) */
    loginMaxAttempts: number;
    /** Maximum registration attempts before rate limiting (mirrors backend RegisterMaxAttempts) */
    registerMaxAttempts: number;
    /** Maximum contact form submissions before rate limiting (mirrors backend ContactMaxAttempts) */
    contactMaxAttempts: number;
    /** Maximum career application submissions before rate limiting (mirrors backend CareerApplicationMaxAttempts) */
    careerApplicationMaxAttempts: number;
    /** Minimum user type required for admin panel access (mirrors backend SiteMinUserTypeAdminAccess) */
    siteMinUserTypeAdminAccess: UserType;
    /** Minimum user type required for listing users (mirrors backend SiteMinUserTypeUserListing) */
    siteMinUserTypeUserListing: UserType;
    /** Minimum user type required for viewing user details (mirrors backend SiteMinUserTypeUserViewing) */
    siteMinUserTypeUserViewing: UserType;
    /** Minimum user type required for banning users (mirrors backend SiteMinUserTypeUserBanning) */
    siteMinUserTypeUserBanning: UserType;
    /** Minimum user type required for modifying users (mirrors backend SiteMinUserTypeUserModification) */
    siteMinUserTypeUserModification: UserType;
    /** Minimum user type required for deleting users (mirrors backend SiteMinUserTypeUserDeletion) */
    siteMinUserTypeUserDeletion: UserType;
    /** Minimum user type required for changing user types (mirrors backend SiteMinUserTypeUserTypeChange) */
    siteMinUserTypeUserTypeChange: UserType;
    /** Minimum user type required for system settings access (mirrors backend SiteMinUserTypeSystemAccess) */
    siteMinUserTypeSystemAccess: UserType;
    /** Minimum user type required for content moderation (mirrors backend SiteMinUserTypeContentModeration) */
    siteMinUserTypeContentModeration: UserType;
    /** Minimum user type required for attachment admin access (mirrors backend SiteMinUserTypeAttachmentAccess) */
    siteMinUserTypeAttachmentAccess: UserType;
    /** Minimum user type required for analytics access (mirrors backend SiteMinUserTypeAnalyticsAccess) */
    siteMinUserTypeAnalyticsAccess: UserType;
    /** Minimum user type required to create organizations via admin (mirrors backend SiteMinUserTypeAdminCreateOrganization) */
    siteMinUserTypeAdminCreateOrganization: UserType;
    /** Minimum user type required to list organizations via admin (mirrors backend SiteMinUserTypeAdminListOrganizations) */
    siteMinUserTypeAdminListOrganizations: UserType;
    /** Minimum user type required to manage organization members via admin (mirrors backend SiteMinUserTypeAdminManageOrganizationMembers) */
    siteMinUserTypeAdminManageOrganizationMembers: UserType;
    /** Minimum user type required to get organization members via admin (mirrors backend SiteMinUserTypeAdminGetOrganizationMember) */
    siteMinUserTypeAdminGetOrganizationMember: UserType;
    /** Minimum user type required to manage chat channels via admin (mirrors backend SiteMinUserTypeAdminChatChannels) */
    siteMinUserTypeAdminChatChannels: UserType;
    /** Minimum user type required to manage careers via admin (mirrors backend SiteMinUserTypeCareersManagement) */
    siteMinUserTypeCareersManagement: UserType;
    /** Minimum user type required to view inference routes, rate-limit policies, and attempt/usage reads (mirrors backend SiteMinUserTypeInferenceViewing) */
    siteMinUserTypeInferenceViewing: UserType;
    /** Minimum user type required to update inference routes and rate-limit policies (mirrors backend SiteMinUserTypeInferenceAdministration) */
    /** Minimum admin tier allowed to select a model for one request or run. */
    siteMinUserTypeInferenceModelOverride: UserType;
    siteMinUserTypeInferenceAdministration: UserType;
    /** Minimum user type required for creating organizations (mirrors backend OrgMinUserTypeCreate) */
    orgMinUserTypeCreate: UserType;
    /** Global override for the parent-role requirement when creating a child organization. */
    orgMinUserTypeCreateChild: UserType;
    /** Minimum user type required to view organization details (mirrors backend OrgMinUserTypeView) */
    orgMinUserTypeView: UserType;
    /** Minimum organization role required to view organization details (mirrors backend OrgMinRoleView), one entry per depth [depth0, depth1, ...] */
    orgMinRoleView: OrganizationRole[];
    /** Minimum user type required to list org members (mirrors backend OrgMinUserTypeListMembers) */
    orgMinUserTypeListMembers: UserType;
    /** Minimum organization role required to list org members (mirrors backend OrgMinRoleListMembers), one entry per depth [depth0, depth1, ...] */
    orgMinRoleListMembers: OrganizationRole[];
    /** Minimum user type required to delete organizations (mirrors backend OrgMinUserTypeDelete) */
    orgMinUserTypeDelete: UserType;
    /** Minimum user type required to update organizations (mirrors backend OrgMinUserTypeUpdate) */
    orgMinUserTypeUpdate: UserType;
    /** Minimum organization role required to update organizations (mirrors backend OrgMinRoleUpdate), one entry per depth [depth0, depth1, ...] */
    orgMinRoleUpdate: OrganizationRole[];
    /** Minimum organization role required to delete organizations (mirrors backend OrgMinRoleDelete), one entry per depth [depth0, depth1, ...] */
    orgMinRoleDelete: OrganizationRole[];
    /** Minimum user type required to invite org members (mirrors backend OrgMinUserTypeInviteMembers) */
    orgMinUserTypeInviteMembers: UserType;
    /** Minimum user type required to add org members (mirrors backend OrgMinUserTypeAddMembers) */
    orgMinUserTypeAddMembers: UserType;
    /** Minimum organization role required to invite org members (mirrors backend OrgMinRoleInviteMembers), one entry per depth [depth0, depth1, ...] */
    orgMinRoleInviteMembers: OrganizationRole[];
    /** Minimum organization role required to add org members (mirrors backend OrgMinRoleAddMembers), one entry per depth [depth0, depth1, ...] */
    orgMinRoleAddMembers: OrganizationRole[];
    /** Minimum user type required to remove org members (mirrors backend OrgMinUserTypeRemoveMembers) */
    orgMinUserTypeRemoveMembers: UserType;
    /** Minimum organization role required to remove org members (mirrors backend OrgMinRoleRemoveMembers), one entry per depth [depth0, depth1, ...] */
    orgMinRoleRemoveMembers: OrganizationRole[];
    /** Minimum user type required to update org member roles (mirrors backend OrgMinUserTypeUpdateMemberRoles) */
    orgMinUserTypeUpdateMemberRoles: UserType;
    /** Minimum organization role required to update org member roles (mirrors backend OrgMinRoleUpdateMemberRoles), one entry per depth [depth0, depth1, ...] */
    orgMinRoleUpdateMemberRoles: OrganizationRole[];
    /** Minimum user type required to manage organization email domains (mirrors backend OrgMinUserTypeManageEmailDomains) */
    orgMinUserTypeManageEmailDomains: UserType;
    /** Minimum organization role required to manage organization email domains (mirrors backend OrgMinRoleManageEmailDomains), one entry per depth [depth0, depth1, ...] */
    orgMinRoleManageEmailDomains: OrganizationRole[];
    /** Minimum user type required to cancel organization invitations (mirrors backend OrgMinUserTypeCancelInvitation) */
    orgMinUserTypeCancelInvitation: UserType;
    /** Minimum organization role required to cancel organization invitations (mirrors backend OrgMinRoleCancelInvitation), one entry per depth [depth0, depth1, ...] */
    orgMinRoleCancelInvitation: OrganizationRole[];
    /** Minimum user type required to view organization invitations (mirrors backend OrgMinUserTypeViewInvitations) */
    orgMinUserTypeViewInvitations: UserType;
    /** Minimum organization role required to view organization invitations (mirrors backend OrgMinRoleViewInvitations), one entry per depth [depth0, depth1, ...] */
    orgMinRoleViewInvitations: OrganizationRole[];
    /**
     * Minimum organization role required to read the organization's inference policy (mirrors backend
     * OrgMinRoleViewInferencePolicy). Organization-role only: user type never grants it. One entry per depth [depth0, depth1, ...].
     */
    orgMinRoleViewInferencePolicy: OrganizationRole[];
    /**
     * Minimum organization role required to change the organization's inference policy and retarget
     * any of its agent sessions (mirrors backend OrgMinRoleManageInferencePolicy). Organization-role
     * only: user type never grants it. One entry per depth [depth0, depth1, ...].
     */
    orgMinRoleManageInferencePolicy: OrganizationRole[];
    /**
     * Minimum organization role required to choose a model where member choice is open (mirrors
     * backend OrgMinRoleChooseInferenceModel). Organization-role only: user type never grants it. One entry per depth [depth0, depth1, ...].
     */
    orgMinRoleChooseInferenceModel: OrganizationRole[];
    /** Default organization type assigned when a new organization is created without an explicit type */
    defaultOrganizationType: OrganizationType;
    /** Capability tier assigned to managed personal workspaces */
    personalWorkspaceOrganizationType: OrganizationType;
    /** Explicit role assigned to each managed personal workspace owner */
    personalWorkspaceOwnerRole: OrganizationRole;
    /** Minimum organization type required to list organization members */
    orgMinTypeListMembers: OrganizationType;
    /** Minimum organization type required to invite organization members */
    orgMinTypeInviteMembers: OrganizationType;
    /** Minimum organization type required to add organization members directly */
    orgMinTypeAddMembers: OrganizationType;
    /** Minimum organization type required to remove organization members */
    orgMinTypeRemoveMembers: OrganizationType;
    /** Minimum organization type required to update organization member roles */
    orgMinTypeUpdateMemberRoles: OrganizationType;
    /** Minimum organization type required to view organization invitations */
    orgMinTypeViewInvitations: OrganizationType;
    /** Minimum organization type required to cancel organization invitations */
    orgMinTypeCancelInvitation: OrganizationType;
    /** Minimum organization type required to manage organization email domains */
    orgMinTypeManageEmailDomains: OrganizationType;
    /** Minimum organization type required to show organization workspace navigation */
    orgMinTypeWorkspaceNavigation: OrganizationType;
    /** Minimum organization type required to create child organizations */
    orgMinTypeCreateChildOrganizations: OrganizationType;
    /** Minimum organization type required for admin and bulk member-management flows */
    orgMinTypeBulkMemberManagement: OrganizationType;
    /** Maximum allowed depth for organization hierarchy (0 = no hierarchy, default: 5) */
    orgHierarchyMaxDepth: number;
    /** Whether child orgs inherit parent role memberships (mirrors backend OrgRoleInheritanceEnabled) */
    orgRoleInheritanceEnabled: boolean;
    /** Minimum role to create child organization at each depth level [depth0, depth1, ...] */
    orgMinRoleCreateChild: OrganizationRole[];
    /** Minimum role to self-join organization at each depth level [depth0, depth1, ...] */
    orgMinRoleSelfJoin: OrganizationRole[];
    /** Whether to auto-add creator when creating child org at each depth [depth0, depth1, ...] */
    orgAutoAddCreatorOnChildCreate: boolean[];
    /** Primary identifier for private user display (what user sees as their main identity) */
    privatePrimaryUserIdentifier: UserIdentifierType;
    /** Secondary identifier for private user display (optional, can be undefined) */
    privateSecondaryUserIdentifier?: UserIdentifierType;
    /** UI component display and behavior configuration */
    ui: {
        /** The primary identifier to display for users in the UI */
        userDisplayType: UserIdentifierType;
        /** The number of characters to use in avatar fallbacks (1 or 2) */
        avatarFallbackChars: 1 | 2;
        /** Toast notification configuration */
        toast: {
            /** Duration in milliseconds for success toasts */
            successDuration: number;
            /** Duration in milliseconds for error toasts */
            errorDuration: number;
        };
        /**
         * Organization role display configuration, optionally indexed by org depth.
         * When depth-indexed, entry 0 applies to root orgs, 1 to immediate children, etc.
         */
        organizationRoleDisplayConfig?: DepthIndexedValue<OrganizationRoleDisplayConfig>;
        /**
         * Group labels for role categories in the enhanced role selector.
         * When depth-indexed, entry 0 applies to root orgs, 1 to immediate children, etc.
         * Defaults: { owner: "Owners", admin: "Administrators", moderator: "Moderators", member: "Members" }
         */
        organizationRoleGroupLabels?: DepthIndexedValue<OrganizationRoleGroupLabels>;
        /**
         * Optional depth-indexed narrowing filters used when listing the authenticated user's own org memberships.
         * Intended for dropdown/workspace navigation callers that want a smaller subset than the backend default.
         */
        userDropdownOrganizationFiltersByDepth?: UserDropdownOrganizationFilterConfig[];
    };
}
/**
 * Display configuration for an organization role badge/selector option.
 * Keep values JSON-serializable so this config can be safely persisted or sent over the wire.
 */
export interface OrganizationRoleConfig {
    label: string;
    variant: "default" | "secondary" | "destructive" | "outline";
    className?: string;
    /** Optional description shown in role selectors and detail views */
    description?: string;
}
/**
 * Human-readable frontend config entry for narrowing org memberships at a specific depth.
 * The client compiles these enum arrays into OrganizationMembershipMaskFilter bitmasks per request.
 */
export interface UserDropdownOrganizationFilterConfig {
    allowedExplicitRoles?: OrganizationRole[];
    allowedOrganizationTypes?: OrganizationType[];
}
/**
 * Map of organization roles to their display config.
 */
export type OrganizationRoleDisplayConfig = Partial<Record<OrganizationRole, OrganizationRoleConfig>>;
/**
 * Group labels for organizational role categories in the enhanced role selector.
 * These correspond to the 4 structural role groups: owner, admin, moderator, member.
 * All fields are optional — unset fields fall back to English defaults.
 */
export interface OrganizationRoleGroupLabels {
    owner?: string;
    admin?: string;
    moderator?: string;
    member?: string;
}
/**
 * Partial configuration type for runtime updates
 */
export type PartialGoCommonConfig = Partial<GoCommonConfig>;
/**
 * Required configuration fields that must be provided
 */
export declare const REQUIRED_GO_COMMON_CONFIG_FIELDS: readonly ["apiBaseUrl", "apiPathPrefix", "enableEmailAuth", "enableOAuth", "enableContacts", "enableCareers", "enableAttachments", "enableUserSettings", "enableUserProfiles", "enableFaro", "enableAdminAPI", "enableUserSearch", "enableOrganizations", "requireUsername", "requireName", "chatTypingSendIntervalMs", "chatTypingIdleTimeoutMs", "chatTypingExpiryMs", "chatTypingSweepIntervalMs"];
export type RequiredGoCommonConfig = Pick<GoCommonConfig, (typeof REQUIRED_GO_COMMON_CONFIG_FIELDS)[number]>;
/**
 * Default fallbacks for fields that UI components may need to render before a
 * GoCommonConfig is available. Exported separately so callers can reuse them
 * (e.g. `config?.phoneNumberDefaultRegion ?? DEFAULT_PHONE_NUMBER_REGION`)
 * without forking the literal.
 */
export declare const DEFAULT_PHONE_NUMBER_REGION = "US";
export declare const DEFAULT_CHAT_CHANNEL_NAME_MAX_LENGTH = 100;
export declare const DEFAULT_CHAT_CHANNEL_DESCRIPTION_MAX_LENGTH = 500;
/**
 * Default accepted special characters for password complexity.
 * Must stay in sync with the backend default for SanitizerPasswordSpecialChars
 * (see pkg/config/defaults.go: DefaultPasswordSpecialChars).
 */
export declare const DEFAULT_PASSWORD_SPECIAL_CHARS = "!@#$%^&*()_+-=[]{}|;:,.<>?";
/**
 * Default configuration values
 */
export declare const DEFAULT_GO_COMMON_CONFIG: Omit<GoCommonConfig, keyof RequiredGoCommonConfig>;
/**
 * Feature flags type helper
 */
export type FeatureFlags = Pick<GoCommonConfig, "enableEmailAuth" | "enableOAuth" | "enableContacts" | "enableCareers" | "enableAttachments" | "enableUserSettings" | "enableUserProfiles" | "enableUserSearch" | "enableFaro" | "enableAdminAPI" | "enableOrganizations">;
/**
 * Validation configuration type helper
 */
export type ValidationConfig = Pick<GoCommonConfig, "passwordMinLength" | "passwordMaxLength" | "passwordRequireUppercase" | "passwordRequireLowercase" | "passwordRequireNumber" | "passwordRequireSpecial" | "passwordSpecialChars" | "emailMaxLength" | "usernameMinLength" | "usernameMaxLength" | "realNameMinLength" | "realNameMaxLength" | "phoneNumberDefaultRegion" | "chatMaxChannelNameLength" | "chatMaxChannelDescriptionLength">;
/**
 * Rate limiting configuration type helper
 */
export type RateLimitConfig = Pick<GoCommonConfig, "loginMaxAttempts" | "registerMaxAttempts" | "contactMaxAttempts" | "careerApplicationMaxAttempts">;
/**
 * Permission configuration type helper
 */
export type PermissionConfig = Pick<GoCommonConfig, "siteMinUserTypeAdminAccess" | "siteMinUserTypeUserListing" | "siteMinUserTypeUserViewing" | "siteMinUserTypeUserBanning" | "siteMinUserTypeUserModification" | "siteMinUserTypeUserDeletion" | "siteMinUserTypeUserTypeChange" | "siteMinUserTypeSystemAccess" | "siteMinUserTypeContentModeration" | "siteMinUserTypeAttachmentAccess" | "siteMinUserTypeAnalyticsAccess" | "siteMinUserTypeAdminCreateOrganization" | "siteMinUserTypeAdminListOrganizations" | "siteMinUserTypeAdminManageOrganizationMembers" | "siteMinUserTypeAdminGetOrganizationMember" | "siteMinUserTypeAdminChatChannels" | "siteMinUserTypeCareersManagement" | "siteMinUserTypeInferenceViewing" | "siteMinUserTypeInferenceModelOverride" | "siteMinUserTypeInferenceAdministration" | "orgMinUserTypeCreate" | "orgMinUserTypeCreateChild" | "orgMinUserTypeView" | "orgMinUserTypeListMembers" | "orgMinRoleView" | "orgMinRoleListMembers" | "orgMinUserTypeDelete" | "orgMinUserTypeUpdate" | "orgMinRoleUpdate" | "orgMinRoleDelete" | "orgMinUserTypeInviteMembers" | "orgMinUserTypeAddMembers" | "orgMinRoleInviteMembers" | "orgMinRoleAddMembers" | "orgMinUserTypeRemoveMembers" | "orgMinRoleRemoveMembers" | "orgMinUserTypeUpdateMemberRoles" | "orgMinRoleUpdateMemberRoles" | "orgMinUserTypeManageEmailDomains" | "orgMinRoleManageEmailDomains" | "orgMinUserTypeCancelInvitation" | "orgMinRoleCancelInvitation" | "orgMinUserTypeViewInvitations" | "orgMinRoleViewInvitations" | "orgMinRoleViewInferencePolicy" | "orgMinRoleManageInferencePolicy" | "orgMinRoleChooseInferenceModel" | "defaultOrganizationType" | "orgMinTypeListMembers" | "orgMinTypeInviteMembers" | "orgMinTypeAddMembers" | "orgMinTypeRemoveMembers" | "orgMinTypeUpdateMemberRoles" | "orgMinTypeViewInvitations" | "orgMinTypeCancelInvitation" | "orgMinTypeManageEmailDomains" | "orgMinTypeWorkspaceNavigation" | "orgMinTypeCreateChildOrganizations" | "orgMinTypeBulkMemberManagement">;
/**
 * Organization permission configuration type helper
 */
export type OrganizationPermissionConfig = Pick<GoCommonConfig, "orgMinUserTypeCreate" | "orgMinUserTypeCreateChild" | "orgMinUserTypeView" | "orgMinUserTypeListMembers" | "orgMinRoleView" | "orgMinRoleListMembers" | "orgMinUserTypeDelete" | "orgMinUserTypeUpdate" | "orgMinRoleUpdate" | "orgMinRoleDelete" | "orgMinUserTypeInviteMembers" | "orgMinUserTypeAddMembers" | "orgMinRoleInviteMembers" | "orgMinRoleAddMembers" | "orgMinUserTypeRemoveMembers" | "orgMinRoleRemoveMembers" | "orgMinUserTypeUpdateMemberRoles" | "orgMinRoleUpdateMemberRoles" | "orgMinUserTypeManageEmailDomains" | "orgMinRoleManageEmailDomains" | "orgMinUserTypeCancelInvitation" | "orgMinRoleCancelInvitation" | "orgMinUserTypeViewInvitations" | "orgMinRoleViewInvitations" | "orgMinRoleViewInferencePolicy" | "orgMinRoleManageInferencePolicy" | "orgMinRoleChooseInferenceModel" | "defaultOrganizationType" | "orgMinTypeListMembers" | "orgMinTypeInviteMembers" | "orgMinTypeAddMembers" | "orgMinTypeRemoveMembers" | "orgMinTypeUpdateMemberRoles" | "orgMinTypeViewInvitations" | "orgMinTypeCancelInvitation" | "orgMinTypeManageEmailDomains" | "orgMinTypeWorkspaceNavigation" | "orgMinTypeCreateChildOrganizations" | "orgMinTypeBulkMemberManagement">;
/**
 * Organization hierarchy configuration type helper
 */
export type OrganizationHierarchyConfig = Pick<GoCommonConfig, "orgHierarchyMaxDepth" | "orgRoleInheritanceEnabled" | "orgMinRoleCreateChild" | "orgMinRoleSelfJoin" | "orgAutoAddCreatorOnChildCreate">;
/**
 * UI configuration type helper
 */
export type UiConfig = GoCommonConfig["ui"];
//# sourceMappingURL=types.d.ts.map