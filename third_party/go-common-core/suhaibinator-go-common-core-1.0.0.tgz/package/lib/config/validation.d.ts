import { type GoCommonConfig } from "./types";
/**
 * Configuration validation errors
 */
export declare class GoCommonConfigError extends Error {
    constructor(message: string);
}
/**
 * Validates a GoCommon configuration object
 */
export declare function validateGoCommonConfig(config: Partial<GoCommonConfig>): asserts config is GoCommonConfig;
/**
 * Validates cross-feature configuration dependencies
 */
export declare function validateFeatureDependencies(config: Partial<GoCommonConfig>): void;
//# sourceMappingURL=validation.d.ts.map