import { GoCommonConfig, FeatureFlags, ValidationConfig, RateLimitConfig, PermissionConfig, OrganizationPermissionConfig, OrganizationHierarchyConfig, UiConfig, UserDropdownOrganizationFilterConfig, DepthIndexedValue } from "./types";
import { UserType, UserIdentifierType } from "../generated/user";
import { OrganizationRole } from "../generated/organization";
import type { OrganizationMembershipMaskFilter } from "../generated/organization";
/**
 * Utility function to extract feature flags from config
 *
 * @param config - The GoCommon configuration
 * @returns Feature flags object
 */
export declare function getFeatureFlags(config: GoCommonConfig): FeatureFlags;
/**
 * Utility function to extract validation configuration from config
 *
 * @param config - The GoCommon configuration
 * @returns Validation configuration object
 */
export declare function getValidationConfig(config: GoCommonConfig): ValidationConfig;
/**
 * Utility function to extract rate limiting configuration from config
 *
 * @param config - The GoCommon configuration
 * @returns Rate limiting configuration object
 */
export declare function getRateLimitConfig(config: GoCommonConfig): RateLimitConfig;
/**
 * Utility function to extract permission configuration from config
 *
 * @param config - The GoCommon configuration
 * @returns Permission configuration object
 */
export declare function getPermissionConfig(config: GoCommonConfig): PermissionConfig;
/**
 * Utility function to extract organization permission configuration from config
 *
 * @param config - The GoCommon configuration
 * @returns Organization permission configuration object
 */
export declare function getOrganizationPermissionConfig(config: GoCommonConfig): OrganizationPermissionConfig;
/**
 * Utility function to extract organization hierarchy configuration from config
 *
 * @param config - The GoCommon configuration
 * @returns Organization hierarchy configuration object
 */
export declare function getOrganizationHierarchyConfig(config: GoCommonConfig): OrganizationHierarchyConfig;
/**
 * Compute organization depth from lineage array.
 * Lineage contains ancestor organization IDs from root to immediate parent.
 *
 * @param lineage - Array of ancestor organization IDs (root to parent)
 * @returns Depth (0 for root, 1+ for children)
 */
export declare function getOrgDepth(lineage?: bigint[] | number[] | string[]): number;
/**
 * Normalize depth to be within valid range for config arrays.
 * Clamps negative values to 0 and values exceeding maxDepth to maxDepth.
 *
 * @param depth - Raw depth value
 * @param maxDepth - Maximum hierarchy depth from config (optional)
 * @returns Normalized depth value
 */
export declare function normalizeOrgDepth(depth: number, maxDepth?: number): number;
/**
 * Get value at specified depth from a depth-indexed config field.
 * - If value is scalar, returns it for all depths (backward compatible)
 * - If value is array, returns element at depth index
 * - If depth exceeds array length, returns the last element; ordering and
 *   restrictiveness are defined by the application
 * - Empty arrays produce undefined; use getRoleAtDepth/getBoolAtDepth when
 *   a fallback is required
 *
 * @param value - Scalar value or array indexed by depth
 * @param depth - Organization depth (0 for root)
 * @returns Value at the specified depth
 */
export declare function getValueAtDepth<T>(value: DepthIndexedValue<T>, depth: number): T;
/**
 * Get organization role at specified depth from a depth-indexed role config field.
 *
 * @param value - Roles indexed by depth; the last entry applies to deeper levels
 * @param depth - Organization depth (0 for root)
 * @param fallback - Fallback role if value is undefined or empty
 * @returns Role at the specified depth
 */
export declare function getRoleAtDepth(value: OrganizationRole[] | undefined, depth: number, fallback?: OrganizationRole): OrganizationRole;
/**
 * Get boolean at specified depth from a depth-indexed boolean config field.
 *
 * @param value - Boolean array indexed by depth
 * @param depth - Organization depth (0 for root)
 * @param fallback - Fallback value if array is undefined or empty
 * @returns Boolean at the specified depth
 */
export declare function getBoolAtDepth(value: boolean[] | undefined, depth: number, fallback?: boolean): boolean;
/**
 * Compile readable depth-indexed dropdown org filters into packed request masks.
 *
 * Empty or fully unspecified depth entries are omitted from the request.
 * When any filters are present, omitted depths are treated by the backend as blocked.
 */
export declare function compileUserDropdownOrganizationMembershipMaskFilters(filtersByDepth?: UserDropdownOrganizationFilterConfig[]): OrganizationMembershipMaskFilter[];
/**
 * Checks if a specific feature is enabled
 *
 * @param config - The GoCommon configuration
 * @param feature - The feature to check
 * @returns True if the feature is enabled
 */
export declare function isFeatureEnabled(config: GoCommonConfig, feature: keyof FeatureFlags): boolean;
/**
 * Gets all enabled features
 *
 * @param config - The GoCommon configuration
 * @returns Array of enabled feature names
 */
export declare function getEnabledFeatures(config: GoCommonConfig): (keyof FeatureFlags)[];
/**
 * Creates a configuration-aware API client base URL
 *
 * @param config - The GoCommon configuration
 * @returns The complete API base URL with path prefix
 */
export declare function getApiUrl(config: GoCommonConfig): string;
/**
 * Permission checking utilities
 */
/**
 * Checks if a user has permission for admin access
 *
 * @param config - The GoCommon configuration
 * @param userType - The user's type/tier (number or UserType enum)
 * @returns True if user has admin access permission
 */
export declare function hasAdminAccess(config: GoCommonConfig, userType: number): boolean;
/**
 * Checks if a user has permission to list users
 *
 * @param config - The GoCommon configuration
 * @param userType - The user's type/tier
 * @returns True if user can list users
 */
export declare function hasUserListingPermission(config: GoCommonConfig, userType: number): boolean;
/**
 * Checks if a user has permission to view user details
 *
 * @param config - The GoCommon configuration
 * @param userType - The user's type/tier
 * @returns True if user can view user details
 */
export declare function hasUserViewingPermission(config: GoCommonConfig, userType: number): boolean;
/**
 * Checks if a user has permission to ban users
 *
 * @param config - The GoCommon configuration
 * @param userType - The user's type/tier
 * @returns True if user can ban users
 */
export declare function hasUserBanningPermission(config: GoCommonConfig, userType: number): boolean;
/**
 * Checks if a user has permission to modify other users
 *
 * @param config - The GoCommon configuration
 * @param userType - The user's type/tier
 * @returns True if user can modify users
 */
export declare function hasUserModificationPermission(config: GoCommonConfig, userType: number): boolean;
/**
 * Checks if a user has permission to delete other users
 *
 * @param config - The GoCommon configuration
 * @param userType - The user's type/tier
 * @returns True if user can delete users
 */
export declare function hasUserDeletionPermission(config: GoCommonConfig, userType: number): boolean;
/**
 * Checks if a user has permission to change user types
 *
 * @param config - The GoCommon configuration
 * @param userType - The user's type/tier
 * @returns True if user can change user types
 */
export declare function hasUserTypeChangePermission(config: GoCommonConfig, userType: number): boolean;
/**
 * Checks if a user has system access permission
 *
 * @param config - The GoCommon configuration
 * @param userType - The user's type/tier
 * @returns True if user has system access
 */
export declare function hasSystemAccessPermission(config: GoCommonConfig, userType: number): boolean;
/**
 * Checks if a user has content moderation permission
 *
 * @param config - The GoCommon configuration
 * @param userType - The user's type/tier
 * @returns True if user can moderate content
 */
export declare function hasContentModerationPermission(config: GoCommonConfig, userType: number): boolean;
/**
 * Checks if a user has attachment access permission
 *
 * @param config - The GoCommon configuration
 * @param userType - The user's type/tier
 * @returns True if user can manage attachments
 */
export declare function hasAttachmentAccessPermission(config: GoCommonConfig, userType: number): boolean;
/**
 * Checks if a user has analytics access permission
 *
 * @param config - The GoCommon configuration
 * @param userType - The user's type/tier
 * @returns True if user can access analytics
 */
export declare function hasAnalyticsAccessPermission(config: GoCommonConfig, userType: number): boolean;
/**
 * Checks if a user has reporting access permission. Reporting shares the
 * enforced analytics threshold rather than carrying a second unused policy.
 *
 * @param config - The GoCommon configuration
 * @param userType - The user's type/tier
 * @returns True if user can access reporting data
 */
export declare function hasReportingAccessPermission(config: GoCommonConfig, userType: number): boolean;
/**
 * Checks if a user has admin chat channel management permission
 *
 * @param config - The GoCommon configuration
 * @param userType - The user's type/tier
 * @returns True if user can manage chat channels via admin
 */
export declare function hasAdminChatChannelsPermission(config: GoCommonConfig, userType: number): boolean;
/**
 * Checks if a user has careers management permission
 *
 * @param config - The GoCommon configuration
 * @param userType - The user's type/tier
 * @returns True if user can manage careers via admin
 */
export declare function hasCareersManagementPermission(config: GoCommonConfig, userType: number): boolean;
/**
 * Checks if a user has inference viewing permission (routes, rate-limit
 * policies, and attempt/usage reads)
 *
 * @param config - The GoCommon configuration
 * @param userType - The user's type/tier
 * @returns True if user can view the AI control plane via admin
 */
export declare function hasInferenceViewingPermission(config: GoCommonConfig, userType: number): boolean;
/**
 * Checks if a user has inference administration permission (route and
 * rate-limit policy writes)
 *
 * @param config - The GoCommon configuration
 * @param userType - The user's type/tier
 * @returns True if user can update inference routes and rate-limit policies
 */
export declare function hasInferenceAdministrationPermission(config: GoCommonConfig, userType: number): boolean;
/**
 * Generic permission checker
 *
 * @param config - The GoCommon configuration
 * @param userType - The user's type/tier
 * @param operation - The permission operation to check
 * @returns True if user has permission for the operation
 */
export declare function hasPermission(config: GoCommonConfig, userType: number, operation: keyof PermissionConfig): boolean;
/**
 * Type-safe permission checking utilities that accept UserType enum values
 * These provide the same functionality as the number-based functions above,
 * but with strong typing for components using UserType enums
 */
/**
 * Checks if a user has permission for admin access (UserType version)
 *
 * @param config - The GoCommon configuration
 * @param userType - The user's UserType enum value
 * @returns True if user has admin access permission
 */
export declare function hasAdminAccessTyped(config: GoCommonConfig, userType: UserType): boolean;
/**
 * Checks if a user has permission to list users (UserType version)
 *
 * @param config - The GoCommon configuration
 * @param userType - The user's UserType enum value
 * @returns True if user can list users
 */
export declare function hasUserListingPermissionTyped(config: GoCommonConfig, userType: UserType): boolean;
/**
 * Checks if a user has permission to view user details (UserType version)
 *
 * @param config - The GoCommon configuration
 * @param userType - The user's UserType enum value
 * @returns True if user can view user details
 */
export declare function hasUserViewingPermissionTyped(config: GoCommonConfig, userType: UserType): boolean;
/**
 * Checks if a user has permission to ban users (UserType version)
 *
 * @param config - The GoCommon configuration
 * @param userType - The user's UserType enum value
 * @returns True if user can ban users
 */
export declare function hasUserBanningPermissionTyped(config: GoCommonConfig, userType: UserType): boolean;
/**
 * Checks if a user has permission to modify other users (UserType version)
 *
 * @param config - The GoCommon configuration
 * @param userType - The user's UserType enum value
 * @returns True if user can modify users
 */
export declare function hasUserModificationPermissionTyped(config: GoCommonConfig, userType: UserType): boolean;
/**
 * Checks if a user has permission to delete other users (UserType version)
 *
 * @param config - The GoCommon configuration
 * @param userType - The user's UserType enum value
 * @returns True if user can delete users
 */
export declare function hasUserDeletionPermissionTyped(config: GoCommonConfig, userType: UserType): boolean;
/**
 * Checks if a user has permission to change user types (UserType version)
 *
 * @param config - The GoCommon configuration
 * @param userType - The user's UserType enum value
 * @returns True if user can change user types
 */
export declare function hasUserTypeChangePermissionTyped(config: GoCommonConfig, userType: UserType): boolean;
/**
 * Checks if a user has system access permission (UserType version)
 *
 * @param config - The GoCommon configuration
 * @param userType - The user's UserType enum value
 * @returns True if user has system access
 */
export declare function hasSystemAccessPermissionTyped(config: GoCommonConfig, userType: UserType): boolean;
/**
 * Checks if a user has content moderation permission (UserType version)
 *
 * @param config - The GoCommon configuration
 * @param userType - The user's UserType enum value
 * @returns True if user can moderate content
 */
export declare function hasContentModerationPermissionTyped(config: GoCommonConfig, userType: UserType): boolean;
/**
 * Checks if a user has attachment access permission (UserType version)
 *
 * @param config - The GoCommon configuration
 * @param userType - The user's UserType enum value
 * @returns True if user can manage attachments
 */
export declare function hasAttachmentAccessPermissionTyped(config: GoCommonConfig, userType: UserType): boolean;
/**
 * Checks if a user has analytics access permission (UserType version)
 *
 * @param config - The GoCommon configuration
 * @param userType - The user's UserType enum value
 * @returns True if user can access analytics
 */
export declare function hasAnalyticsAccessPermissionTyped(config: GoCommonConfig, userType: UserType): boolean;
/**
 * Checks if a user has reporting access permission (UserType version)
 *
 * @param config - The GoCommon configuration
 * @param userType - The user's UserType enum value
 * @returns True if user can access reporting data
 */
export declare function hasReportingAccessPermissionTyped(config: GoCommonConfig, userType: UserType): boolean;
/**
 * Checks if a user has admin chat channel management permission (UserType version)
 *
 * @param config - The GoCommon configuration
 * @param userType - The user's UserType enum value
 * @returns True if user can manage chat channels via admin
 */
export declare function hasAdminChatChannelsPermissionTyped(config: GoCommonConfig, userType: UserType): boolean;
/**
 * Checks if a user has careers management permission (UserType version)
 *
 * @param config - The GoCommon configuration
 * @param userType - The user's UserType enum value
 * @returns True if user can manage careers via admin
 */
export declare function hasCareersManagementPermissionTyped(config: GoCommonConfig, userType: UserType): boolean;
/**
 * Checks if a user has inference viewing permission (UserType version)
 *
 * @param config - The GoCommon configuration
 * @param userType - The user's UserType enum value
 * @returns True if user can view the AI control plane via admin
 */
export declare function hasInferenceViewingPermissionTyped(config: GoCommonConfig, userType: UserType): boolean;
/**
 * Checks if a user has inference administration permission (UserType version)
 *
 * @param config - The GoCommon configuration
 * @param userType - The user's UserType enum value
 * @returns True if user can update inference routes and rate-limit policies
 */
export declare function hasInferenceAdministrationPermissionTyped(config: GoCommonConfig, userType: UserType): boolean;
/**
 * Generic permission checker (UserType version)
 *
 * @param config - The GoCommon configuration
 * @param userType - The user's UserType enum value
 * @param operation - The permission operation to check
 * @returns True if user has permission for the operation
 */
export declare function hasPermissionTyped(config: GoCommonConfig, userType: UserType, operation: keyof PermissionConfig): boolean;
/**
 * User identifier configuration utilities
 */
/**
 * Gets user identifier configuration from environment variables or config
 *
 * @param config - Optional GoCommon configuration object
 * @returns User identifier configuration
 */
export declare function getUserIdentifierConfig(config?: GoCommonConfig): {
    privatePrimaryUserIdentifier: UserIdentifierType;
    privateSecondaryUserIdentifier?: UserIdentifierType;
};
/**
 * UI configuration utilities
 */
/**
 * Gets UI configuration from config
 *
 * @param config - The GoCommon configuration
 * @returns UI configuration object
 */
export declare function getUiConfig(config: GoCommonConfig): UiConfig;
/**
 * Type definition for user data that can be displayed
 */
type UserDisplayData = {
    id?: string | bigint;
    Email?: string;
    email?: string;
    username?: string;
    name?: string;
    firstName?: string;
    lastName?: string;
} | null | undefined;
/**
 * Gets user display text based on UI configuration
 *
 * @param config - The GoCommon configuration
 * @param user - The user object
 * @returns Display text for the user
 */
export declare function getUserDisplayText(config: GoCommonConfig, user: UserDisplayData): string;
/**
 * Gets avatar fallback text based on UI configuration
 *
 * @param config - The GoCommon configuration
 * @param user - The user object
 * @returns Avatar fallback text (1 or 2 characters)
 */
export declare function getAvatarFallbackText(config: GoCommonConfig, user: UserDisplayData): string;
export type { GoCommonConfig, PartialGoCommonConfig, FeatureFlags, ValidationConfig, RateLimitConfig, PermissionConfig, OrganizationPermissionConfig, OrganizationRoleConfig, OrganizationRoleDisplayConfig, OrganizationRoleGroupLabels, UserDropdownOrganizationFilterConfig, UiConfig, } from "./types";
export { DEFAULT_GO_COMMON_CONFIG, DEFAULT_PHONE_NUMBER_REGION, DEFAULT_CHAT_CHANNEL_NAME_MAX_LENGTH, DEFAULT_CHAT_CHANNEL_DESCRIPTION_MAX_LENGTH, DEFAULT_PASSWORD_SPECIAL_CHARS, UserDisplayType, isDepthIndexed, type DepthIndexedValue, type OrganizationHierarchyConfig, } from "./types";
export { GoCommonConfigError, validateGoCommonConfig, validateFeatureDependencies, } from "./validation";
/** UI hint only; the service reloads the actor and enforces this permission. */
export declare function hasInferenceModelOverridePermission(config: GoCommonConfig, userType: number): boolean;
export declare function hasInferenceModelOverridePermissionTyped(config: GoCommonConfig, userType: UserType): boolean;
//# sourceMappingURL=index.d.ts.map