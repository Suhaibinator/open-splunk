/**
 * Process-wide "a request got a 401" signal.
 *
 * `ProtobufTransport` raises it on every 401 it decodes, so anything built on
 * the transport — `GoCommonClient` and application-owned protobuf clients alike
 * — reports without per-client wiring. `AuthProvider` subscribes and re-checks
 * the session, which is how an expired HttpOnly session cookie turns into a
 * logged-out UI instead of a tab that keeps failing every request.
 *
 * A 401 is a hypothesis, not a verdict: it can be a permission answer on one
 * endpoint while the session is perfectly alive. Subscribers must verify
 * before acting on it.
 *
 * The registry is browser-only. On a server this module is shared by every
 * concurrent request, so subscribing there is a no-op and reporting fans out to
 * nobody; SSR code handles its own 401s in the request it is serving.
 */
type UnauthorizedResponseListener = () => void;
/** Subscribe to unauthorized-response signals; returns the unsubscribe function. */
export declare function subscribeUnauthorizedResponse(listener: UnauthorizedResponseListener): () => void;
/**
 * Report that a request got a 401. The transport calls this *before* it throws
 * the `ApiError`, so a listener must never throw — it would replace the 401 the
 * caller is about to see. Each listener is isolated for that reason.
 */
export declare function reportUnauthorizedResponse(): void;
/** Test hook: drop every listener so one test's subscription cannot leak into the next. */
export declare function resetUnauthorizedResponseListenersForTests(): void;
export {};
//# sourceMappingURL=unauthorized-response.d.ts.map