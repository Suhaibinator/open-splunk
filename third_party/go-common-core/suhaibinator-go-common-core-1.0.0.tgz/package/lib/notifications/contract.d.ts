/**
 * Notification activity-scope grammar and native key formats.
 *
 * Mirrors `pkg/common_util/notificationkey` and is tested against its shared
 * fixtures (`pkg/common_util/notificationkey/testdata/contracts.json`). The
 * formats are documented once in `docs/backend/external/notification-contracts.md`.
 * Activity scopes are exact-match visibility hints, not realtime topics or
 * authorization grants.
 */
export declare const MAX_ACTIVITY_SCOPE_LENGTH = 128;
/** The server rejects activity updates carrying more scopes than this. */
export declare const MAX_ACTIVITY_SCOPES_PER_UPDATE = 8;
/**
 * Identifies a visible chat timeline (`parentMessageId = 0n`) or thread. Both
 * unread-chat and approval notifications use this scope. Throws for a zero or
 * out-of-range ID.
 */
export declare function chatActivityScope(channelId: bigint, parentMessageId?: bigint): string;
/**
 * Validates a nonempty scope without normalizing it. Named segments match
 * `[a-z][a-z0-9_-]*`; numeric segments are canonical unsigned 64-bit decimals.
 * The `chat` namespace additionally requires exactly a positive channel ID and
 * a parent ID.
 */
export declare function isValidActivityScope(scope: string): boolean;
//# sourceMappingURL=contract.d.ts.map