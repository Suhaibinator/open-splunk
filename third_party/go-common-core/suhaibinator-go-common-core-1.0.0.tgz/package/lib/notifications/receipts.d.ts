import type { NotificationReadReceipt } from "../generated/notification";
/** The server rejects a mark-read request carrying more receipts than this. */
export declare const MAX_NOTIFICATION_READ_RECEIPTS = 100;
/**
 * Deduplicates read receipts by notification ID, keeping the highest revision
 * (reading a newer revision covers every older one). The returned map iterates
 * IDs in first-seen order.
 */
export declare function latestNotificationReceiptRevisions(receipts: Iterable<NotificationReadReceipt>): Map<bigint, bigint>;
/**
 * Splits read receipts into request-sized batches. Receipts are deduplicated by
 * notification ID, keeping the highest revision (the server rejects duplicate
 * IDs, and reading a newer revision covers every older one). First-seen order
 * is preserved. Returns no batches for an empty input.
 */
export declare function chunkNotificationReceipts(receipts: readonly NotificationReadReceipt[], max?: number): NotificationReadReceipt[][];
//# sourceMappingURL=receipts.d.ts.map