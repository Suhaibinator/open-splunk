import type { TransportHeadersProvider } from "./transport";
export type HeaderReader = Pick<Headers, "get">;
export type ForwardedHeaders = {
    "CF-Connecting-IP"?: string;
    "X-Forwarded-For"?: string;
};
export interface NextRequestHeadersProviderOptions {
    /** Session cookie to forward. Defaults to go-common's `auth_token`; false disables it. */
    sessionCookieName?: string | false;
    /** Explicitly maps trusted inbound request headers to outbound API headers. */
    mapRequestHeaders?: (headers: HeaderReader) => HeadersInit | Promise<HeadersInit>;
}
/**
 * Maps CF-Connecting-IP, falling back to X-Real-IP, to downstream API headers.
 * The caller must establish that its ingress supplies trusted values; this
 * helper does not authenticate them. Raw X-Forwarded-For is ignored because
 * its leftmost values can be client-controlled.
 */
export declare function buildSSRForwardedHeaders(headers: HeaderReader): ForwardedHeaders;
/**
 * Creates a per-request Next.js headers provider for ProtobufTransport and
 * GoCommonClient. The returned provider is safe to keep on a module singleton:
 * it resolves the active Next request context anew for every invocation.
 */
export declare function createNextRequestHeadersProvider(options?: NextRequestHeadersProviderOptions): TransportHeadersProvider;
//# sourceMappingURL=next.d.ts.map