/**
 * go-common API Client
 *
 * A fully-featured TypeScript client for interacting with go-common backends.
 * Handles protobuf serialization/deserialization, authentication, and error handling.
 */
import { go_common } from "./index";
import { Duration } from "./generated/google/protobuf/duration";
import { type HttpClient, type ProtobufTransportConfig } from "./transport";
export { ApiError } from "./transport";
/**
 * Configuration options for the API client
 */
export interface ClientConfig extends ProtobufTransportConfig {
    /**
     * Channel IDs sent in one `participants.listBatch` request; larger inputs are
     * split into sequential requests. Keep it at or below the server's hot
     * `chat_max_list_participants_batch_channel_ids` (default 50): the server
     * rejects a larger batch and reports no maximum the client could adopt.
     */
    chatMaxListParticipantsBatchChannelIds?: number;
    /**
     * Message IDs sent in one inference-summary batch request; larger inputs are
     * split into sequential requests. Keep it at or below the server's hot
     * `chat_max_batch_get_messages` (default 200): the server rejects a larger
     * batch and reports no maximum the client could adopt.
     */
    chatMaxInferenceSummaryBatchMessageIds?: number;
}
/** Inputs for `auth.createOAuthState`. */
export interface CreateOAuthStateOptions {
    /** Slug of a provider returned by `auth.listOAuthProviders`. */
    providerSlug: string;
    /** Local frontend destination after sign-in. */
    returnUrl: string;
    /**
     * Exact redirect URI registered with the provider: the frontend callback
     * page, or for form_post providers the absolute backend relay URL
     * (`getApiUrl(API_PATHS.AUTH.OAUTH.FORM_POST)`).
     */
    redirectUri: string;
    /** Frontend callback page the form_post relay redirects to; form_post providers only. */
    frontendCallbackUrl?: string;
}
/** Inputs for `auth.oauthCallback`, read from the callback page's query. */
export interface OAuthCallbackOptions {
    code: string;
    state: string;
}
export interface PaginationOptions {
    page: number;
    limit: number;
    cursor?: bigint;
    includeTotalCount?: boolean;
}
export interface OptionalPaginationOptions {
    page?: number;
    limit?: number;
    cursor?: bigint;
    includeTotalCount?: boolean;
}
/**
 * A protobuf list request whose pagination may leave the page and page size to
 * the server. An omitted page or limit is sent as 0, which the server replaces
 * with page 1 and its configured default_pagination_limit.
 */
export type ListRequestWithOptionalPagination<T extends {
    pagination?: unknown;
}> = Omit<T, "pagination"> & {
    pagination?: OptionalPaginationOptions;
};
export interface AdminUserListOptions {
    pagination?: OptionalPaginationOptions;
    search?: string;
    userTypeFilter?: go_common.v1.UserType;
    bannedFilter?: boolean;
    emailVerifiedFilter?: boolean;
    isBotFilter?: boolean;
    registeredFrom?: Date;
    registeredTo?: Date;
    sortBy?: go_common.v1.AdminListUsersSortBy;
    sort?: {
        sortDesc?: boolean;
    };
}
export interface AdminTokensSortOptions {
    sortBy: go_common.v1.AdminListTokensSortBy;
    sortDesc?: boolean;
}
export interface AdminTokenListOptions {
    pagination?: OptionalPaginationOptions;
    userIdFilter?: bigint;
    tokenTypeFilter?: go_common.v1.TokenType;
    statusFilter?: go_common.v1.TokenStatus;
    search?: string;
    rawTokenFilter?: string;
    fromDate?: Date;
    toDate?: Date;
    sortBy?: go_common.v1.AdminListTokensSortBy;
    sort?: {
        sortDesc?: boolean;
    };
}
/**
 * Options for `chat.agentRuns.getStatus`. `parentMessageIds` uses the thread
 * convention where `0n` is the main timeline; omitted or empty reads the main
 * timeline.
 */
export interface AgentRunStatusRequestOptions {
    parentMessageIds?: readonly bigint[];
    historyLimit?: number;
    includeDelegatedThreads?: boolean;
}
/** A protobuf request whose `K` fields may be omitted; `fromPartial` sends their zero value. */
type RequestWithOptional<T, K extends keyof T> = Omit<T, K> & Partial<Pick<T, K>>;
/**
 * Input for `admin.inference.updateOperationModels`. `expectedVersion` is the list version last
 * read; a stale version is rejected. An absent `sessionAction` keeps affected sessions, and
 * `moveToModelId` is set only with the MOVE action.
 */
export type UpdateInferenceOperationModelsInput = RequestWithOptional<go_common.v1.UpdateInferenceOperationModelsRequest, "sessionAction">;
/** Input for `organizations.inferencePolicy.update`. */
export type UpdateOrganizationInferencePolicyInput = go_common.v1.UpdateOrganizationInferencePolicyRequest;
/**
 * Input for `organizations.inferencePolicy.updateOperation`. Empty `inferenceModelIds` means the
 * whole site list; an absent `defaultModelId` leaves the organization default unset. An absent
 * `memberRetarget` (members may move their own running sessions, valid only under the
 * `ORG_DECIDES` gate) means false.
 */
export type UpdateOrganizationInferenceOperationPolicyInput = RequestWithOptional<go_common.v1.UpdateOrganizationInferenceOperationPolicyRequest, "sessionAction" | "memberRetarget">;
/** Input for `organizations.inferencePolicy.listModelChoices`. */
export type ListInferenceModelChoicesInput = go_common.v1.ListInferenceModelChoicesRequest;
/**
 * Input for `chat.agentSessions.retargetInference`. An absent `api` inherits the operation
 * route's API.
 */
export type RetargetInferenceSessionInput = RequestWithOptional<go_common.v1.RetargetInferenceSessionRequest, "siteOverride">;
/** Input for `chat.channels.fork`. Absent optional fields send their zero value. */
export type ForkChannelInput = RequestWithOptional<go_common.v1.ForkChannelRequest, "memberUserIds" | "keepOrgAccess" | "keepContext" | "clientRequestId">;
/** Input for `chat.agentSessions.retargetInferenceBulk`. */
export type RetargetInferenceSessionsInput = RequestWithOptional<go_common.v1.RetargetInferenceSessionsRequest, "siteOverride">;
/**
 * Main API client for go-common
 */
export declare class GoCommonClient {
    private readonly transport;
    private readonly maxListParticipantsBatchChannelIds;
    private readonly maxInferenceSummaryBatchMessageIds;
    constructor(config: ClientConfig, httpClient?: HttpClient);
    /**
     * Authentication API
     */
    auth: {
        /**
         * Register a new user with email and password, and optional username and name.
         *
         * `options.frontendOrigin` selects which frontend origin the verification email
         * links back to when the backend is configured with multiple allowed origins
         * (`AllowedFrontendOrigins`). Omit it to use the backend's default frontend URL.
         * The origin must be in the backend allowlist or the request is rejected.
         */
        register: (email: string, password: string, username?: string, firstName?: string, lastName?: string, options?: {
            frontendOrigin?: string;
        }) => Promise<go_common.v1.EmailRegistrationResponse>;
        /**
         * Login with email and password, with optional OTP code for 2FA.
         *
         * After valid credentials, an OTP-enabled account with no code returns
         * `otpRequired = true` without creating a session. An invalid supplied code
         * rejects with an API error. Successful login sets a server-issued HttpOnly
         * cookie; this client never stores an auth token.
         */
        login: (email: string, password: string, otpCode?: string) => Promise<go_common.v1.EmailAuthResponse>;
        /**
         * OTP/TOTP (2FA) management
         */
        otp: {
            /**
             * Initiate OTP setup by generating a new TOTP secret and QR code URL.
             */
            setup: (currentPassword: string) => Promise<go_common.v1.SetupOTPResponse>;
            /**
             * Verify OTP setup by submitting a 6-digit code from the authenticator app.
             */
            verifySetup: (otpCode: string, currentPassword: string) => Promise<go_common.v1.VerifyOTPSetupResponse>;
            /**
             * Disable OTP (2FA) by confirming the current password.
             */
            disable: (currentPassword: string) => Promise<go_common.v1.DisableOTPResponse>;
        };
        /**
         * Change password for the current user
         */
        changePassword: (oldPassword: string, newPassword: string) => Promise<void>;
        /** Accept an account invitation without creating a session. */
        acceptInvitation: (token: string, password: string) => Promise<void>;
        /**
         * Request password reset.
         *
         * `options.frontendOrigin` selects which frontend origin the reset email links
         * back to when the backend is configured with multiple allowed origins
         * (`AllowedFrontendOrigins`). Omit it to use the backend's default frontend URL.
         * The origin must be in the backend allowlist or the request is rejected.
         */
        resetPassword: (email: string, options?: {
            frontendOrigin?: string;
        }) => Promise<void>;
        /**
         * Complete email verification
         */
        verifyEmail: (verificationCode: string) => Promise<void>;
        /**
         * Complete password reset
         */
        completePasswordReset: (verificationCode: string, newPassword: string) => Promise<void>;
        /**
         * List the OAuth providers the server currently offers for sign-in.
         */
        listOAuthProviders: (signal?: AbortSignal) => Promise<go_common.v1.ListOAuthProvidersResponse>;
        /**
         * Create the server-issued, browser-bound state for an OAuth sign-in. The
         * response carries the complete provider authorization URL to navigate to;
         * the state is opaque to the client.
         */
        createOAuthState: (options: CreateOAuthStateOptions) => Promise<go_common.v1.OAuthStateResponse>;
        /**
         * Exchange the provider's authorization code. The response names the
         * provider and the server-validated return URL recorded in the state.
         */
        oauthCallback: (options: OAuthCallbackOptions) => Promise<go_common.v1.OAuthTokenResponse>;
        /**
         * Logout current session or all sessions
         */
        logout: (logoutEverywhere?: boolean) => Promise<void>;
        /**
         * Add password authentication to OAuth account
         */
        addPassword: (password: string, confirmPassword: string) => Promise<void>;
        /**
         * Get available authentication methods
         */
        getMethods: () => Promise<go_common.v1.GetAuthMethodsResponse>;
        /**
         * Authenticated session management
         */
        sessions: {
            /**
             * List active sessions for the current user.
             */
            list: (pagination?: OptionalPaginationOptions) => Promise<go_common.v1.ListActiveSessionsResponse>;
            /**
             * Revoke a specific active session for the current user.
             */
            revoke: (sessionId: string) => Promise<go_common.v1.RevokeSessionResponse>;
            /**
             * Revoke every session except the current one.
             */
            revokeOther: () => Promise<go_common.v1.RevokeOtherSessionsResponse>;
        };
        /**
         * Check if a username is available for registration
         */
        checkUsername: (username: string) => Promise<go_common.v1.CheckUsernameAvailabilityResponse>;
        /**
         * Phone verification API
         */
        phone: {
            /**
             * Send phone verification OTP
             */
            sendOTP: (phoneNumber: string) => Promise<void>;
            /**
             * Verify phone OTP code
             */
            verifyOTP: (otpCode: string) => Promise<void>;
            /**
             * Resend phone verification OTP
             */
            resendOTP: () => Promise<void>;
        };
    };
    /**
     * User API
     */
    user: {
        getProfile: () => Promise<go_common.v1.GetCurrentUserResponse>;
        getSettings: () => Promise<go_common.v1.UserSettings>;
        updateSettings: (settings: go_common.v1.UpdateUserSettingsRequest) => Promise<go_common.v1.UserSettings>;
        updateLanguage: (language: go_common.v1.Language) => Promise<go_common.v1.UserSettings>;
        removePhoneNumber: () => Promise<go_common.v1.RemovePhoneNumberResponse>;
        updateUsername: (username: string) => Promise<go_common.v1.UpdateUsernameResponse>;
        searchPublicUsers: (request: go_common.v1.SearchPublicUsersRequest) => Promise<go_common.v1.SearchPublicUsersResponse>;
        profilePicture: {
            createUploadUrl: (filename: string, contentType?: string) => Promise<go_common.v1.CreateProfilePictureUploadURLResponse>;
            uploadFile: (uploadUrl: string, formData: Record<string, string>, file: File | Blob) => Promise<void>;
            remove: () => Promise<void>;
        };
        invitations: {
            list: (pagination?: OptionalPaginationOptions) => Promise<go_common.v1.ListPendingInvitationsResponse>;
            accept: (invitationId: bigint) => Promise<go_common.v1.AcceptInvitationResponse>;
            decline: (invitationId: bigint) => Promise<go_common.v1.DeclineInvitationResponse>;
        };
    };
    /**
     * Attachments API
     */
    attachments: {
        /**
         * Finalize uploaded attachments after direct storage upload.
         * This verifies ownership and triggers immediate processing.
         */
        finalizeUploads: (attachmentIds: bigint[]) => Promise<go_common.v1.FinalizeAttachmentsResponse>;
    };
    /**
     * Admin API (requires tier 2+ admin access)
     */
    admin: {
        /**
         * User management
         */
        users: {
            /**
             * List users with pagination and filtering
             */
            list: (options?: AdminUserListOptions) => Promise<go_common.v1.AdminListUsersResponse>;
            /**
             * Get specific user details
             */
            get: (userId: bigint) => Promise<go_common.v1.AdminGetUserResponse>;
            /**
             * Create a human or bot account using the requested authentication setup.
             */
            create: (options: go_common.v1.AdminCreateUserRequest) => Promise<go_common.v1.AdminCreateUserResponse>;
            resendInvitation: (userId: bigint, options?: {
                frontendOrigin?: string;
            }) => Promise<void>;
            /**
             * Ban or unban a user
             */
            ban: (userId: bigint, banned: boolean, reason?: string) => Promise<go_common.v1.AdminBanUserResponse>;
            /**
             * Change user type/role
             */
            changeType: (userId: bigint, newUserType: go_common.v1.UserType, reason?: string) => Promise<go_common.v1.AdminChangeUserTypeResponse>;
            /**
             * Change username
             */
            changeUsername: (userId: bigint, newUsername: string, reason: string) => Promise<go_common.v1.AdminChangeUsernameResponse>;
            /**
             * List username change history
             */
            listUsernameChangeHistory: (params?: {
                pagination?: OptionalPaginationOptions;
                targetUserIdFilter?: bigint;
                actorUserIdFilter?: bigint;
                usernameFilter?: string;
                fromTime?: Date;
                toTime?: Date;
                sortBy?: go_common.v1.AdminListUsernameChangeHistorySortBy;
                sort?: {
                    sortDesc?: boolean;
                };
            }) => Promise<go_common.v1.AdminListUsernameChangeHistoryResponse>;
            /**
             * Delete user account permanently
             */
            delete: (userId: bigint, reason: string, deleteAttachments?: boolean) => Promise<go_common.v1.AdminDeleteUserResponse>;
            /**
             * Revoke all sessions for a user
             */
            revokeSessions: (userId: bigint, reason?: string) => Promise<go_common.v1.AdminRevokeUserSessionsResponse>;
            /**
             * Create a profile picture upload URL for a user
             */
            createProfilePictureUploadUrl: (userId: bigint, filename: string, contentType?: string) => Promise<go_common.v1.AdminCreateUserProfilePictureUploadURLResponse>;
            /**
             * Clear a user's profile picture
             */
            clearProfilePicture: (userId: bigint) => Promise<go_common.v1.AdminClearUserProfilePictureResponse>;
        };
        /**
         * Organization management (admin only)
         */
        organizations: {
            /**
             * Admin create organization
             * @param parentOrganizationId - Optional parent organization ID for creating child organizations
             */
            create: (name: string, slug: string, description?: string, avatarUrl?: string, parentOrganizationId?: bigint, organizationType?: go_common.v1.OrganizationType) => Promise<go_common.v1.AdminCreateOrganizationResponse>;
            /**
             * Read a complete-access descendant page, excluding the root organization.
             * Omit `limit` (sent as 0) to let the server use max_pagination_limit;
             * larger values are clamped to it.
             */
            getDeletionImpact: (organizationId: bigint, afterOrganizationId?: bigint, limit?: number, signal?: AbortSignal) => Promise<go_common.v1.AdminGetOrganizationDeletionImpactResponse>;
            /**
             * Admin list all organizations
             */
            listAll: (pagination?: OptionalPaginationOptions, sort?: {
                sortBy: go_common.v1.AdminListAllOrganizationsSortBy;
                sortDesc?: boolean;
            }, filter?: {
                search: string;
            }, organizationTypeFilter?: go_common.v1.OrganizationType, parentOrganizationIdFilter?: bigint, depthFilter?: number, signal?: AbortSignal) => Promise<go_common.v1.AdminListAllOrganizationsResponse>;
            /**
             * Admin list paginated organization parent options.
             *
             * The option filter searches parent names and slugs. The table filter and
             * organization type filter constrain which organizations can contribute
             * a direct parent option.
             */
            listParentOptions: (pagination?: OptionalPaginationOptions, filter?: {
                search: string;
            }, tableFilter?: {
                search: string;
            }, organizationTypeFilter?: go_common.v1.OrganizationType, signal?: AbortSignal) => Promise<go_common.v1.AdminListOrganizationParentOptionsResponse>;
            /**
             * Admin organization filter metadata
             */
            listFilterMetadata: (filter?: {
                search: string;
            }, organizationTypeFilter?: go_common.v1.OrganizationType) => Promise<go_common.v1.AdminListAllOrganizationsFilterMetadataResponse>;
            /**
             * Admin change organization type.
             */
            changeType: (organizationId: bigint, newOrganizationType: go_common.v1.OrganizationType, reason: string) => Promise<go_common.v1.AdminChangeOrganizationTypeResponse>;
            /**
             * Admin add user to organization (direct, no consent required)
             */
            addMember: (organizationId: bigint, userId: bigint, role: go_common.v1.OrganizationRole) => Promise<go_common.v1.AdminAddUserToOrganizationResponse>;
            /**
             * Admin add user to organization by identifier (direct add if exists, auto-add if not)
             */
            addMemberByIdentifier: (organizationId: bigint, identifierType: go_common.v1.UserIdentifierType, identifier: string, role: go_common.v1.OrganizationRole) => Promise<go_common.v1.AdminAddUserToOrganizationByIdentifierResponse>;
            /**
             * Admin update user role in organization.
             */
            updateMemberRole: (organizationId: bigint, userId: bigint, role: go_common.v1.OrganizationRole) => Promise<go_common.v1.AdminUpdateUserRoleInOrganizationResponse>;
            /**
             * Admin get detailed information about a specific organization member.
             */
            getMember: (organizationId: bigint, userId: bigint) => Promise<go_common.v1.AdminGetOrganizationMemberResponse>;
            /**
             * Admin organization email domain management
             */
            emailDomains: {
                /**
                 * Admin create organization email domain
                 */
                create: (organizationId: bigint, domain: string) => Promise<go_common.v1.AdminCreateOrganizationEmailDomainResponse>;
                /**
                 * Admin delete organization email domain
                 */
                delete: (organizationEmailDomainId: bigint) => Promise<void>;
                /**
                 * Admin list organization email domains
                 */
                list: (organizationId: bigint, pagination?: OptionalPaginationOptions) => Promise<go_common.v1.AdminListOrganizationEmailDomainsResponse>;
            };
        };
        /**
         * Contact message management
         */
        contactMessages: {
            /**
             * List contact messages with filtering
             */
            list: (pagination?: OptionalPaginationOptions, statusFilter?: string, emailFilter?: string, sort?: {
                sortBy: go_common.v1.AdminListContactMessagesSortBy;
                sortDesc?: boolean;
            }) => Promise<go_common.v1.AdminListContactMessagesResponse>;
            /**
             * Get specific contact message details
             */
            get: (messageId: bigint) => Promise<go_common.v1.AdminGetContactMessageResponse>;
            /**
             * Get contact message by reference ID
             */
            getByReference: (referenceId: string) => Promise<go_common.v1.AdminGetContactMessageByReferenceIDResponse>;
        };
        /**
         * Careers management
         */
        careers: {
            jobs: {
                list: (requestPayload?: ListRequestWithOptionalPagination<go_common.v1.AdminListCareerJobPostingsRequest>) => Promise<go_common.v1.AdminListCareerJobPostingsResponse>;
                get: (jobPostingId: bigint) => Promise<go_common.v1.AdminGetCareerJobPostingResponse>;
                create: (requestPayload: go_common.v1.AdminCreateCareerJobPostingRequest) => Promise<go_common.v1.AdminCreateCareerJobPostingResponse>;
                update: (requestPayload: go_common.v1.AdminUpdateCareerJobPostingRequest) => Promise<go_common.v1.AdminUpdateCareerJobPostingResponse>;
                updateStatus: (jobPostingId: bigint, status: go_common.v1.CareerJobPostingStatus) => Promise<go_common.v1.AdminTransitionCareerJobPostingStatusResponse>;
            };
            applications: {
                list: (requestPayload?: ListRequestWithOptionalPagination<go_common.v1.AdminListCareerApplicationsRequest>) => Promise<go_common.v1.AdminListCareerApplicationsResponse>;
                get: (applicationId: bigint) => Promise<go_common.v1.AdminGetCareerApplicationResponse>;
                getByReferenceId: (referenceId: string) => Promise<go_common.v1.AdminGetCareerApplicationByReferenceIDResponse>;
                updateStatus: (applicationId: bigint, status: go_common.v1.CareerApplicationStatus, adminNotes?: string) => Promise<go_common.v1.AdminUpdateCareerApplicationStatusResponse>;
            };
        };
        /**
         * Attachment management
         */
        attachments: {
            /**
             * List attachments with filtering
             */
            list: (pagination?: OptionalPaginationOptions, userIdFilter?: bigint, statusFilter?: string, contentTypeFilter?: string, minSizeBytes?: bigint, maxSizeBytes?: bigint, sort?: {
                sortBy: go_common.v1.AdminListAttachmentsSortBy;
                sortDesc?: boolean;
            }) => Promise<go_common.v1.AdminListAttachmentsResponse>;
            /**
             * Update an attachment's moderation status (e.g. "vetted" or "rejected").
             */
            updateStatus: (attachmentId: bigint, status: string, validationDetails: string) => Promise<go_common.v1.AdminUpdateAttachmentStatusResponse>;
            /**
             * Delete an attachment, optionally removing the underlying stored files.
             */
            delete: (attachmentId: bigint, deleteFiles: boolean, reason: string) => Promise<go_common.v1.AdminDeleteAttachmentResponse>;
        };
        /**
         * Analytics
         */
        analytics: {
            /**
             * Get user analytics
             */
            users: (groupBy?: string, filter?: {
                fromDate?: Date;
                toDate?: Date;
                search?: string;
            }, signal?: AbortSignal) => Promise<go_common.v1.AdminUserAnalyticsResponse>;
            /**
             * Get storage analytics
             */
            storage: (filter?: {
                fromDate?: Date;
                toDate?: Date;
            }, groupBy?: string, signal?: AbortSignal) => Promise<go_common.v1.AdminStorageAnalyticsResponse>;
        };
        /**
         * Token management
         */
        tokens: {
            /**
             * List authentication tokens
             */
            list: (options?: AdminTokenListOptions) => Promise<go_common.v1.AdminListTokensResponse>;
        };
        /**
         * System information
         */
        system: {
            /**
             * Get system statistics
             */
            stats: () => Promise<go_common.v1.AdminSystemStatsResponse>;
        };
        /**
         * Inference model catalog management
         */
        inferenceProviders: {
            list: (signal?: AbortSignal) => Promise<go_common.v1.ListAdminInferenceProvidersResponse>;
        };
        inferenceModels: {
            /**
             * List inference models with optional pagination.
             */
            list: (pagination?: OptionalPaginationOptions, signal?: AbortSignal) => Promise<go_common.v1.ListAdminInferenceModelsResponse>;
            /**
             * Create a new inference model
             */
            create: (providerId: string, providerModelId: string, displayName: string, active?: boolean) => Promise<go_common.v1.CreateAdminInferenceModelResponse>;
            /**
             * Update an inference model
             */
            update: (inferenceModelId: bigint, fields: {
                providerId?: string;
                providerModelId?: string;
                displayName?: string;
                active?: boolean;
            }) => Promise<go_common.v1.UpdateAdminInferenceModelResponse>;
            /**
             * Delete an inference model
             */
            delete: (inferenceModelId: bigint) => Promise<go_common.v1.DeleteAdminInferenceModelResponse>;
        };
        /**
         * AI control-plane administration: operation routes, model rate-limit
         * policies, and the inference attempt/usage ledger. Route, rate-limit, attempt, and usage reads require the
         * inference-viewing permission; selectable-model reads require model-override
         * permission. Updates require inference administration.
         * Operation identity on the wire is the importing application's numeric
         * proto enum value. Responses also carry symbolic and display names.
         */
        inference: {
            /**
             * List every registered operation with its route (route is absent when
             * the operation has no route configured yet), ordered by sort order and
             * enum value.
             */
            listRoutes: () => Promise<go_common.v1.ListInferenceRoutesResponse>;
            /**
             * List the models the viewer may select for one request or run, for
             * pickers that build a request-scoped model selection. Requires the
             * inference-model-override permission (not inference viewing). Passing
             * the operation adds its routed default to the response.
             */
            listSelectableModels: (options?: {
                operation?: number;
            }, signal?: AbortSignal) => Promise<go_common.v1.ListSelectableInferenceModelsResponse>;
            /**
             * Replace the mutable route fields for one operation. An absent
             * temperature clears the stored temperature.
             */
            updateRoute: (update: {
                operation: number;
                inferenceModelId: bigint;
                totalTimeout: Duration;
                maxAttempts: number;
                initialBackoff: Duration;
                maxBackoff: Duration;
                temperature?: number;
                api?: go_common.v1.InferenceAPI;
            }) => Promise<go_common.v1.UpdateInferenceRouteResponse>;
            /**
             * List every configured model rate-limit policy ordered by inference
             * model id.
             */
            listRateLimitPolicies: () => Promise<go_common.v1.ListInferenceRateLimitPoliciesResponse>;
            /**
             * Replace one model's optional, all-or-none request and token buckets.
             * An absent bucket clears that limit.
             */
            updateRateLimitPolicy: (inferenceModelId: bigint, buckets: {
                requestBucket?: go_common.v1.InferenceRateLimitBucket;
                tokenBucket?: go_common.v1.InferenceRateLimitBucket;
            }) => Promise<go_common.v1.UpdateInferenceRateLimitPolicyResponse>;
            /**
             * Filtered, paginated attempt-ledger read. All filter fields are
             * optional; metadata containment accepts only registered/allowlisted
             * keys.
             */
            listAttempts: (filter?: Partial<go_common.v1.InferenceAttemptFilter>) => Promise<go_common.v1.ListInferenceAttemptsResponse>;
            /**
             * Load one attempt row by ledger id.
             */
            getAttempt: (id: bigint) => Promise<go_common.v1.GetInferenceAttemptResponse>;
            /**
             * Aggregate rollup plus provider/operation/status breakdown for a
             * filtered attempt set.
             */
            getUsage: (filter?: Partial<go_common.v1.InferenceAttemptFilter>) => Promise<go_common.v1.GetInferenceUsageResponse>;
            /**
             * One operation's site model list with its version and organization-choice gate.
             * Requires inference viewing.
             */
            getOperationModels: (operation: number, signal?: AbortSignal) => Promise<go_common.v1.GetInferenceOperationModelsResponse>;
            /**
             * Replace one operation's site model list. Requires inference administration.
             * `expectedVersion` gives optimistic concurrency: a stale version is rejected. A dry run
             * returns the impact preview without saving. `sessionAction` decides what happens to
             * sessions on removed models (absent keeps them); `moveToModelId` is the MOVE target and
             * absent means unset.
             */
            updateOperationModels: (update: UpdateInferenceOperationModelsInput) => Promise<go_common.v1.UpdateInferenceOperationModelsResponse>;
        };
        /**
         * Chat channel management
         */
        chatChannels: {
            /**
             * List chat channels (admin)
             */
            list: (pagination?: OptionalPaginationOptions, filters?: {
                search?: string;
                channelTypeFilter?: go_common.v1.ChannelType;
                includeArchived?: boolean;
                includeDeleted?: boolean;
                channelIdFilter?: bigint;
                createdByUserIdFilter?: bigint;
                participantUserIdFilter?: bigint;
            }, sort?: {
                sortBy: go_common.v1.AdminListChatChannelsSortBy;
                sortDesc?: boolean;
            }) => Promise<go_common.v1.AdminListChatChannelsResponse>;
            /**
             * Get a specific chat channel (admin)
             */
            get: (channelId: bigint, includeDeleted?: boolean) => Promise<go_common.v1.AdminGetChatChannelResponse>;
            /**
             * Update a chat channel (admin)
             */
            update: (params: {
                channelId: bigint;
                name?: string;
                description?: string;
                avatarAttachmentId?: bigint;
                isArchived?: boolean;
                supportReplies?: boolean;
                supportThreads?: boolean;
                supportMessageEdits?: boolean;
                supportMessageDeletes?: boolean;
                supportMessageReactions?: boolean;
                allowMultipleReactionsPerUser?: boolean;
                supportEmbeds?: boolean;
                supportAttachments?: boolean;
                allowNativeEmbeds?: boolean;
                allowCustomEmbeds?: boolean;
                supportInferenceUsage?: boolean;
                contextId?: bigint;
                contextDisplayName?: string;
                clearContext?: boolean;
                contextEntityId?: bigint;
            }) => Promise<go_common.v1.AdminUpdateChatChannelResponse>;
            /**
             * Delete a chat channel (admin)
             */
            delete: (channelId: bigint, reason: string) => Promise<go_common.v1.AdminDeleteChatChannelResponse>;
            participants: {
                /**
                 * List chat channel participants (admin)
                 */
                list: (channelId: bigint, pagination?: OptionalPaginationOptions, includeLeft?: boolean) => Promise<go_common.v1.AdminListChatChannelParticipantsResponse>;
                /**
                 * Add chat channel participants (admin)
                 */
                add: (channelId: bigint, userIds: bigint[], reason?: string) => Promise<go_common.v1.AdminAddChatChannelParticipantsResponse>;
                /**
                 * Remove a chat channel participant (admin)
                 */
                remove: (channelId: bigint, userId: bigint, reason?: string) => Promise<go_common.v1.AdminRemoveChatChannelParticipantResponse>;
                /**
                 * Update a chat channel participant role (admin)
                 */
                updateRole: (channelId: bigint, userId: bigint, role: go_common.v1.ChannelRole, reason?: string) => Promise<go_common.v1.AdminUpdateChatChannelParticipantRoleResponse>;
            };
        };
    };
    /**
     * Organizations API
     */
    organizations: {
        /**
         * Check if an organization slug is available
         */
        checkSlug: (slug: string) => Promise<go_common.v1.CheckOrganizationSlugAvailabilityResponse>;
        /**
         * Create a new organization
         * @param parentOrganizationId - Optional parent organization ID for creating child organizations
         */
        create: (name: string, slug: string, description?: string, avatarUrl?: string, parentOrganizationId?: bigint) => Promise<go_common.v1.CreateOrganizationResponse>;
        /**
         * Get organization by ID
         */
        get: (organizationId: bigint) => Promise<go_common.v1.GetOrganizationResponse>;
        /**
         * Get organization by slug
         */
        getBySlug: (slug: string) => Promise<go_common.v1.GetOrganizationBySlugResponse>;
        /**
         * Get current user's role in an organization (by id or slug)
         */
        getMyRole: (params: {
            organizationId?: bigint;
            slug?: string;
        }) => Promise<go_common.v1.GetMyOrganizationRoleResponse>;
        /**
         * Update organization
         */
        update: (organizationId: bigint, name: string, slug: string, description?: string, avatarUrl?: string) => Promise<go_common.v1.UpdateOrganizationResponse>;
        /**
         * Delete organization
         */
        delete: (organizationId: bigint) => Promise<go_common.v1.DeleteOrganizationResponse>;
        /**
         * List user's organizations with pagination
         */
        list: (pagination?: OptionalPaginationOptions, sort?: {
            sortBy: go_common.v1.ListOrganizationsSortBy;
            sortDesc?: boolean;
        }, organizationMembershipMaskFilters?: go_common.v1.OrganizationMembershipMaskFilter[], filter?: {
            search: string;
        }, organizationTypeFilter?: go_common.v1.OrganizationType, parentOrganizationIdFilter?: bigint, depthFilter?: number, signal?: AbortSignal) => Promise<go_common.v1.ListOrganizationsResponse>;
        /**
         * List organizations by parent (null/undefined for root organizations)
         */
        listByParent: (parentOrganizationId?: bigint, pagination?: OptionalPaginationOptions) => Promise<go_common.v1.ListOrganizationsByParentResponse>;
        /**
         * Get organization hierarchy tree
         * @param organizationId - Root organization to start from
         * @param includeDescendants - If true, traverses authorized descendants within server hierarchy limits; if false, pages direct children
         * @param pagination - Optional immediate-child page when includeDescendants is false
         */
        getHierarchy: (organizationId: bigint, includeDescendants?: boolean, pagination?: OptionalPaginationOptions, signal?: AbortSignal) => Promise<go_common.v1.GetOrganizationHierarchyResponse>;
        /**
         * Organization membership management
         */
        members: {
            /**
             * Add user to organization
             */
            add: (organizationId: bigint, userId: bigint, role: go_common.v1.OrganizationRole) => Promise<go_common.v1.AddUserToOrganizationResponse>;
            /**
             * Add user to organization by identifier (direct add if exists, auto-add if not)
             */
            addByIdentifier: (organizationId: bigint, identifierType: go_common.v1.UserIdentifierType, identifier: string, role: go_common.v1.OrganizationRole) => Promise<go_common.v1.AddUserToOrganizationByIdentifierResponse>;
            /**
             * Remove user from organization
             */
            remove: (organizationId: bigint, userId: bigint) => Promise<go_common.v1.RemoveUserFromOrganizationResponse>;
            /**
             * Update user role in organization
             */
            updateRole: (organizationId: bigint, userId: bigint, role: go_common.v1.OrganizationRole) => Promise<go_common.v1.UpdateUserRoleInOrganizationResponse>;
            /**
             * List organization members with pagination
             */
            list: (organizationId: bigint, pagination?: OptionalPaginationOptions) => Promise<go_common.v1.ListOrganizationUsersResponse>;
            /**
             * Get detailed information about a specific organization member
             */
            get: (organizationId: bigint, userId: bigint) => Promise<go_common.v1.GetOrganizationMemberResponse>;
            /**
             * Invite user to organization by email or username
             * Creates an invitation and returns its persisted ID.
             */
            invite: (organizationId: bigint, identifierType: go_common.v1.UserIdentifierType, identifier: string, role: go_common.v1.OrganizationRole) => Promise<go_common.v1.InviteUserToOrganizationResponse>;
        };
        /**
         * Organization invitation management (admin view)
         */
        invitations: {
            /**
             * List pending invitations sent by organization
             */
            list: (organizationId: bigint, pagination?: OptionalPaginationOptions) => Promise<go_common.v1.ListOrganizationInvitationsResponse>;
            /**
             * Cancel a pending invitation
             */
            cancel: (organizationId: bigint, invitationId: bigint) => Promise<go_common.v1.CancelInvitationResponse>;
        };
        /**
         * Organization email domain management
         */
        emailDomains: {
            /**
             * Create organization email domain
             */
            create: (organizationId: bigint, domain: string) => Promise<go_common.v1.CreateOrganizationEmailDomainResponse>;
            /**
             * Delete organization email domain
             */
            delete: (organizationId: bigint, organizationEmailDomainId: bigint) => Promise<void>;
            /**
             * List organization email domains
             */
            list: (organizationId: bigint, pagination?: OptionalPaginationOptions) => Promise<go_common.v1.ListOrganizationEmailDomainsResponse>;
        };
        /**
         * Organization inference policy: provider allowlist, per-operation model narrowing, and the
         * member model picker. These checks use the viewer's effective organization role only; site
         * user type never grants them.
         */
        inferencePolicy: {
            /**
             * The organization's policy with every registered operation, inherited settings included
             * at version zero. Requires the view-inference-policy role.
             */
            get: (organizationId: bigint, signal?: AbortSignal) => Promise<go_common.v1.GetOrganizationInferencePolicyResponse>;
            /**
             * Replace the organization's provider allowlist. Requires the manage-inference-policy role.
             * `expectedVersion` gives optimistic concurrency: a stale version is rejected. A dry run
             * returns the impact preview without saving.
             */
            update: (update: UpdateOrganizationInferencePolicyInput) => Promise<go_common.v1.UpdateOrganizationInferencePolicyResponse>;
            /**
             * Replace one operation's organization policy. Requires the manage-inference-policy role.
             * An empty `inferenceModelIds` means the whole site list. An absent `defaultModelId` or
             * `moveToModelId` means unset; `moveToModelId` is the MOVE target, and an absent
             * `sessionAction` keeps affected sessions. `expectedVersion` gives optimistic concurrency:
             * a stale version is rejected. A dry run returns the impact preview without saving.
             */
            updateOperation: (update: UpdateOrganizationInferenceOperationPolicyInput) => Promise<go_common.v1.UpdateOrganizationInferenceOperationPolicyResponse>;
            /**
             * Models eligible for one organization and operation, with the default marked, whether
             * member choice is open, and a typed block reason when none is eligible. The server
             * admits a chooser (the choose-inference-model role) or a re-targeting manager (site
             * inference administration or the manage-inference-policy role) and says which in
             * `canChoose` and `management`. Partition caches by viewer and organization.
             */
            listModelChoices: (options: ListInferenceModelChoicesInput, signal?: AbortSignal) => Promise<go_common.v1.ListInferenceModelChoicesResponse>;
        };
    };
    /**
     * Chat / messaging API
     */
    chat: {
        channels: {
            /**
             * List channels for the current user
             */
            list: (pagination?: OptionalPaginationOptions, includeArchived?: boolean) => Promise<go_common.v1.ListChannelsResponse>;
            /**
             * Get channel by id
             */
            get: (channelId: bigint, signal?: AbortSignal) => Promise<go_common.v1.GetChannelResponse>;
            /**
             * Create a new channel. `forkRules` are fixed at creation; omitted, forking is disabled.
             */
            create: (name: string, description: string, channelType: go_common.v1.ChannelType, participantUserIds: bigint[], contextId?: bigint, contextDisplayName?: string, contextEntityId?: bigint, unreadNotificationsEnabled?: boolean, forkRules?: go_common.v1.ChannelForkRules) => Promise<go_common.v1.CreateChannelResponse>;
            /**
             * Fork a channel: copy its history up to and including `forkPointMessageId` into a new
             * channel the caller owns. The source's fork rules decide who may fork, which members may
             * be named, and whether `keepOrgAccess` / `keepContext` are honored. A retry with the same
             * `clientRequestId` returns the fork it created.
             */
            fork: (input: ForkChannelInput) => Promise<go_common.v1.ForkChannelResponse>;
            /**
             * Get-or-create a unique channel for the exact member tuple.
             * The backend implicitly includes the authenticated user in the tuple.
             */
            getOrCreateByMembersUnique: (memberUserIds: bigint[], contextId?: bigint, contextDisplayName?: string, contextEntityId?: bigint) => Promise<go_common.v1.GetOrCreateChannelByMembersUniqueResponse>;
            /**
             * Create endpoints are exposed via `create(...)`.
             */
            /**
             * Update channel metadata
             */
            update: (params: {
                channelId: bigint;
                name?: string;
                description?: string;
                avatarAttachmentId?: bigint;
                isArchived?: boolean;
                unreadNotificationsEnabled?: boolean;
            }) => Promise<go_common.v1.UpdateChannelResponse>;
            /**
             * Leave a channel
             */
            leave: (channelId: bigint) => Promise<go_common.v1.LeaveChannelResponse>;
            /**
             * Set who beyond participants may read a channel: nobody (`UNSPECIFIED`), any signed-in
             * user, or anyone with the channel ID. Owner only. Returns the updated channel.
             */
            setPublicRead: (channelId: bigint, publicRead: go_common.v1.ChatChannelPublicRead) => Promise<go_common.v1.SetChannelPublicReadResponse>;
            participants: {
                /**
                 * Add users to a channel
                 */
                add: (channelId: bigint, userIds: bigint[]) => Promise<go_common.v1.AddParticipantsResponse>;
                /**
                 * Remove a user from a channel
                 */
                remove: (channelId: bigint, userId: bigint) => Promise<go_common.v1.RemoveParticipantResponse>;
                /**
                 * Update a participant's role
                 */
                updateRole: (channelId: bigint, userId: bigint, role: go_common.v1.ChannelRole) => Promise<go_common.v1.UpdateParticipantRoleResponse>;
                /**
                 * Update the current user's participant preferences for a channel
                 */
                updatePreferences: (channelId: bigint, preferences: {
                    notificationMode?: go_common.v1.ChannelNotificationMode;
                    isPinned?: boolean;
                }) => Promise<go_common.v1.UpdateParticipantPreferencesResponse>;
                /**
                 * List participants in a channel
                 */
                list: (channelId: bigint, pagination?: OptionalPaginationOptions) => Promise<go_common.v1.ListParticipantsResponse>;
                /**
                 * List participants for multiple channels. Channel IDs are deduplicated
                 * and sent in sequential requests of at most
                 * `chatMaxListParticipantsBatchChannelIds` IDs; the items are returned in
                 * request order. `pagination` applies to each channel.
                 */
                listBatch: (channelIds: bigint[], pagination?: OptionalPaginationOptions) => Promise<go_common.v1.ListParticipantsBatchResponse>;
            };
        };
        /**
         * Reads of a channel open to anyone, made without a session. A channel that is not open to
         * anyone, or any channel while public reads are disabled, rejects with a 404 `ApiError`.
         * Requests are rate limited per IP (429) while the server's `rate_limits.rate_limit_enabled`
         * is on (default off).
         */
        public: {
            /** Get a channel open to anyone. */
            getChannel: (channelId: bigint, signal?: AbortSignal) => Promise<go_common.v1.GetPublicChannelResponse>;
            /**
             * List a channel's visible messages, like `messages.list`: hidden and deleted messages are
             * never returned.
             */
            listMessages: (channelId: bigint, options?: {
                pagination?: OptionalPaginationOptions;
                parentMessageId?: bigint;
                sortBy?: go_common.v1.ListMessagesSortBy;
                sort?: {
                    sortDesc: boolean;
                };
            }, signal?: AbortSignal) => Promise<go_common.v1.ListPublicMessagesResponse>;
        };
        messages: {
            /**
             * List messages within a channel
             */
            list: (channelId: bigint, options?: {
                pagination?: OptionalPaginationOptions;
                parentMessageId?: bigint;
                includeDeleted?: boolean;
                sortBy?: go_common.v1.ListMessagesSortBy;
                sort?: {
                    sortDesc: boolean;
                };
                /** Bot/service-authority + admin tooling only: include hidden_from_users rows. */
                includeHidden?: boolean;
            }, signal?: AbortSignal) => Promise<go_common.v1.ListMessagesResponse>;
            /**
             * Get a single message by id
             */
            get: (messageId: bigint, options?: {
                includeHidden?: boolean;
            }) => Promise<go_common.v1.GetMessageResponse>;
            /**
             * Send a new message to a channel. When the agent session the message reaches is busy or
             * suspended, the input is queued instead: the response carries `queuedInput` rather than
             * `message` (see `agentQueuedInputs`), and `newAttachments` belong to it. A thread reply
             * also sent to the channel is refused with a 409 that `isAgentBroadcastWouldWaitError`
             * recognizes while any agent session it reaches would make it wait.
             */
            send: (params: {
                channelId: bigint;
                content: string;
                parentMessageId?: bigint;
                replyToMessageId?: bigint;
                embeds?: go_common.v1.CreateMessageEmbedRequest[];
                attachments?: go_common.v1.AttachmentMetadata[];
                /** Also show a thread reply on the main timeline; requires `parentMessageId`. */
                broadcastToChannel?: boolean;
                /**
                 * Idempotency key for this submission, unique per sender and channel. Reuse it when
                 * retrying an ambiguous failure so the server returns what the original send left: its
                 * message, or its `queuedInput` while the input still waits for a busy agent session.
                 */
                clientMessageId?: string;
            }) => Promise<go_common.v1.SendMessageResponse>;
            /**
             * Edit an existing message
             */
            edit: (params: {
                messageId: bigint;
                content: string;
                embeds?: go_common.v1.CreateMessageEmbedRequest[];
                attachments?: go_common.v1.AttachmentMetadata[];
                replaceEmbeds?: boolean;
                replaceAttachments?: boolean;
            }) => Promise<go_common.v1.EditMessageResponse>;
            /**
             * List edit history for a message
             */
            editHistory: (messageId: bigint, pagination?: OptionalPaginationOptions) => Promise<go_common.v1.ListMessageEditHistoryResponse>;
            /**
             * Delete a message
             */
            delete: (messageId: bigint) => Promise<go_common.v1.DeleteMessageResponse>;
            /**
             * Batch get messages within a channel
             */
            batchGet: (channelId: bigint, messageIds: bigint[], options?: {
                includeHidden?: boolean;
            }) => Promise<go_common.v1.BatchGetMessagesResponse>;
            /**
             * Add or remove reactions on messages
             */
            reactions: {
                add: (messageId: bigint, emoji: string) => Promise<go_common.v1.AddReactionResponse>;
                remove: (messageId: bigint, emoji: string) => Promise<go_common.v1.RemoveReactionResponse>;
                list: (messageId: bigint, options?: {
                    pagination?: OptionalPaginationOptions;
                    emojiFilter?: string;
                }) => Promise<go_common.v1.ListReactionsResponse>;
            };
            /**
             * Approve or deny a TOOL_CALL message awaiting human-in-the-loop
             * approval (approval_status == PENDING). On deny the service auto-writes
             * the paired error TOOL_RESULT; resolution fans out via the
             * TOOL_CALL_RESOLUTION websocket event.
             */
            resolveToolCall: (params: {
                messageId: bigint;
                approve: boolean;
                reason?: string;
            }) => Promise<go_common.v1.ResolveToolCallResponse>;
            /**
             * Derived inference-usage summary for one assistant/compaction message.
             * Aggregated from the ChatInferenceCall ledger — not stored on the
             * message row. Returns an empty/absent summary (not an error) when the
             * message has no linked inference calls.
             */
            getInferenceSummary: (messageId: bigint) => Promise<go_common.v1.GetMessageInferenceSummaryResponse>;
            /**
             * Batched derived inference-usage summaries for a transcript page, so
             * token badges can share bounded batch requests rather than requesting each
             * assistant message separately. Inputs exceeding the configured client batch
             * size are split into sequential requests. Each returned summary carries its own messageId; message IDs
             * with no ledger rows (or not visible/authorized) are omitted.
             */
            batchGetInferenceSummaries: (channelId: bigint, messageIds: bigint[], signal?: AbortSignal) => Promise<go_common.v1.BatchGetMessageInferenceSummariesResponse>;
        };
        /**
         * Agentic inference usage reads (Decision 0 / Decision 2.5). Read-only;
         * backed by the ChatInferenceCall ledger and ChatInferenceTotals cache.
         * Usage reads return zeros (not errors) when no ledger rows exist. There is
         * no agent-session create/get/updateConfig client in v1 — those are Go
         * service methods on the consuming app's backend.
         */
        usage: {
            /** Aggregate inference totals for a channel (cheap channel-level total). */
            getChannelTotals: (channelId: bigint) => Promise<go_common.v1.GetChatInferenceTotalsResponse>;
            /** Inference usage scoped to an agent session, with optional breakdowns. */
            getAgentSessionUsage: (agentSessionId: bigint, options?: {
                byRunPagination?: OptionalPaginationOptions;
                byModelPagination?: OptionalPaginationOptions;
                /** Roll a delegation parent up with its delegated child sessions (fills by_session). */
                includeChildren?: boolean;
            }) => Promise<go_common.v1.GetAgentSessionUsageResponse>;
        };
        agentRuns: {
            /**
             * Append-only inference-call ledger for one agent run (debug/audit).
             * Paginated like other list endpoints.
             */
            listInferenceCalls: (agentRunId: bigint, options?: {
                pagination?: OptionalPaginationOptions;
            }) => Promise<go_common.v1.ListAgentRunInferenceCallsResponse>;
            /**
             * Authoritative agent-run status for thread locations of one channel: the
             * newest run of each location plus up to `historyLimit` older ones. Any
             * channel reader may call it, including read-only organization readers.
             *
             * `parentMessageIds` uses the thread convention where `0n` is the main
             * timeline; omitted or empty reads the main timeline. At most 50 locations
             * and 10 older runs per location.
             */
            getStatus: (channelId: bigint, options?: AgentRunStatusRequestOptions, signal?: AbortSignal) => Promise<go_common.v1.GetAgentRunStatusResponse>;
            /**
             * Stops one active run and suspends its session until `agentSessions.resume`.
             * Name the run the viewer saw: a run that already ended is not stopped, and
             * neither is a newer one (409). Only runs whose session policy allows user Stop
             * can be stopped (403), by people who may resolve the run's tool calls or whose
             * input it admitted. Returns the session's interaction for the viewer, absent
             * when the read after commit fails (the AGENT_SESSION_INTERACTION event then
             * prompts a re-read).
             */
            stop: (agentRunId: bigint) => Promise<go_common.v1.StopAgentRunResponse>;
        };
        agentSessions: {
            /**
             * Agent sessions bound to one channel: the main-timeline session first, then
             * thread sessions newest first, delegated children included (at most 200, so
             * past the cap the oldest threads are left out). Any
             * channel reader may call it. Run state is read separately through
             * `agentRuns.getStatus`.
             */
            listForChannel: (channelId: bigint) => Promise<go_common.v1.ListChannelAgentSessionsResponse>;
            /**
             * Resumes a session a Stop suspended: input held meanwhile starts one run (its
             * id is `agentRunId`), or, with none held, the session's deferred sub-agent
             * report does. The person who stopped it, channel admins and site
             * tool-approval admins may resume it; a session with nothing to resume
             * returns its interaction to any reader. `interaction` is absent when the read
             * after commit fails (the AGENT_SESSION_INTERACTION event then prompts a re-read).
             */
            resume: (agentSessionId: bigint) => Promise<go_common.v1.ResumeAgentSessionResponse>;
            /**
             * Moves one session's inference pin to another model. Inference administrators and holders
             * of the manage-inference-policy role may retarget any session in the organization; the
             * session owner may retarget their own with the choose-inference-model role.
             * `expectedPinVersion` gives optimistic concurrency: a stale version is rejected. An absent
             * `api` inherits the operation route's API. `siteOverride` also requires the
             * inference-model-override permission.
             */
            retargetInference: (retarget: RetargetInferenceSessionInput) => Promise<go_common.v1.RetargetInferenceSessionResponse>;
            /**
             * Moves several of one organization's session pins to another model in one transaction.
             * Requires inference administration or the manage-inference-policy role; the server caps
             * the batch size. Each entry's `expectedPinVersion` gives optimistic concurrency: a stale
             * version is rejected. An absent `api` inherits the operation route's API. `siteOverride`
             * also requires the inference-model-override permission.
             */
            retargetInferenceBulk: (retarget: RetargetInferenceSessionsInput) => Promise<go_common.v1.RetargetInferenceSessionsResponse>;
        };
        /**
         * Input sent while an agent session was busy or suspended. It waits in the session's queue
         * (a send answers with `queuedInput` instead of `message`) and becomes a chat message only
         * when the agent receives it, arriving through MESSAGE_SENT. Every change to a queue is
         * announced by the session's AGENT_SESSION_INTERACTION event.
         */
        agentQueuedInputs: {
            /**
             * One agent session's queued input, oldest first, for anyone who can read the conversation.
             * Each entry says whether the viewer may edit it (its sender) or remove it (its sender or a
             * channel admin). Page by cursor: pass the previous page's `pagination.nextCursor`. A page
             * holds at most the server's pending-input cap.
             */
            list: (agentSessionId: bigint, pagination?: {
                limit?: number;
                cursor?: bigint;
            }) => Promise<go_common.v1.ListAgentQueuedInputsResponse>;
            /**
             * Rewords queued input the viewer sent. `attachments` is the whole new list, kept ones
             * included: one left out is removed, and an empty list removes all. Embeds and the reply
             * target are kept. Upload the response's `newAttachments` as for a send. Rejects with a 409
             * that `isAgentQueuedInputNotQueuedError` recognizes once the input is no longer queued
             * (delivered, removed or discarded), and with a 409 when the channel is archived.
             */
            edit: (params: {
                queuedInputId: bigint;
                content: string;
                attachments: go_common.v1.AttachmentMetadata[];
            }) => Promise<go_common.v1.EditAgentQueuedInputResponse>;
            /**
             * Withdraws queued input; its sender and channel admins may. Rejects with a 409 that
             * `isAgentQueuedInputNotQueuedError` recognizes once the input is no longer queued
             * (delivered, removed or discarded), and with a 409 when the channel is archived.
             */
            remove: (queuedInputId: bigint) => Promise<void>;
        };
    };
    /**
     * Contact API
     */
    contact: {
        /**
         * Submit contact form
         */
        submit: (name: string, email: string, subject: string, message: string) => Promise<string>;
    };
    /**
     * Careers API
     */
    careers: {
        /**
         * List public career job postings
         */
        listJobs: (requestPayload?: ListRequestWithOptionalPagination<go_common.v1.ListCareerJobPostingsRequest>) => Promise<go_common.v1.ListCareerJobPostingsResponse>;
        /**
         * Get a public career job posting by slug
         */
        getJobBySlug: (slug: string) => Promise<go_common.v1.GetCareerJobPostingBySlugResponse>;
        applications: {
            /**
             * Create an authenticated career application and get resume upload instructions
             */
            create: (requestPayload: go_common.v1.CreateCareerApplicationRequest) => Promise<go_common.v1.CreateCareerApplicationResponse>;
            /**
             * List authenticated user's own career applications
             */
            listMine: (requestPayload?: ListRequestWithOptionalPagination<go_common.v1.ListMyCareerApplicationsRequest>) => Promise<go_common.v1.ListMyCareerApplicationsResponse>;
            /**
             * Get authenticated user's application by reference ID
             */
            getMineByReference: (referenceId: string) => Promise<go_common.v1.GetMyCareerApplicationByReferenceIDResponse>;
            /**
             * Withdraw authenticated user's application by reference ID
             */
            withdraw: (referenceId: string) => Promise<go_common.v1.WithdrawMyCareerApplicationResponse>;
        };
    };
    /**
     * Notification inbox API. Every operation is bound to the signed-in user;
     * notifications are created server-side only. Responds 404 when the feature
     * is disabled or the notification does not exist.
     */
    notifications: {
        /**
         * List notifications newest first, optionally within an exact activity scope.
         * A short or empty filtered page can still have `nextBeforeId`; use the
         * cursor, not the entry count, to determine whether another page exists.
         */
        list: (options?: {
            beforeId?: bigint;
            limit?: number;
            unreadOnly?: boolean;
            activityScope?: string;
        }, signal?: AbortSignal) => Promise<go_common.v1.ListNotificationsResponse>;
        get: (id: bigint, signal?: AbortSignal) => Promise<go_common.v1.Notification>;
        /** Authorized unread count; incomplete results are a confirmed lower bound. */
        count: (signal?: AbortSignal) => Promise<go_common.v1.NotificationCountResponse>;
        /**
         * Mark notifications read at the given revisions. Receipts are deduplicated
         * by ID (highest revision wins) and sent in sequential batches of at most
         * 100; a failed batch rejects and leaves
         * earlier batches applied, so retrying the whole call is safe. An empty
         * input sends nothing.
         */
        markRead: (receipts: readonly go_common.v1.NotificationReadReceipt[], signal?: AbortSignal) => Promise<go_common.v1.NotificationMutationResponse>;
        /**
         * Claim the right to show an interruptive alert for one revision. Returns
         * `claimed: false` (not an error) when the alert should not be shown.
         */
        claimAlert: (id: bigint, revision: bigint, signal?: AbortSignal) => Promise<go_common.v1.ClaimNotificationAlertResponse>;
        getPreferences: (signal?: AbortSignal) => Promise<go_common.v1.NotificationPreferencesResponse>;
        /**
         * Partially update preferences. Omitted fields (and unset per-type flags)
         * are left unchanged on the server.
         */
        updatePreferences: (update: {
            inAppAlertsEnabled?: boolean;
            preferences?: readonly go_common.v1.NotificationPreference[];
        }, signal?: AbortSignal) => Promise<go_common.v1.NotificationMutationResponse>;
    };
    /**
     * Get configured base URL (scheme + host + optional base path).
     */
    getBaseUrl(): string;
    /**
     * Get configured API prefix (path prefix, e.g. "/api/v1/common").
     */
    getApiPrefix(): string;
    /**
     * Build the URL of an API path the same way requests are addressed. The
     * result is relative when the configured base URL is.
     */
    getApiUrl(path: string): string;
    /**
     * Make an API request
     */
    private makeRequest;
}
//# sourceMappingURL=client.d.ts.map