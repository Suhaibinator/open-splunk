/**
 * API Path Constants for go-common
 *
 * This file provides type-safe API endpoint paths for frontend applications
 * using go-common as their backend.
 *
 * @module api-paths
 */
/**
 * API endpoint paths organized by feature area.
 * All paths are relative to the base API prefix.
 */
export declare const API_PATHS: {
    /**
     * Default base API prefix. Can be overridden using buildApiPath function.
     * Uses GO_COMMON_API_PATH_PREFIX environment variable if available.
     */
    readonly BASE: string;
    /**
     * Authentication endpoints
     */
    readonly AUTH: {
        /**
         * Email-based authentication
         */
        readonly EMAIL: {
            /** POST - Create new user account */
            readonly CREATE: "/auth/email/create";
            /** POST - Login with email/password */
            readonly LOGIN: "/auth/email/login";
            /** POST - Change password (requires auth) */
            readonly CHANGE_PASSWORD: "/auth/email/change-password";
            /** POST - Request password reset */
            readonly RESET_PASSWORD: "/auth/email/reset-password";
            /** POST - Complete email verification */
            readonly COMPLETE_VERIFICATION: "/auth/email/complete-verification";
            /** POST - Complete password reset */
            readonly ACCEPT_INVITATION: "/auth/email/accept-invitation";
            readonly COMPLETE_RESET: "/auth/email/complete-reset";
        };
        /**
         * OTP/TOTP two-factor authentication (2FA)
         */
        readonly OTP: {
            /** POST - Initiate OTP setup (requires auth) */
            readonly SETUP: "/auth/otp/setup";
            /** POST - Verify OTP setup (requires auth) */
            readonly VERIFY_SETUP: "/auth/otp/verify-setup";
            /** POST - Disable OTP (requires auth) */
            readonly DISABLE: "/auth/otp/disable";
        };
        /**
         * OAuth authentication
         */
        readonly OAUTH: {
            /** GET - List the configured OAuth providers */
            readonly PROVIDERS: "/auth/oauth/providers";
            /** POST - Create server-issued OAuth state and the provider authorization URL */
            readonly STATE: "/auth/oauth/state";
            /** POST - Provider-facing form_post relay; its absolute URL is the redirect_uri for form_post providers */
            readonly FORM_POST: "/auth/oauth/form-post";
            /** POST - OAuth provider callback */
            readonly CALLBACK: "/auth/oauth/callback";
        };
        /**
         * Phone verification
         */
        readonly PHONE: {
            /** POST - Send phone verification OTP */
            readonly SEND_OTP: "/auth/phone/send-otp";
            /** POST - Verify phone OTP code */
            readonly VERIFY_OTP: "/auth/phone/verify-otp";
            /** POST - Resend phone verification OTP */
            readonly RESEND_OTP: "/auth/phone/resend-otp";
        };
        /**
         * Authenticated session management
         */
        readonly SESSIONS: {
            /** POST - List active sessions for current user */
            readonly LIST: "/auth/sessions";
            /** POST - Revoke a specific session for current user */
            readonly REVOKE: "/auth/sessions/revoke";
            /** POST - Revoke all sessions except the current one */
            readonly REVOKE_OTHER: "/auth/sessions/revoke-others";
        };
        /** POST - Logout current session or all sessions */
        readonly LOGOUT: "/auth/logout";
        /** POST - Add password to OAuth account (requires auth) */
        readonly ADD_PASSWORD: "/auth/add-password";
        /** GET - Get available auth methods (requires auth) */
        readonly METHODS: "/auth/methods";
        /** POST - Check if username is available (no auth required) */
        readonly CHECK_USERNAME: "/auth/check-username";
    };
    /**
     * User management endpoints
     */
    readonly USER: {
        /** GET - Get current user profile (requires auth) */
        readonly ME: "/user/me";
        /** POST - Search public users */
        readonly SEARCH: "/user/search";
        /** GET/PUT - User settings (requires auth) */
        readonly SETTINGS: "/user/settings";
        /** PUT - Update user language preference (requires auth) */
        readonly LANGUAGE: "/user/settings/language";
        /**
         * Profile picture management
         */
        readonly PROFILE_PICTURE: {
            /** POST - Generate upload URL for profile picture */
            readonly UPLOAD_URL: "/user/profile-picture/upload-url";
            /** DELETE - Remove current profile picture */
            readonly REMOVE: "/user/profile-picture";
        };
        /**
         * Phone number management
         */
        readonly PHONE: {
            /** POST - Remove phone number from user account */
            readonly REMOVE: "/user/phone/remove";
        };
        /**
         * Username management
         */
        readonly USERNAME: {
            /** PUT - Update username */
            readonly UPDATE: "/user/username";
        };
        /**
         * User invitation management (for invitations received by user)
         */
        readonly INVITATIONS: {
            /** POST - List pending invitations for current user */
            readonly LIST: "/user/invitations/list";
            /** POST - Accept an invitation */
            readonly ACCEPT: "/user/invitations/accept";
            /** POST - Decline an invitation */
            readonly DECLINE: "/user/invitations/decline";
        };
    };
    /**
     * Contact form endpoints
     */
    readonly CONTACT: {
        /** POST - Submit contact message */
        readonly SUBMIT: "/contact/submit";
    };
    /**
     * Careers endpoints
     */
    readonly CAREERS: {
        readonly JOBS: {
            /** POST - List public career job postings */
            readonly LIST: "/careers/jobs";
            /** POST - Get a public career job posting by slug */
            readonly GET_BY_SLUG: "/careers/jobs/get-by-slug";
        };
        readonly APPLICATIONS: {
            /** POST - Create an authenticated career application and get resume upload instructions */
            readonly CREATE: "/careers/applications/create";
            /** POST - List authenticated user's own applications */
            readonly LIST_MINE: "/careers/applications/my";
            /** POST - Get authenticated user's application by reference ID */
            readonly GET_MINE_BY_REFERENCE: "/careers/applications/my/get-by-reference";
            /** POST - Withdraw authenticated user's application by reference ID */
            readonly WITHDRAW: "/careers/applications/my/withdraw";
        };
    };
    /**
     * Attachment management endpoints
     */
    readonly ATTACHMENTS: {
        /** POST - Finalize uploaded attachments */
        readonly FINALIZE: "/attachments/finalize";
    };
    /**
     * Chat / messaging endpoints
     */
    readonly CHAT: {
        readonly CHANNELS: {
            /** POST - Create a new channel */
            readonly CREATE: "/chat/channels";
            /** POST - Get-or-create channel unique for exact member tuple */
            readonly BY_MEMBERS_UNIQUE: "/chat/channels/by_members/unique";
            /** POST - Get a single channel */
            readonly GET: "/chat/channels/get";
            /** PUT - Update channel metadata */
            readonly UPDATE: "/chat/channels/update";
            /** POST - List channels for current user */
            readonly LIST: "/chat/channels/list";
            /** POST - Leave a channel */
            readonly LEAVE: "/chat/channels/leave";
            /** POST - Set who beyond participants may read a channel (owner only) */
            readonly SET_PUBLIC_READ: "/chat/channels/public_read/set";
            /** POST - Fork a channel at a message into a new channel */
            readonly FORK: "/chat/channels/fork";
            readonly PARTICIPANTS: {
                /** POST - Add channel participants */
                readonly ADD: "/chat/channels/participants/add";
                /** DELETE - Remove a participant */
                readonly REMOVE: "/chat/channels/participants/remove";
                /** PUT - Update participant role */
                readonly UPDATE_ROLE: "/chat/channels/participants/role";
                /** PUT - Update participant preferences */
                readonly UPDATE_PREFERENCES: "/chat/channels/participants/preferences";
                /** POST - List participants */
                readonly LIST: "/chat/channels/participants/list";
                /** POST - List participants for multiple channels */
                readonly LIST_BATCH: "/chat/channels/participants/list_batch";
            };
        };
        readonly MESSAGES: {
            /** POST - Send message to channel */
            readonly SEND: "/chat/messages/send";
            /** PUT - Edit message content */
            readonly EDIT: "/chat/messages/edit";
            /** DELETE - Delete a message */
            readonly DELETE: "/chat/messages/delete";
            /** POST - Get message by id */
            readonly GET: "/chat/messages/get";
            /** POST - Batch get messages by id */
            readonly BATCH_GET: "/chat/messages/batch_get";
            /** POST - List messages for channel */
            readonly LIST: "/chat/messages/list";
            /** POST - List edit history for a message */
            readonly EDIT_HISTORY: "/chat/messages/edit_history";
            readonly REACTIONS: {
                /** POST - Add reaction */
                readonly ADD: "/chat/messages/reactions/add";
                /** DELETE - Remove reaction */
                readonly REMOVE: "/chat/messages/reactions/remove";
                /** POST - List reactions */
                readonly LIST: "/chat/messages/reactions/list";
            };
            /** POST - Approve/deny a tool call awaiting human-in-the-loop approval */
            readonly RESOLVE_TOOL_CALL: "/chat/messages/resolve_tool_call";
            /** POST - Derived inference-usage summary for one assistant/compaction message */
            readonly INFERENCE_SUMMARY: "/chat/messages/inference_summary";
            /** POST - Batched derived inference-usage summaries for a transcript page */
            readonly BATCH_INFERENCE_SUMMARIES: "/chat/messages/batch_inference_summaries";
        };
        /**
         * Agentic inference usage reads (Decision 0 / Decision 2.5). Backed by the
         * ChatInferenceCall ledger and ChatInferenceTotals cache. Read-only.
         */
        readonly USAGE: {
            /** POST - Aggregate inference totals for a channel */
            readonly CHANNEL_TOTALS: "/chat/usage/channel_totals";
            /** POST - Inference usage scoped to an agent session (+ optional breakdowns) */
            readonly AGENT_SESSION: "/chat/usage/agent_session";
        };
        readonly AGENT_RUNS: {
            /** POST - Append-only inference-call ledger for one agent run (paginated) */
            readonly INFERENCE_CALLS: "/chat/agent_runs/inference_calls";
            /** POST - Authoritative run status for thread locations of one channel */
            readonly STATUS: "/chat/agent_runs/status";
            /** POST - Stop one active run and suspend its session until Resume */
            readonly STOP: "/chat/agent_runs/stop";
        };
        readonly AGENT_SESSIONS: {
            /** POST - Agent sessions bound to one channel, delegated child sessions included */
            readonly LIST: "/chat/agent_sessions/list";
            /** POST - Resume a stopped session; input held meanwhile starts one run */
            readonly RESUME: "/chat/agent_sessions/resume";
            /**
             * POST - Move one session's inference pin to another model. Outside `/chat`, but
             * served only when chat is enabled.
             */
            readonly RETARGET_INFERENCE: "/inference/sessions/retarget";
            /** POST - Move several of one organization's session pins to another model */
            readonly RETARGET_INFERENCE_BULK: "/inference/sessions/retarget-bulk";
        };
        /**
         * Input queued for a busy or suspended agent session, which becomes a chat message only when
         * the agent receives it.
         */
        readonly AGENT_QUEUED_INPUTS: {
            /** POST - One session's queued input, oldest first (cursor-paged) */
            readonly LIST: "/chat/agent_queued_inputs/list";
            /** PUT - Reword queued input before the agent receives it (sender only) */
            readonly EDIT: "/chat/agent_queued_inputs/edit";
            /** DELETE - Withdraw queued input before the agent receives it (sender or channel admin) */
            readonly REMOVE: "/chat/agent_queued_inputs/remove";
        };
        /**
         * Reads of channels open to anyone, served without a session and rate limited per IP.
         */
        readonly PUBLIC: {
            /** POST - Get a channel open to anyone */
            readonly GET_CHANNEL: "/chat/public/channels/get";
            /** POST - List a channel's visible messages */
            readonly LIST_MESSAGES: "/chat/public/messages/list";
        };
    };
    /**
     * Admin API endpoints (requires tier 2+ admin access)
     */
    readonly ADMIN: {
        /**
         * User management
         */
        readonly USERS: {
            /** POST - List users with pagination and filtering */
            readonly LIST: "/admin/users";
            /** POST - Get specific user details */
            readonly GET: "/admin/users/get";
            /** POST - Create a human or bot user */
            readonly CREATE: "/admin/users/create";
            readonly RESEND_INVITATION: "/admin/users/resend-invitation";
            /** POST - Ban/unban user */
            readonly BAN: "/admin/users/ban";
            /** POST - Change user type/role */
            readonly CHANGE_TYPE: "/admin/users/change-type";
            /** POST - Change username */
            readonly CHANGE_USERNAME: "/admin/users/change-username";
            /** POST - List username change history */
            readonly USERNAME_CHANGE_HISTORY: "/admin/users/username-change-history";
            /** POST - Delete user account */
            readonly DELETE: "/admin/users/delete";
            /** POST - Revoke user sessions */
            readonly REVOKE_SESSIONS: "/admin/users/revoke-sessions";
            /** POST - Create profile picture upload URL for user */
            readonly PROFILE_PICTURE_UPLOAD_URL: "/admin/users/profile-picture/upload-url";
            /** POST - Clear user profile picture */
            readonly PROFILE_PICTURE_CLEAR: "/admin/users/profile-picture/clear";
        };
        /**
         * Organization management (admin only)
         */
        readonly ORGANIZATIONS: {
            /** POST - Admin create organization */
            readonly CREATE: "/admin/organizations/create";
            /** POST - Admin list all organizations */
            readonly LIST_ALL: "/admin/organizations/list-all";
            /** POST - Admin read bounded descendant pages for deletion preview */
            readonly DELETION_IMPACT: "/admin/organizations/deletion-impact";
            /** POST - Admin list paginated organization parent options */
            readonly PARENT_OPTIONS: "/admin/organizations/parent-options";
            /** POST - Admin list organization filter metadata */
            readonly FILTER_METADATA: "/admin/organizations/filter-metadata";
            /** POST - Admin change organization type */
            readonly CHANGE_TYPE: "/admin/organizations/change-type";
            /** POST - Admin add user to organization */
            readonly ADD_MEMBER: "/admin/organizations/members/add";
            /** POST - Admin add user to organization by email or username */
            readonly ADD_MEMBER_BY_IDENTIFIER: "/admin/organizations/members/add-by-identifier";
            /** PUT - Admin update user role in organization */
            readonly UPDATE_MEMBER_ROLE: "/admin/organizations/members/update-role";
            /** POST - Admin get organization member details */
            readonly GET_MEMBER: "/admin/organizations/members/get";
            /** Organization email domain management (admin only) */
            readonly EMAIL_DOMAINS: {
                /** POST - Admin create organization email domain */
                readonly CREATE: "/admin/organizations/email-domains/create";
                /** DELETE - Admin delete organization email domain */
                readonly DELETE: "/admin/organizations/email-domains/delete";
                /** POST - Admin list organization email domains */
                readonly LIST: "/admin/organizations/email-domains/list";
            };
        };
        /**
         * Contact message management
         */
        readonly CONTACT_MESSAGES: {
            /** POST - List contact messages with filtering */
            readonly LIST: "/admin/contact-messages";
            /** POST - Get specific contact message */
            readonly GET: "/admin/contact-messages/get";
            /** POST - Get contact message by reference ID */
            readonly GET_BY_REFERENCE: "/admin/contact-messages/get-by-reference";
        };
        /**
         * Careers management
         */
        readonly CAREERS: {
            readonly JOBS: {
                /** POST - List career job postings */
                readonly LIST: "/admin/careers/jobs";
                /** POST - Get a career job posting */
                readonly GET: "/admin/careers/jobs/get";
                /** POST - Create a career job posting */
                readonly CREATE: "/admin/careers/jobs/create";
                /** POST - Update a career job posting */
                readonly UPDATE: "/admin/careers/jobs/update";
                /** POST - Transition a career job posting status */
                readonly STATUS: "/admin/careers/jobs/status";
            };
            readonly APPLICATIONS: {
                /** POST - List career applications */
                readonly LIST: "/admin/careers/applications";
                /** POST - Get a career application */
                readonly GET: "/admin/careers/applications/get";
                /** POST - Get a career application by reference id */
                readonly GET_BY_REFERENCE: "/admin/careers/applications/get-by-reference";
                /** POST - Update a career application status */
                readonly STATUS: "/admin/careers/applications/status";
            };
        };
        /**
         * Attachment management
         */
        readonly ATTACHMENTS: {
            /** POST - List attachments with filtering */
            readonly LIST: "/admin/attachments";
            /** POST - Update an attachment's moderation status */
            readonly UPDATE_STATUS: "/admin/attachments/update-status";
            /** POST - Delete an attachment */
            readonly DELETE: "/admin/attachments/delete";
        };
        /**
         * Analytics endpoints
         */
        readonly ANALYTICS: {
            /** POST - User analytics with time-series data */
            readonly USERS: "/admin/analytics/users";
            /** POST - Storage analytics */
            readonly STORAGE: "/admin/analytics/storage";
        };
        /**
         * Token management
         */
        readonly TOKENS: {
            /** POST - List authentication tokens */
            readonly LIST: "/admin/tokens";
        };
        /**
         * System information
         */
        readonly SYSTEM: {
            /** POST - Get system statistics */
            readonly STATS: "/admin/system/stats";
        };
        /**
         * Inference model catalog management
         */
        readonly INFERENCE_PROVIDERS: {
            readonly LIST: "/admin/inference-providers";
        };
        readonly INFERENCE_MODELS: {
            /** POST - List inference models */
            readonly LIST: "/admin/inference-models";
            /** POST - Create inference model */
            readonly CREATE: "/admin/inference-models/create";
            /** POST - Update inference model */
            readonly UPDATE: "/admin/inference-models/update";
            /** POST - Delete inference model */
            readonly DELETE: "/admin/inference-models/delete";
        };
        /**
         * AI control-plane administration: operation routes, model rate-limit
         * policies, and the inference attempt/usage ledger. Reads require the
         * inference-viewing permission; updates require inference administration.
         */
        readonly INFERENCE: {
            /** POST - List every registered operation with its route */
            readonly ROUTES: "/admin/inference/routes";
            /** POST - Update one operation route */
            readonly ROUTES_UPDATE: "/admin/inference/routes/update";
            /**
             * POST - Models selectable for one request or run. Gated by the
             * inference-model-override permission, not inference viewing.
             */
            readonly SELECTABLE_MODELS: "/admin/inference/selectable-models";
            /** POST - List model rate-limit policies */
            readonly RATE_LIMITS: "/admin/inference/rate-limits";
            /** POST - Update one model rate-limit policy */
            readonly RATE_LIMITS_UPDATE: "/admin/inference/rate-limits/update";
            /** POST - List inference attempts (filtered, paginated) */
            readonly ATTEMPTS: "/admin/inference/attempts";
            /** POST - Get one inference attempt by ledger id */
            readonly ATTEMPTS_GET: "/admin/inference/attempts/get";
            /** POST - Usage summary + provider/operation breakdown for a filtered attempt set */
            readonly USAGE: "/admin/inference/usage";
            /** POST - One operation's site model list (inference viewing) */
            readonly OPERATION_MODELS: "/admin/inference/operation-models/get";
            /** POST - Replace one operation's site model list (inference administration) */
            readonly OPERATION_MODELS_UPDATE: "/admin/inference/operation-models/update";
        };
        /**
         * Chat channel management
         */
        readonly CHAT_CHANNELS: {
            /** POST - List chat channels (admin) */
            readonly LIST: "/admin/channels";
            /** POST - Get chat channel details (admin) */
            readonly GET: "/admin/channels/get";
            /** POST - Update chat channel (admin) */
            readonly UPDATE: "/admin/channels/update";
            /** POST - Delete chat channel (admin) */
            readonly DELETE: "/admin/channels/delete";
            readonly PARTICIPANTS: {
                /** POST - List channel participants (admin) */
                readonly LIST: "/admin/channels/participants/list";
                /** POST - Add channel participants (admin) */
                readonly ADD: "/admin/channels/participants/add";
                /** POST - Remove channel participant (admin) */
                readonly REMOVE: "/admin/channels/participants/remove";
                /** POST - Update participant role (admin) */
                readonly UPDATE_ROLE: "/admin/channels/participants/role";
            };
        };
    };
    /**
     * Organization endpoints
     */
    readonly ORGANIZATIONS: {
        /** POST - Create new organization */
        readonly CREATE: "/organizations";
        /** POST - Get organization by ID */
        readonly GET: "/organizations/get";
        /** POST - Get organization by slug */
        readonly GET_BY_SLUG: "/organizations/get-by-slug";
        /** POST - Get current user's role in an organization (by id or slug) */
        readonly GET_MY_ROLE: "/organizations/role/get-my";
        /** PUT - Update organization */
        readonly UPDATE: "/organizations/update";
        /** DELETE - Delete organization */
        readonly DELETE: "/organizations/delete";
        /** POST - List user's organizations */
        readonly LIST: "/organizations/list";
        /** POST - Check if organization slug is available */
        readonly CHECK_SLUG: "/organizations/check-slug";
        /**
         * Organization membership management
         */
        readonly MEMBERS: {
            /** POST - Add user to organization */
            readonly ADD: "/organizations/members/add";
            /** POST - Add user by identifier (direct add or auto-add pending) */
            readonly ADD_BY_IDENTIFIER: "/organizations/members/add-by-identifier";
            /** POST - Invite user by email or username */
            readonly INVITE: "/organizations/members/invite";
            /** DELETE - Remove user from organization */
            readonly REMOVE: "/organizations/members/remove";
            /** PUT - Update user role in organization */
            readonly UPDATE_ROLE: "/organizations/members/update-role";
            /** POST - List organization members */
            readonly LIST: "/organizations/members/list";
            /** POST - Get individual organization member details */
            readonly GET: "/organizations/members/get";
        };
        /**
         * Organization invitation management (admin view)
         */
        readonly INVITATIONS: {
            /** POST - List pending invitations sent by organization */
            readonly LIST: "/organizations/invitations/list";
            /** POST - Cancel a pending invitation */
            readonly CANCEL: "/organizations/invitations/cancel";
        };
        /** Organization email domain management */
        readonly EMAIL_DOMAINS: {
            /** POST - Create organization email domain */
            readonly ADD: "/organizations/email-domains/add";
            /** DELETE - Remove organization email domain */
            readonly REMOVE: "/organizations/email-domains/remove";
            /** POST - List organization email domains */
            readonly LIST: "/organizations/email-domains/list";
        };
        /**
         * Organization hierarchy operations
         */
        readonly HIERARCHY: {
            /** POST - List organizations by parent (null for root orgs) */
            readonly LIST_BY_PARENT: "/organizations/list-by-parent";
            /** POST - Get organization hierarchy tree */
            readonly GET: "/organizations/hierarchy/get";
        };
        /**
         * Organization inference policy: provider allowlist and per-operation model narrowing.
         * Reads need the view-inference-policy role; updates need the manage-inference-policy role.
         */
        readonly INFERENCE_POLICY: {
            /** POST - Get the organization's inference policy */
            readonly GET: "/organizations/inference-policy/get";
            /** POST - Replace the organization's provider allowlist */
            readonly UPDATE: "/organizations/inference-policy/update";
            /** POST - Replace one operation's organization model policy */
            readonly OPERATION_UPDATE: "/organizations/inference-policy/operation/update";
        };
    };
    /**
     * Member-facing inference endpoints
     */
    readonly INFERENCE: {
        /** POST - Models the viewer may choose for one organization and operation */
        readonly MODEL_CHOICES: "/inference/model-choices";
    };
    /**
     * Notification inbox endpoints. Notifications are created server-side only.
     */
    readonly NOTIFICATIONS: {
        /** POST - List the current user's notifications, newest first */
        readonly LIST: "/notifications/list";
        /** POST - Get one notification */
        readonly GET: "/notifications/get";
        /** GET - Count unread notifications */
        readonly COUNT: "/notifications/count";
        /** POST - Mark notifications read at specific revisions (1-100 receipts) */
        readonly READ: "/notifications/read";
        /** POST - Claim the right to show an interruptive alert for a revision */
        readonly CLAIM_ALERT: "/notifications/alert/claim";
        /** GET/PUT - Notification preferences */
        readonly PREFERENCES: "/notifications/preferences";
    };
    /**
     * Telemetry endpoints
     */
    readonly FARO: {
        /** POST - Collect frontend telemetry */
        readonly COLLECT: "/faro/collect";
    };
};
/**
 * Type representing all available API paths
 */
export type ApiPath = typeof API_PATHS;
/**
 * Type for extracting all endpoint paths as string literals
 */
export type ApiEndpoint = (typeof API_PATHS.AUTH.EMAIL)[keyof typeof API_PATHS.AUTH.EMAIL] | (typeof API_PATHS.AUTH.OAUTH)[keyof typeof API_PATHS.AUTH.OAUTH] | (typeof API_PATHS.AUTH.PHONE)[keyof typeof API_PATHS.AUTH.PHONE] | (typeof API_PATHS.AUTH.SESSIONS)[keyof typeof API_PATHS.AUTH.SESSIONS] | typeof API_PATHS.AUTH.LOGOUT | typeof API_PATHS.AUTH.ADD_PASSWORD | typeof API_PATHS.AUTH.METHODS | typeof API_PATHS.AUTH.CHECK_USERNAME | typeof API_PATHS.USER.ME | typeof API_PATHS.USER.SETTINGS | (typeof API_PATHS.USER.PROFILE_PICTURE)[keyof typeof API_PATHS.USER.PROFILE_PICTURE] | (typeof API_PATHS.USER.PHONE)[keyof typeof API_PATHS.USER.PHONE] | (typeof API_PATHS.USER.USERNAME)[keyof typeof API_PATHS.USER.USERNAME] | (typeof API_PATHS.USER.INVITATIONS)[keyof typeof API_PATHS.USER.INVITATIONS] | (typeof API_PATHS.CONTACT)[keyof typeof API_PATHS.CONTACT] | (typeof API_PATHS.CAREERS.JOBS)[keyof typeof API_PATHS.CAREERS.JOBS] | (typeof API_PATHS.CAREERS.APPLICATIONS)[keyof typeof API_PATHS.CAREERS.APPLICATIONS] | (typeof API_PATHS.ATTACHMENTS)[keyof typeof API_PATHS.ATTACHMENTS] | typeof API_PATHS.ORGANIZATIONS.CREATE | typeof API_PATHS.ORGANIZATIONS.GET | typeof API_PATHS.ORGANIZATIONS.GET_BY_SLUG | typeof API_PATHS.ORGANIZATIONS.GET_MY_ROLE | typeof API_PATHS.ORGANIZATIONS.UPDATE | typeof API_PATHS.ORGANIZATIONS.DELETE | typeof API_PATHS.ORGANIZATIONS.LIST | typeof API_PATHS.ORGANIZATIONS.CHECK_SLUG | (typeof API_PATHS.ORGANIZATIONS.MEMBERS)[keyof typeof API_PATHS.ORGANIZATIONS.MEMBERS] | (typeof API_PATHS.ORGANIZATIONS.INVITATIONS)[keyof typeof API_PATHS.ORGANIZATIONS.INVITATIONS] | (typeof API_PATHS.ORGANIZATIONS.EMAIL_DOMAINS)[keyof typeof API_PATHS.ORGANIZATIONS.EMAIL_DOMAINS] | (typeof API_PATHS.ORGANIZATIONS.INFERENCE_POLICY)[keyof typeof API_PATHS.ORGANIZATIONS.INFERENCE_POLICY] | (typeof API_PATHS.INFERENCE)[keyof typeof API_PATHS.INFERENCE] | (typeof API_PATHS.ADMIN.USERS)[keyof typeof API_PATHS.ADMIN.USERS] | (typeof API_PATHS.ADMIN.ORGANIZATIONS)[keyof typeof API_PATHS.ADMIN.ORGANIZATIONS] | (typeof API_PATHS.ADMIN.ORGANIZATIONS.EMAIL_DOMAINS)[keyof typeof API_PATHS.ADMIN.ORGANIZATIONS.EMAIL_DOMAINS] | (typeof API_PATHS.ADMIN.CONTACT_MESSAGES)[keyof typeof API_PATHS.ADMIN.CONTACT_MESSAGES] | (typeof API_PATHS.ADMIN.CAREERS.JOBS)[keyof typeof API_PATHS.ADMIN.CAREERS.JOBS] | (typeof API_PATHS.ADMIN.CAREERS.APPLICATIONS)[keyof typeof API_PATHS.ADMIN.CAREERS.APPLICATIONS] | (typeof API_PATHS.ADMIN.ATTACHMENTS)[keyof typeof API_PATHS.ADMIN.ATTACHMENTS] | (typeof API_PATHS.ADMIN.ANALYTICS)[keyof typeof API_PATHS.ADMIN.ANALYTICS] | (typeof API_PATHS.ADMIN.TOKENS)[keyof typeof API_PATHS.ADMIN.TOKENS] | (typeof API_PATHS.ADMIN.SYSTEM)[keyof typeof API_PATHS.ADMIN.SYSTEM] | (typeof API_PATHS.ADMIN.INFERENCE_PROVIDERS)[keyof typeof API_PATHS.ADMIN.INFERENCE_PROVIDERS] | (typeof API_PATHS.ADMIN.INFERENCE_MODELS)[keyof typeof API_PATHS.ADMIN.INFERENCE_MODELS] | (typeof API_PATHS.ADMIN.INFERENCE)[keyof typeof API_PATHS.ADMIN.INFERENCE] | (typeof API_PATHS.ADMIN.CHAT_CHANNELS)[keyof typeof API_PATHS.ADMIN.CHAT_CHANNELS] | (typeof API_PATHS.ADMIN.CHAT_CHANNELS.PARTICIPANTS)[keyof typeof API_PATHS.ADMIN.CHAT_CHANNELS.PARTICIPANTS] | typeof API_PATHS.CHAT.MESSAGES.EDIT_HISTORY | (typeof API_PATHS.CHAT.PUBLIC)[keyof typeof API_PATHS.CHAT.PUBLIC] | typeof API_PATHS.CHAT.CHANNELS.SET_PUBLIC_READ | typeof API_PATHS.CHAT.CHANNELS.FORK | (typeof API_PATHS.NOTIFICATIONS)[keyof typeof API_PATHS.NOTIFICATIONS] | (typeof API_PATHS.FARO)[keyof typeof API_PATHS.FARO];
/**
 * Builds a full API path by combining the base prefix with the endpoint path.
 *
 * @param path - The endpoint path (e.g., API_PATHS.AUTH.EMAIL.LOGIN)
 * @param basePrefix - Optional custom base prefix (defaults to API_PATHS.BASE)
 * @returns The full API path
 *
 * @example
 * ```typescript
 * // Using default base prefix
 * const loginUrl = buildApiPath(API_PATHS.AUTH.EMAIL.LOGIN);
 * // Result: "/api/v1/auth/email/login"
 *
 * // Using custom base prefix
 * const customUrl = buildApiPath(API_PATHS.USER.ME, '/api/v2');
 * // Result: "/api/v2/user/me"
 *
 * // Using empty prefix for legacy support
 * const legacyUrl = buildApiPath(API_PATHS.USER.ME, '');
 * // Result: "/user/me"
 * ```
 */
export declare function buildApiPath(path: string, basePrefix?: string): string;
/**
 * HTTP methods for each endpoint
 */
export declare const API_METHODS: {
    readonly "/auth/email/create": "POST";
    readonly "/auth/email/login": "POST";
    readonly "/auth/email/change-password": "POST";
    readonly "/auth/email/reset-password": "POST";
    readonly "/auth/email/complete-verification": "POST";
    readonly "/auth/email/accept-invitation": "POST";
    readonly "/auth/email/complete-reset": "POST";
    readonly "/auth/oauth/providers": "GET";
    readonly "/auth/oauth/callback": "POST";
    readonly "/auth/phone/send-otp": "POST";
    readonly "/auth/phone/verify-otp": "POST";
    readonly "/auth/phone/resend-otp": "POST";
    readonly "/auth/sessions": "POST";
    readonly "/auth/sessions/revoke": "POST";
    readonly "/auth/sessions/revoke-others": "POST";
    readonly "/auth/logout": "POST";
    readonly "/auth/add-password": "POST";
    readonly "/auth/methods": "GET";
    readonly "/auth/check-username": "POST";
    readonly "/user/me": "GET";
    readonly "/user/settings": "GET" | "PUT";
    readonly "/user/settings/language": "PUT";
    readonly "/user/profile-picture/upload-url": "POST";
    readonly "/user/profile-picture": "DELETE";
    readonly "/user/phone/remove": "POST";
    readonly "/user/username": "PUT";
    readonly "/contact/submit": "POST";
    readonly "/careers/jobs": "POST";
    readonly "/careers/jobs/get-by-slug": "POST";
    readonly "/careers/applications/create": "POST";
    readonly "/careers/applications/my": "POST";
    readonly "/careers/applications/my/get-by-reference": "POST";
    readonly "/careers/applications/my/withdraw": "POST";
    readonly "/attachments/finalize": "POST";
    readonly "/user/invitations/list": "POST";
    readonly "/user/invitations/accept": "POST";
    readonly "/user/invitations/decline": "POST";
    readonly "/organizations": "POST";
    readonly "/organizations/get": "POST";
    readonly "/organizations/get-by-slug": "POST";
    readonly "/organizations/role/get-my": "POST";
    readonly "/organizations/update": "PUT";
    readonly "/organizations/delete": "DELETE";
    readonly "/organizations/check-slug": "POST";
    readonly "/organizations/members/add": "POST";
    readonly "/organizations/members/invite": "POST";
    readonly "/organizations/members/remove": "DELETE";
    readonly "/organizations/members/update-role": "PUT";
    readonly "/organizations/members/list": "POST";
    readonly "/organizations/members/get": "POST";
    readonly "/organizations/invitations/list": "POST";
    readonly "/organizations/invitations/cancel": "POST";
    readonly "/organizations/email-domains/add": "POST";
    readonly "/organizations/email-domains/remove": "DELETE";
    readonly "/organizations/email-domains/list": "POST";
    readonly "/organizations/list-by-parent": "POST";
    readonly "/organizations/hierarchy/get": "POST";
    readonly "/organizations/inference-policy/get": "POST";
    readonly "/organizations/inference-policy/update": "POST";
    readonly "/organizations/inference-policy/operation/update": "POST";
    readonly "/inference/model-choices": "POST";
    readonly "/inference/sessions/retarget": "POST";
    readonly "/inference/sessions/retarget-bulk": "POST";
    readonly "/chat/public/channels/get": "POST";
    readonly "/chat/public/messages/list": "POST";
    readonly "/chat/channels/public_read/set": "POST";
    readonly "/chat/channels/fork": "POST";
    readonly "/admin/users": "POST";
    readonly "/admin/users/get": "POST";
    readonly "/admin/users/create": "POST";
    readonly "/admin/users/resend-invitation": "POST";
    readonly "/admin/users/ban": "POST";
    readonly "/admin/users/change-type": "POST";
    readonly "/admin/users/change-username": "POST";
    readonly "/admin/users/username-change-history": "POST";
    readonly "/admin/users/delete": "POST";
    readonly "/admin/users/revoke-sessions": "POST";
    readonly "/admin/users/profile-picture/upload-url": "POST";
    readonly "/admin/users/profile-picture/clear": "POST";
    readonly "/admin/organizations/create": "POST";
    readonly "/admin/organizations/list-all": "POST";
    readonly "/admin/organizations/filter-metadata": "POST";
    readonly "/admin/organizations/change-type": "POST";
    readonly "/admin/organizations/members/add": "POST";
    readonly "/admin/organizations/members/add-by-identifier": "POST";
    readonly "/admin/organizations/members/update-role": "PUT";
    readonly "/admin/organizations/members/get": "POST";
    readonly "/admin/organizations/email-domains/create": "POST";
    readonly "/admin/organizations/email-domains/delete": "DELETE";
    readonly "/admin/organizations/email-domains/list": "POST";
    readonly "/admin/contact-messages": "POST";
    readonly "/admin/contact-messages/get": "POST";
    readonly "/admin/contact-messages/get-by-reference": "POST";
    readonly "/admin/careers/jobs": "POST";
    readonly "/admin/careers/jobs/get": "POST";
    readonly "/admin/careers/jobs/create": "POST";
    readonly "/admin/careers/jobs/update": "POST";
    readonly "/admin/careers/jobs/status": "POST";
    readonly "/admin/careers/applications": "POST";
    readonly "/admin/careers/applications/get": "POST";
    readonly "/admin/careers/applications/get-by-reference": "POST";
    readonly "/admin/careers/applications/status": "POST";
    readonly "/admin/attachments": "POST";
    readonly "/admin/attachments/update-status": "POST";
    readonly "/admin/attachments/delete": "POST";
    readonly "/admin/analytics/users": "POST";
    readonly "/admin/analytics/storage": "POST";
    readonly "/admin/tokens": "POST";
    readonly "/admin/system/stats": "POST";
    readonly "/admin/inference-providers": "POST";
    readonly "/admin/inference-models": "POST";
    readonly "/admin/inference-models/create": "POST";
    readonly "/admin/inference-models/update": "POST";
    readonly "/admin/inference-models/delete": "POST";
    readonly "/admin/inference/routes": "POST";
    readonly "/admin/inference/routes/update": "POST";
    readonly "/admin/inference/rate-limits": "POST";
    readonly "/admin/inference/rate-limits/update": "POST";
    readonly "/admin/inference/attempts": "POST";
    readonly "/admin/inference/attempts/get": "POST";
    readonly "/admin/inference/usage": "POST";
    readonly "/admin/inference/operation-models/get": "POST";
    readonly "/admin/inference/operation-models/update": "POST";
    readonly "/admin/channels": "POST";
    readonly "/admin/channels/get": "POST";
    readonly "/admin/channels/update": "POST";
    readonly "/admin/channels/delete": "POST";
    readonly "/admin/channels/participants/list": "POST";
    readonly "/admin/channels/participants/add": "POST";
    readonly "/admin/channels/participants/remove": "POST";
    readonly "/admin/channels/participants/role": "POST";
    readonly "/notifications/list": "POST";
    readonly "/notifications/get": "POST";
    readonly "/notifications/count": "GET";
    readonly "/notifications/read": "POST";
    readonly "/notifications/alert/claim": "POST";
    readonly "/notifications/preferences": "GET" | "PUT";
    readonly "/faro/collect": "POST";
};
/**
 * Authentication requirements for each endpoint
 */
export declare const API_AUTH_REQUIRED: {
    readonly "/auth/email/create": false;
    readonly "/auth/email/login": false;
    readonly "/auth/email/change-password": true;
    readonly "/auth/email/reset-password": false;
    readonly "/auth/email/complete-verification": false;
    readonly "/auth/email/accept-invitation": false;
    readonly "/auth/email/complete-reset": false;
    readonly "/auth/oauth/providers": false;
    readonly "/auth/oauth/callback": false;
    readonly "/auth/phone/send-otp": true;
    readonly "/auth/phone/verify-otp": true;
    readonly "/auth/phone/resend-otp": true;
    readonly "/auth/sessions": true;
    readonly "/auth/sessions/revoke": true;
    readonly "/auth/sessions/revoke-others": true;
    readonly "/auth/logout": true;
    readonly "/auth/add-password": true;
    readonly "/auth/methods": true;
    readonly "/auth/check-username": false;
    readonly "/user/me": true;
    readonly "/user/settings": true;
    readonly "/user/settings/language": true;
    readonly "/user/profile-picture/upload-url": true;
    readonly "/user/profile-picture": true;
    readonly "/user/phone/remove": true;
    readonly "/user/username": true;
    readonly "/contact/submit": false;
    readonly "/careers/jobs": false;
    readonly "/careers/jobs/get-by-slug": false;
    readonly "/careers/applications/create": true;
    readonly "/careers/applications/my": true;
    readonly "/careers/applications/my/get-by-reference": true;
    readonly "/careers/applications/my/withdraw": true;
    readonly "/attachments/finalize": true;
    readonly "/user/invitations/list": true;
    readonly "/user/invitations/accept": true;
    readonly "/user/invitations/decline": true;
    readonly "/organizations": true;
    readonly "/organizations/get": true;
    readonly "/organizations/get-by-slug": true;
    readonly "/organizations/role/get-my": true;
    readonly "/organizations/update": true;
    readonly "/organizations/delete": true;
    readonly "/organizations/check-slug": false;
    readonly "/organizations/members/add": true;
    readonly "/organizations/members/invite": true;
    readonly "/organizations/members/remove": true;
    readonly "/organizations/members/update-role": true;
    readonly "/organizations/members/list": true;
    readonly "/organizations/members/get": true;
    readonly "/organizations/invitations/list": true;
    readonly "/organizations/invitations/cancel": true;
    readonly "/organizations/email-domains/add": true;
    readonly "/organizations/email-domains/remove": true;
    readonly "/organizations/email-domains/list": true;
    readonly "/organizations/list-by-parent": true;
    readonly "/organizations/hierarchy/get": true;
    readonly "/organizations/inference-policy/get": true;
    readonly "/organizations/inference-policy/update": true;
    readonly "/organizations/inference-policy/operation/update": true;
    readonly "/inference/model-choices": true;
    readonly "/inference/sessions/retarget": true;
    readonly "/inference/sessions/retarget-bulk": true;
    readonly "/chat/public/channels/get": false;
    readonly "/chat/public/messages/list": false;
    readonly "/chat/channels/public_read/set": true;
    readonly "/chat/channels/fork": true;
    readonly "/admin/users": true;
    readonly "/admin/users/get": true;
    readonly "/admin/users/create": true;
    readonly "/admin/users/resend-invitation": true;
    readonly "/admin/users/ban": true;
    readonly "/admin/users/change-type": true;
    readonly "/admin/users/delete": true;
    readonly "/admin/users/revoke-sessions": true;
    readonly "/admin/users/profile-picture/upload-url": true;
    readonly "/admin/users/profile-picture/clear": true;
    readonly "/admin/organizations/create": true;
    readonly "/admin/organizations/list-all": true;
    readonly "/admin/organizations/filter-metadata": true;
    readonly "/admin/organizations/change-type": true;
    readonly "/admin/organizations/members/add": true;
    readonly "/admin/organizations/members/add-by-identifier": true;
    readonly "/admin/organizations/members/update-role": true;
    readonly "/admin/organizations/members/get": true;
    readonly "/admin/organizations/email-domains/create": true;
    readonly "/admin/organizations/email-domains/delete": true;
    readonly "/admin/organizations/email-domains/list": true;
    readonly "/admin/contact-messages": true;
    readonly "/admin/contact-messages/get": true;
    readonly "/admin/contact-messages/get-by-reference": true;
    readonly "/admin/careers/jobs": true;
    readonly "/admin/careers/jobs/get": true;
    readonly "/admin/careers/jobs/create": true;
    readonly "/admin/careers/jobs/update": true;
    readonly "/admin/careers/jobs/status": true;
    readonly "/admin/careers/applications": true;
    readonly "/admin/careers/applications/get": true;
    readonly "/admin/careers/applications/get-by-reference": true;
    readonly "/admin/careers/applications/status": true;
    readonly "/admin/attachments": true;
    readonly "/admin/attachments/update-status": true;
    readonly "/admin/attachments/delete": true;
    readonly "/admin/analytics/users": true;
    readonly "/admin/analytics/storage": true;
    readonly "/admin/tokens": true;
    readonly "/admin/system/stats": true;
    readonly "/admin/inference-providers": true;
    readonly "/admin/inference-models": true;
    readonly "/admin/inference-models/create": true;
    readonly "/admin/inference-models/update": true;
    readonly "/admin/inference-models/delete": true;
    readonly "/admin/inference/routes": true;
    readonly "/admin/inference/routes/update": true;
    readonly "/admin/inference/rate-limits": true;
    readonly "/admin/inference/rate-limits/update": true;
    readonly "/admin/inference/attempts": true;
    readonly "/admin/inference/attempts/get": true;
    readonly "/admin/inference/usage": true;
    readonly "/admin/inference/operation-models/get": true;
    readonly "/admin/inference/operation-models/update": true;
    readonly "/admin/channels": true;
    readonly "/admin/channels/get": true;
    readonly "/admin/channels/update": true;
    readonly "/admin/channels/delete": true;
    readonly "/admin/channels/participants/list": true;
    readonly "/admin/channels/participants/add": true;
    readonly "/admin/channels/participants/remove": true;
    readonly "/admin/channels/participants/role": true;
    readonly "/notifications/list": true;
    readonly "/notifications/get": true;
    readonly "/notifications/count": true;
    readonly "/notifications/read": true;
    readonly "/notifications/alert/claim": true;
    readonly "/notifications/preferences": true;
    readonly "/faro/collect": false;
};
/**
 * Rate limited endpoints
 */
export declare const API_RATE_LIMITED: {
    readonly "/auth/email/create": true;
    readonly "/auth/email/login": true;
    readonly "/auth/email/reset-password": true;
    readonly "/auth/email/complete-verification": true;
    readonly "/auth/oauth/callback": true;
    readonly "/contact/submit": true;
    readonly "/careers/applications/create": true;
    readonly "/careers/applications/my/withdraw": true;
    readonly "/chat/public/channels/get": true;
    readonly "/chat/public/messages/list": true;
    readonly "/chat/channels/fork": true;
};
//# sourceMappingURL=api-paths.d.ts.map