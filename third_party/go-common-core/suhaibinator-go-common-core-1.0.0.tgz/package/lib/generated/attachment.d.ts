import { BinaryReader, BinaryWriter } from "@bufbuild/protobuf/wire";
/** Status codes for attachment processing */
export declare enum AttachmentProcessingStatus {
    /** ATTACHMENT_PROCESSING_STATUS_UNSPECIFIED - Default unspecified state */
    ATTACHMENT_PROCESSING_STATUS_UNSPECIFIED = 0,
    /** ATTACHMENT_PROCESSING_STATUS_SUCCESS - Processing completed successfully */
    ATTACHMENT_PROCESSING_STATUS_SUCCESS = 1,
    /** ATTACHMENT_PROCESSING_STATUS_NOT_FOUND - Attachment was not found */
    ATTACHMENT_PROCESSING_STATUS_NOT_FOUND = 2,
    /** ATTACHMENT_PROCESSING_STATUS_INVALID_STATE - Invalid attachment state (e.g., not in pending_upload status) */
    ATTACHMENT_PROCESSING_STATUS_INVALID_STATE = 3,
    /** ATTACHMENT_PROCESSING_STATUS_VALIDATION_FAILED - Validation failed */
    ATTACHMENT_PROCESSING_STATUS_VALIDATION_FAILED = 4,
    /** ATTACHMENT_PROCESSING_STATUS_ERROR - General processing error */
    ATTACHMENT_PROCESSING_STATUS_ERROR = 5,
    /** ATTACHMENT_PROCESSING_STATUS_ALREADY_PROCESSED - Attachment is already processed */
    ATTACHMENT_PROCESSING_STATUS_ALREADY_PROCESSED = 6,
    UNRECOGNIZED = -1
}
export declare function attachmentProcessingStatusFromJSON(object: any): AttachmentProcessingStatus;
export declare function attachmentProcessingStatusToJSON(object: AttachmentProcessingStatus): string;
/**
 * Storage visibility of an attachment. Decided server-side by the object-type
 * registry, never by the client. Determines whether a returned URL is a stable,
 * anonymously fetchable (CDN-cacheable) URL or a short-lived presigned URL.
 * This enum is also the stored representation on the attachment row:
 * UNSPECIFIED marks rows that predate the visibility field, whose objects live
 * in the private bucket, so UNSPECIFIED always classifies as private.
 */
export declare enum AttachmentVisibility {
    /** ATTACHMENT_VISIBILITY_UNSPECIFIED - Default unspecified state (legacy rows; always treat as private) */
    ATTACHMENT_VISIBILITY_UNSPECIFIED = 0,
    /** ATTACHMENT_VISIBILITY_PRIVATE - Object lives in the private bucket; URLs are presigned and expire */
    ATTACHMENT_VISIBILITY_PRIVATE = 1,
    /** ATTACHMENT_VISIBILITY_PUBLIC - Object lives in the public bucket; URLs are stable and anonymously fetchable */
    ATTACHMENT_VISIBILITY_PUBLIC = 2,
    UNRECOGNIZED = -1
}
export declare function attachmentVisibilityFromJSON(object: any): AttachmentVisibility;
export declare function attachmentVisibilityToJSON(object: AttachmentVisibility): string;
/** Request message for finalizing multiple uploaded attachments */
export interface FinalizeAttachmentsRequest {
    /** List of attachment IDs to process */
    attachmentIds: bigint[];
}
/** Response message for attachment finalization */
export interface FinalizeAttachmentsResponse {
    /** Results for individual attachments */
    results: AttachmentResult[];
}
/** Result for an individual attachment */
export interface AttachmentResult {
    /** The attachment ID */
    attachmentId: bigint;
    /** Whether processing succeeded for this attachment */
    success: boolean;
    /** Status code for the processing result */
    status: AttachmentProcessingStatus;
    /** Optional error message if processing failed */
    errorMessage?: string | undefined;
}
/** Uploaded attachment data for existing files (edit mode) */
export interface UploadedAttachment {
    /** Unique identifier for this attachment */
    id: string;
    /** Original filename */
    filename: string;
    /** MIME content type */
    contentType: string;
    /** File size in bytes */
    size: bigint;
    /** Unsalted SHA-256 content hash; pending uploads expose the sender-declared hash. */
    contentHash: string;
    /** Attachment ID from the backend */
    attachmentId: bigint;
    /** Download URL for the existing file */
    downloadUrl: string;
    /** Optional thumbnail URL for images */
    thumbnailUrl?: string | undefined;
    /**
     * Storage visibility of the attachment. Tells the client whether download_url
     * (and thumbnail_url) is stable/cacheable or a presigned URL that expires.
     * Unset on servers that predate visibility support, and UNSPECIFIED for rows
     * stored before the field existed; treat both as private.
     */
    visibility?: AttachmentVisibility | undefined;
}
/** Attachment metadata for requests */
export interface AttachmentMetadata {
    /** SHA-256 hash of file content */
    contentHash: string;
    /** Original filename */
    filename: string;
    /** MIME type */
    contentType: string;
}
/** Attachment upload information for responses */
export interface AttachmentUploadInfo {
    /** Hash to identify which attachment (fileId) */
    contentHash: string;
    /** Presigned URL for upload */
    uploadUrl: string;
    /** Form data for upload */
    formData: {
        [key: string]: string;
    };
    /** Generated attachment ID */
    attachmentId: bigint;
    /** Upload URL expiry timestamp */
    expiry?: Date | undefined;
}
export interface AttachmentUploadInfo_FormDataEntry {
    key: string;
    value: string;
}
export declare const FinalizeAttachmentsRequest: MessageFns<FinalizeAttachmentsRequest>;
export declare const FinalizeAttachmentsResponse: MessageFns<FinalizeAttachmentsResponse>;
export declare const AttachmentResult: MessageFns<AttachmentResult>;
export declare const UploadedAttachment: MessageFns<UploadedAttachment>;
export declare const AttachmentMetadata: MessageFns<AttachmentMetadata>;
export declare const AttachmentUploadInfo: MessageFns<AttachmentUploadInfo>;
export declare const AttachmentUploadInfo_FormDataEntry: MessageFns<AttachmentUploadInfo_FormDataEntry>;
type Builtin = Date | Function | Uint8Array | string | number | boolean | bigint | undefined;
type DeepPartial<T> = T extends bigint ? string | number | bigint : T extends Builtin ? T : T extends globalThis.Array<infer U> ? globalThis.Array<DeepPartial<U>> : T extends ReadonlyArray<infer U> ? ReadonlyArray<DeepPartial<U>> : T extends {} ? {
    [K in keyof T]?: DeepPartial<T[K]>;
} : Partial<T>;
type KeysOfUnion<T> = T extends T ? keyof T : never;
type Exact<P, I extends P> = P extends Builtin ? P : P & {
    [K in keyof P]: Exact<P[K], I[K]>;
} & {
    [K in Exclude<keyof I, KeysOfUnion<P>>]: never;
};
interface MessageFns<T> {
    encode(message: T, writer?: BinaryWriter): BinaryWriter;
    decode(input: BinaryReader | Uint8Array, length?: number): T;
    fromJSON(object: any): T;
    toJSON(message: T): unknown;
    create<I extends Exact<DeepPartial<T>, I>>(base?: I): T;
    fromPartial<I extends Exact<DeepPartial<T>, I>>(object: I): T;
}
export {};
//# sourceMappingURL=attachment.d.ts.map