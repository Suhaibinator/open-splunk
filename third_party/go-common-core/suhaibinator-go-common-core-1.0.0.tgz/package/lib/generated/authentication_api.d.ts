import { BinaryReader, BinaryWriter } from "@bufbuild/protobuf/wire";
import { ActiveSession } from "./authentication";
import { PaginationRequest, PaginationResponse } from "./pagination";
export interface ListActiveSessionsRequest {
    pagination?: PaginationRequest | undefined;
}
export interface ListActiveSessionsResponse {
    sessions: ActiveSession[];
    pagination?: PaginationResponse | undefined;
}
export interface RevokeSessionRequest {
    sessionId: string;
}
export interface RevokeSessionResponse {
    sessionsRevoked: number;
}
export interface RevokeOtherSessionsRequest {
}
export interface RevokeOtherSessionsResponse {
    sessionsRevoked: number;
}
export declare const ListActiveSessionsRequest: MessageFns<ListActiveSessionsRequest>;
export declare const ListActiveSessionsResponse: MessageFns<ListActiveSessionsResponse>;
export declare const RevokeSessionRequest: MessageFns<RevokeSessionRequest>;
export declare const RevokeSessionResponse: MessageFns<RevokeSessionResponse>;
export declare const RevokeOtherSessionsRequest: MessageFns<RevokeOtherSessionsRequest>;
export declare const RevokeOtherSessionsResponse: MessageFns<RevokeOtherSessionsResponse>;
type Builtin = Date | Function | Uint8Array | string | number | boolean | bigint | undefined;
type DeepPartial<T> = T extends bigint ? string | number | bigint : T extends Builtin ? T : T extends globalThis.Array<infer U> ? globalThis.Array<DeepPartial<U>> : T extends ReadonlyArray<infer U> ? ReadonlyArray<DeepPartial<U>> : T extends {} ? {
    [K in keyof T]?: DeepPartial<T[K]>;
} : Partial<T>;
type KeysOfUnion<T> = T extends T ? keyof T : never;
type Exact<P, I extends P> = P extends Builtin ? P : P & {
    [K in keyof P]: Exact<P[K], I[K]>;
} & {
    [K in Exclude<keyof I, KeysOfUnion<P>>]: never;
};
interface MessageFns<T> {
    encode(message: T, writer?: BinaryWriter): BinaryWriter;
    decode(input: BinaryReader | Uint8Array, length?: number): T;
    fromJSON(object: any): T;
    toJSON(message: T): unknown;
    create<I extends Exact<DeepPartial<T>, I>>(base?: I): T;
    fromPartial<I extends Exact<DeepPartial<T>, I>>(object: I): T;
}
export {};
//# sourceMappingURL=authentication_api.d.ts.map