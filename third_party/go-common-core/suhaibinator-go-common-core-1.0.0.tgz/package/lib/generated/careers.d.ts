import { BinaryReader, BinaryWriter } from "@bufbuild/protobuf/wire";
import { AttachmentMetadata, AttachmentUploadInfo } from "./attachment";
import { PaginationRequest, PaginationResponse, SortRequest } from "./pagination";
/** CareerWorkplaceMode describes where the role is performed. */
export declare enum CareerWorkplaceMode {
    CAREER_WORKPLACE_MODE_UNSPECIFIED = 0,
    CAREER_WORKPLACE_MODE_ONSITE = 1,
    CAREER_WORKPLACE_MODE_HYBRID = 2,
    CAREER_WORKPLACE_MODE_REMOTE = 3,
    UNRECOGNIZED = -1
}
export declare function careerWorkplaceModeFromJSON(object: any): CareerWorkplaceMode;
export declare function careerWorkplaceModeToJSON(object: CareerWorkplaceMode): string;
/** CareerEmploymentType describes the engagement type for a role. */
export declare enum CareerEmploymentType {
    CAREER_EMPLOYMENT_TYPE_UNSPECIFIED = 0,
    CAREER_EMPLOYMENT_TYPE_FULL_TIME = 1,
    CAREER_EMPLOYMENT_TYPE_PART_TIME = 2,
    CAREER_EMPLOYMENT_TYPE_CONTRACT = 3,
    CAREER_EMPLOYMENT_TYPE_INTERNSHIP = 4,
    UNRECOGNIZED = -1
}
export declare function careerEmploymentTypeFromJSON(object: any): CareerEmploymentType;
export declare function careerEmploymentTypeToJSON(object: CareerEmploymentType): string;
/** CareerJobPostingStatus controls job visibility and application eligibility. */
export declare enum CareerJobPostingStatus {
    CAREER_JOB_POSTING_STATUS_UNSPECIFIED = 0,
    CAREER_JOB_POSTING_STATUS_DRAFT = 1,
    CAREER_JOB_POSTING_STATUS_PUBLISHED = 2,
    CAREER_JOB_POSTING_STATUS_CLOSED = 3,
    CAREER_JOB_POSTING_STATUS_ARCHIVED = 4,
    UNRECOGNIZED = -1
}
export declare function careerJobPostingStatusFromJSON(object: any): CareerJobPostingStatus;
export declare function careerJobPostingStatusToJSON(object: CareerJobPostingStatus): string;
/** CareerApplicationStatus tracks internal review state for a submitted application. */
export declare enum CareerApplicationStatus {
    CAREER_APPLICATION_STATUS_UNSPECIFIED = 0,
    CAREER_APPLICATION_STATUS_SUBMITTED = 1,
    CAREER_APPLICATION_STATUS_REVIEWING = 2,
    CAREER_APPLICATION_STATUS_INTERVIEWING = 3,
    CAREER_APPLICATION_STATUS_OFFERED = 4,
    CAREER_APPLICATION_STATUS_HIRED = 5,
    CAREER_APPLICATION_STATUS_REJECTED = 6,
    CAREER_APPLICATION_STATUS_WITHDRAWN = 7,
    /** CAREER_APPLICATION_STATUS_PENDING_RESUME_UPLOAD - Created by applicant but resume is not yet fully uploaded/vetted. */
    CAREER_APPLICATION_STATUS_PENDING_RESUME_UPLOAD = 8,
    UNRECOGNIZED = -1
}
export declare function careerApplicationStatusFromJSON(object: any): CareerApplicationStatus;
export declare function careerApplicationStatusToJSON(object: CareerApplicationStatus): string;
/** Request to list publicly visible career job postings. */
export declare enum ListCareerJobPostingsSortBy {
    LIST_CAREER_JOB_POSTINGS_SORT_BY_UNSPECIFIED = 0,
    LIST_CAREER_JOB_POSTINGS_SORT_BY_TITLE = 1,
    LIST_CAREER_JOB_POSTINGS_SORT_BY_TEAM = 2,
    LIST_CAREER_JOB_POSTINGS_SORT_BY_LOCATION_LABEL = 3,
    LIST_CAREER_JOB_POSTINGS_SORT_BY_PUBLISHED_AT = 4,
    LIST_CAREER_JOB_POSTINGS_SORT_BY_CLOSES_AT = 5,
    LIST_CAREER_JOB_POSTINGS_SORT_BY_CREATED_AT = 6,
    LIST_CAREER_JOB_POSTINGS_SORT_BY_UPDATED_AT = 7,
    LIST_CAREER_JOB_POSTINGS_SORT_BY_EMPLOYMENT_TYPE = 8,
    LIST_CAREER_JOB_POSTINGS_SORT_BY_WORKPLACE_MODE = 9,
    UNRECOGNIZED = -1
}
export declare function listCareerJobPostingsSortByFromJSON(object: any): ListCareerJobPostingsSortBy;
export declare function listCareerJobPostingsSortByToJSON(object: ListCareerJobPostingsSortBy): string;
/** CareerJobPosting is the canonical model for public and admin job posting views. */
export interface CareerJobPosting {
    id: bigint;
    slug: string;
    title: string;
    team: string;
    locationLabel: string;
    workplaceMode: CareerWorkplaceMode;
    employmentType: CareerEmploymentType;
    summary: string;
    description: string;
    status: CareerJobPostingStatus;
    publishedAt?: Date | undefined;
    closesAt?: Date | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
/** CareerApplication is the full stored application model used for internal/admin flows. */
export interface CareerApplication {
    id: bigint;
    referenceId: string;
    jobPostingId: bigint;
    jobTitleSnapshot: string;
    applicantName: string;
    email: string;
    phone: string;
    locationLabel: string;
    linkedinUrl: string;
    portfolioUrl: string;
    coverLetter: string;
    resumeAttachmentId: bigint;
    status: CareerApplicationStatus;
    adminNotes: string;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    /** Owner account for authenticated applicant self-service. */
    applicantUserId: bigint;
}
/** ApplicantCareerApplication is the applicant-facing self-service application model. */
export interface ApplicantCareerApplication {
    id: bigint;
    referenceId: string;
    jobPostingId: bigint;
    jobTitleSnapshot: string;
    applicantName: string;
    email: string;
    phone: string;
    locationLabel: string;
    linkedinUrl: string;
    portfolioUrl: string;
    coverLetter: string;
    resumeAttachmentId: bigint;
    status: CareerApplicationStatus;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    /** Owner account for authenticated applicant self-service. */
    applicantUserId: bigint;
}
export interface ListCareerJobPostingsRequest {
    pagination?: PaginationRequest | undefined;
    workplaceModeFilter: CareerWorkplaceMode;
    employmentTypeFilter: CareerEmploymentType;
    sort?: SortRequest | undefined;
    sortBy: ListCareerJobPostingsSortBy;
}
/** Response for listing public career job postings. */
export interface ListCareerJobPostingsResponse {
    jobs: CareerJobPosting[];
    pagination?: PaginationResponse | undefined;
}
/** Request to fetch a career job posting by slug. */
export interface GetCareerJobPostingBySlugRequest {
    slug: string;
}
/** Response containing a public job posting. */
export interface GetCareerJobPostingBySlugResponse {
    job?: CareerJobPosting | undefined;
}
/** Request to create an authenticated career application and receive resume upload instructions. */
export interface CreateCareerApplicationRequest {
    jobSlug: string;
    applicantName: string;
    email: string;
    phone: string;
    locationLabel: string;
    linkedinUrl: string;
    portfolioUrl: string;
    coverLetter: string;
    /** Single resume metadata for generating the upload target. */
    resumeAttachment?: AttachmentMetadata | undefined;
}
/** Response containing created application data and resume upload instructions. */
export interface CreateCareerApplicationResponse {
    referenceId: string;
    application?: ApplicantCareerApplication | undefined;
    resumeUpload?: AttachmentUploadInfo | undefined;
}
/** Request to list authenticated user's own applications. */
export interface ListMyCareerApplicationsRequest {
    pagination?: PaginationRequest | undefined;
    statusFilter: CareerApplicationStatus;
}
/** Response containing authenticated user's own applications. */
export interface ListMyCareerApplicationsResponse {
    applications: ApplicantCareerApplication[];
    pagination?: PaginationResponse | undefined;
}
/** Request to get one authenticated user's application by reference. */
export interface GetMyCareerApplicationByReferenceIDRequest {
    referenceId: string;
}
/** Response containing one authenticated user's application by reference. */
export interface GetMyCareerApplicationByReferenceIDResponse {
    application?: ApplicantCareerApplication | undefined;
}
/** Request to withdraw one authenticated user's application by reference. */
export interface WithdrawMyCareerApplicationRequest {
    referenceId: string;
}
/** Response after withdrawing one authenticated user's application. */
export interface WithdrawMyCareerApplicationResponse {
    application?: ApplicantCareerApplication | undefined;
}
export declare const CareerJobPosting: MessageFns<CareerJobPosting>;
export declare const CareerApplication: MessageFns<CareerApplication>;
export declare const ApplicantCareerApplication: MessageFns<ApplicantCareerApplication>;
export declare const ListCareerJobPostingsRequest: MessageFns<ListCareerJobPostingsRequest>;
export declare const ListCareerJobPostingsResponse: MessageFns<ListCareerJobPostingsResponse>;
export declare const GetCareerJobPostingBySlugRequest: MessageFns<GetCareerJobPostingBySlugRequest>;
export declare const GetCareerJobPostingBySlugResponse: MessageFns<GetCareerJobPostingBySlugResponse>;
export declare const CreateCareerApplicationRequest: MessageFns<CreateCareerApplicationRequest>;
export declare const CreateCareerApplicationResponse: MessageFns<CreateCareerApplicationResponse>;
export declare const ListMyCareerApplicationsRequest: MessageFns<ListMyCareerApplicationsRequest>;
export declare const ListMyCareerApplicationsResponse: MessageFns<ListMyCareerApplicationsResponse>;
export declare const GetMyCareerApplicationByReferenceIDRequest: MessageFns<GetMyCareerApplicationByReferenceIDRequest>;
export declare const GetMyCareerApplicationByReferenceIDResponse: MessageFns<GetMyCareerApplicationByReferenceIDResponse>;
export declare const WithdrawMyCareerApplicationRequest: MessageFns<WithdrawMyCareerApplicationRequest>;
export declare const WithdrawMyCareerApplicationResponse: MessageFns<WithdrawMyCareerApplicationResponse>;
type Builtin = Date | Function | Uint8Array | string | number | boolean | bigint | undefined;
type DeepPartial<T> = T extends bigint ? string | number | bigint : T extends Builtin ? T : T extends globalThis.Array<infer U> ? globalThis.Array<DeepPartial<U>> : T extends ReadonlyArray<infer U> ? ReadonlyArray<DeepPartial<U>> : T extends {} ? {
    [K in keyof T]?: DeepPartial<T[K]>;
} : Partial<T>;
type KeysOfUnion<T> = T extends T ? keyof T : never;
type Exact<P, I extends P> = P extends Builtin ? P : P & {
    [K in keyof P]: Exact<P[K], I[K]>;
} & {
    [K in Exclude<keyof I, KeysOfUnion<P>>]: never;
};
interface MessageFns<T> {
    encode(message: T, writer?: BinaryWriter): BinaryWriter;
    decode(input: BinaryReader | Uint8Array, length?: number): T;
    fromJSON(object: any): T;
    toJSON(message: T): unknown;
    create<I extends Exact<DeepPartial<T>, I>>(base?: I): T;
    fromPartial<I extends Exact<DeepPartial<T>, I>>(object: I): T;
}
export {};
//# sourceMappingURL=careers.d.ts.map