import { BinaryReader, BinaryWriter } from "@bufbuild/protobuf/wire";
/**
 * RealtimeEvent is the server-to-client envelope for every realtime frame.
 *
 * go-common never enumerates application payload types: `payload` carries an
 * application-defined proto message serialized by the publisher, which keeps
 * application event schemas in application repositories. Chat's payload message
 * (ChatWebSocketEvent) lives in go-common only because chat is a go-common feature.
 *
 * There is deliberately no `sequence` field. Per-topic monotonic sequencing would
 * require an authority that an arbitrary multi-producer topic does not have; chat's
 * stream dedupe is scoped per (channel, message) inside its own payload.
 * Applications needing versions or sequences carry them in their payload message,
 * where they can define the authority.
 */
export interface RealtimeEvent {
    /**
     * Topic the event was published on. Two special values:
     *  - "user": the recipient's own user topic. It is recipient-relative so that one
     *    envelope marshal can be shared by every recipient of a user-topic fan-out.
     *  - "realtime.control": control frames (CommandResult).
     */
    topic: string;
    /**
     * Namespaced event type, e.g. "chat.message_sent". The bundled clients log (never silently
     * skip) frames whose event type they do not recognize.
     */
    eventType: string;
    /** When the event occurred (server time). */
    occurredAt?: Date | undefined;
    /**
     * Serialized app-defined proto message. This is the firewall between go-common's
     * transport and application event schemas.
     */
    payload: Uint8Array;
}
/**
 * RealtimeCommand is the client-to-server envelope for every realtime frame.
 *
 * Subscribe and unsubscribe are handled by the hub itself; every other type is
 * dispatched to a registered command handler.
 */
export interface RealtimeCommand {
    /** Command type, e.g. "subscribe", "unsubscribe", "chat.typing". */
    type: string;
    /** Client-generated request ID used to correlate acks and errors (optional). */
    requestId: string;
    /** Command-type-specific serialized proto payload. */
    payload: Uint8Array;
}
/**
 * RealtimeSubscribeCommand is the payload of a "subscribe" RealtimeCommand.
 *
 * Clients never subscribe to the reserved "user.*" and "realtime.*" namespaces:
 * the connection's own user topic is subscribed automatically at registration and
 * anyone else's is forbidden, so reserved-namespace topics are rejected with
 * "reserved_topic".
 */
export interface RealtimeSubscribeCommand {
    /** Topics to subscribe to. Batches are bounded server-side and fail per topic. */
    topics: string[];
}
/** RealtimeUnsubscribeCommand is the payload of an "unsubscribe" RealtimeCommand. */
export interface RealtimeUnsubscribeCommand {
    /** Topics to unsubscribe from. */
    topics: string[];
}
/**
 * CommandResult reports the outcome of a subscribe or unsubscribe command. It is
 * delivered as a RealtimeEvent on topic "realtime.control" with event_type
 * "realtime.command_result", enqueued before any event for a newly subscribed topic.
 *
 * Results are always explicit: a failed subscribe is reported per topic, never
 * silently dropped, because the client batches topics from independent consumers
 * into a single command and each consumer needs its own outcome.
 */
export interface CommandResult {
    /** request_id copied from the originating RealtimeCommand. */
    requestId: string;
    /** Whether every topic in the command succeeded. */
    ok: boolean;
    /** Per-topic outcome. */
    topics: TopicResult[];
}
/** TopicResult is the outcome of one topic within a CommandResult. */
export interface TopicResult {
    /** Topic this result refers to. */
    topic: string;
    /** Whether the operation succeeded for this topic. */
    ok: boolean;
    /**
     * Failure reason when ok is false: "unauthorized_topic" | "unknown_namespace" |
     * "invalid_topic" | "subscription_limit" | "reserved_topic" | "authorizer_timeout".
     *
     * "authorizer_timeout" is deliberately distinct from "unauthorized_topic": the
     * authorizer never reached a decision (the command's shared auth budget expired),
     * so it says nothing about this user's access and the client may retry rather than
     * treating the topic as forbidden.
     */
    errorCode: string;
}
export declare const RealtimeEvent: MessageFns<RealtimeEvent>;
export declare const RealtimeCommand: MessageFns<RealtimeCommand>;
export declare const RealtimeSubscribeCommand: MessageFns<RealtimeSubscribeCommand>;
export declare const RealtimeUnsubscribeCommand: MessageFns<RealtimeUnsubscribeCommand>;
export declare const CommandResult: MessageFns<CommandResult>;
export declare const TopicResult: MessageFns<TopicResult>;
type Builtin = Date | Function | Uint8Array | string | number | boolean | bigint | undefined;
type DeepPartial<T> = T extends bigint ? string | number | bigint : T extends Builtin ? T : T extends globalThis.Array<infer U> ? globalThis.Array<DeepPartial<U>> : T extends ReadonlyArray<infer U> ? ReadonlyArray<DeepPartial<U>> : T extends {} ? {
    [K in keyof T]?: DeepPartial<T[K]>;
} : Partial<T>;
type KeysOfUnion<T> = T extends T ? keyof T : never;
type Exact<P, I extends P> = P extends Builtin ? P : P & {
    [K in keyof P]: Exact<P[K], I[K]>;
} & {
    [K in Exclude<keyof I, KeysOfUnion<P>>]: never;
};
interface MessageFns<T> {
    encode(message: T, writer?: BinaryWriter): BinaryWriter;
    decode(input: BinaryReader | Uint8Array, length?: number): T;
    fromJSON(object: any): T;
    toJSON(message: T): unknown;
    create<I extends Exact<DeepPartial<T>, I>>(base?: I): T;
    fromPartial<I extends Exact<DeepPartial<T>, I>>(object: I): T;
}
export {};
//# sourceMappingURL=realtime_ws.d.ts.map