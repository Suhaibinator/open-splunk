import { BinaryReader, BinaryWriter } from "@bufbuild/protobuf/wire";
import { AttachmentVisibility } from "./attachment";
import { TokenStatus, TokenType } from "./authentication";
import { CareerApplication, CareerApplicationStatus, CareerEmploymentType, CareerJobPosting, CareerJobPostingStatus, CareerWorkplaceMode } from "./careers";
import { Channel, ChannelParticipant, ChannelRole, ChannelType } from "./chat";
import { InferenceAPI, InferenceModel } from "./inference";
import { OrganizationEmailDomain, OrganizationInvitation, OrganizationMemberDetails, OrganizationRole, OrganizationUser } from "./organization";
import { FilterRequest, PaginationRequest, PaginationResponse, SortRequest } from "./pagination";
import { User, UserIdentifierType, UserType } from "./user";
export declare enum AdminListUsersSortBy {
    ADMIN_LIST_USERS_SORT_BY_UNSPECIFIED = 0,
    ADMIN_LIST_USERS_SORT_BY_EMAIL = 1,
    ADMIN_LIST_USERS_SORT_BY_USERNAME = 2,
    ADMIN_LIST_USERS_SORT_BY_USER_TYPE = 3,
    ADMIN_LIST_USERS_SORT_BY_CREATED_AT = 4,
    ADMIN_LIST_USERS_SORT_BY_UPDATED_AT = 5,
    ADMIN_LIST_USERS_SORT_BY_LAST_LOGIN = 6,
    UNRECOGNIZED = -1
}
export declare function adminListUsersSortByFromJSON(object: any): AdminListUsersSortBy;
export declare function adminListUsersSortByToJSON(object: AdminListUsersSortBy): string;
/** Request to list username change audit history with filtering and pagination. */
export declare enum AdminListUsernameChangeHistorySortBy {
    ADMIN_LIST_USERNAME_CHANGE_HISTORY_SORT_BY_UNSPECIFIED = 0,
    ADMIN_LIST_USERNAME_CHANGE_HISTORY_SORT_BY_CREATED_AT = 1,
    ADMIN_LIST_USERNAME_CHANGE_HISTORY_SORT_BY_TARGET_USER_ID = 2,
    ADMIN_LIST_USERNAME_CHANGE_HISTORY_SORT_BY_ACTOR_USER_ID = 3,
    ADMIN_LIST_USERNAME_CHANGE_HISTORY_SORT_BY_OLD_USERNAME = 4,
    ADMIN_LIST_USERNAME_CHANGE_HISTORY_SORT_BY_NEW_USERNAME = 5,
    UNRECOGNIZED = -1
}
export declare function adminListUsernameChangeHistorySortByFromJSON(object: any): AdminListUsernameChangeHistorySortBy;
export declare function adminListUsernameChangeHistorySortByToJSON(object: AdminListUsernameChangeHistorySortBy): string;
/** Human account authentication setup chosen by an administrator. */
export declare enum AdminUserAccessMode {
    /** ADMIN_USER_ACCESS_MODE_UNSPECIFIED - Defaults to OAuth only */
    ADMIN_USER_ACCESS_MODE_UNSPECIFIED = 0,
    ADMIN_USER_ACCESS_MODE_OAUTH_ONLY = 1,
    ADMIN_USER_ACCESS_MODE_INVITATION = 2,
    ADMIN_USER_ACCESS_MODE_PASSWORD = 3,
    UNRECOGNIZED = -1
}
export declare function adminUserAccessModeFromJSON(object: any): AdminUserAccessMode;
export declare function adminUserAccessModeToJSON(object: AdminUserAccessMode): string;
/** Request to list contact messages with filtering and pagination */
export declare enum AdminListContactMessagesSortBy {
    ADMIN_LIST_CONTACT_MESSAGES_SORT_BY_UNSPECIFIED = 0,
    ADMIN_LIST_CONTACT_MESSAGES_SORT_BY_EMAIL = 1,
    ADMIN_LIST_CONTACT_MESSAGES_SORT_BY_CREATED_AT = 2,
    UNRECOGNIZED = -1
}
export declare function adminListContactMessagesSortByFromJSON(object: any): AdminListContactMessagesSortBy;
export declare function adminListContactMessagesSortByToJSON(object: AdminListContactMessagesSortBy): string;
export declare enum AdminListCareerJobPostingsSortBy {
    ADMIN_LIST_CAREER_JOB_POSTINGS_SORT_BY_UNSPECIFIED = 0,
    ADMIN_LIST_CAREER_JOB_POSTINGS_SORT_BY_TITLE = 1,
    ADMIN_LIST_CAREER_JOB_POSTINGS_SORT_BY_TEAM = 2,
    ADMIN_LIST_CAREER_JOB_POSTINGS_SORT_BY_LOCATION_LABEL = 3,
    ADMIN_LIST_CAREER_JOB_POSTINGS_SORT_BY_STATUS = 4,
    ADMIN_LIST_CAREER_JOB_POSTINGS_SORT_BY_PUBLISHED_AT = 5,
    ADMIN_LIST_CAREER_JOB_POSTINGS_SORT_BY_CLOSES_AT = 6,
    ADMIN_LIST_CAREER_JOB_POSTINGS_SORT_BY_CREATED_AT = 7,
    ADMIN_LIST_CAREER_JOB_POSTINGS_SORT_BY_UPDATED_AT = 8,
    UNRECOGNIZED = -1
}
export declare function adminListCareerJobPostingsSortByFromJSON(object: any): AdminListCareerJobPostingsSortBy;
export declare function adminListCareerJobPostingsSortByToJSON(object: AdminListCareerJobPostingsSortBy): string;
/** Request to list applications in the admin careers interface. */
export declare enum AdminListCareerApplicationsSortBy {
    ADMIN_LIST_CAREER_APPLICATIONS_SORT_BY_UNSPECIFIED = 0,
    ADMIN_LIST_CAREER_APPLICATIONS_SORT_BY_REFERENCE_ID = 1,
    ADMIN_LIST_CAREER_APPLICATIONS_SORT_BY_EMAIL = 2,
    ADMIN_LIST_CAREER_APPLICATIONS_SORT_BY_STATUS = 3,
    ADMIN_LIST_CAREER_APPLICATIONS_SORT_BY_JOB_POSTING_ID = 4,
    ADMIN_LIST_CAREER_APPLICATIONS_SORT_BY_JOB_TITLE_SNAPSHOT = 5,
    ADMIN_LIST_CAREER_APPLICATIONS_SORT_BY_CREATED_AT = 6,
    ADMIN_LIST_CAREER_APPLICATIONS_SORT_BY_UPDATED_AT = 7,
    UNRECOGNIZED = -1
}
export declare function adminListCareerApplicationsSortByFromJSON(object: any): AdminListCareerApplicationsSortBy;
export declare function adminListCareerApplicationsSortByToJSON(object: AdminListCareerApplicationsSortBy): string;
/** Request to list attachments with filtering and pagination */
export declare enum AdminListAttachmentsSortBy {
    ADMIN_LIST_ATTACHMENTS_SORT_BY_UNSPECIFIED = 0,
    ADMIN_LIST_ATTACHMENTS_SORT_BY_SIZE = 1,
    ADMIN_LIST_ATTACHMENTS_SORT_BY_CONTENT_TYPE = 2,
    ADMIN_LIST_ATTACHMENTS_SORT_BY_UPLOAD_STATUS = 3,
    ADMIN_LIST_ATTACHMENTS_SORT_BY_CREATED_AT = 4,
    UNRECOGNIZED = -1
}
export declare function adminListAttachmentsSortByFromJSON(object: any): AdminListAttachmentsSortBy;
export declare function adminListAttachmentsSortByToJSON(object: AdminListAttachmentsSortBy): string;
/** Request to list chat channels with filtering and pagination. */
export declare enum AdminListChatChannelsSortBy {
    ADMIN_LIST_CHAT_CHANNELS_SORT_BY_UNSPECIFIED = 0,
    ADMIN_LIST_CHAT_CHANNELS_SORT_BY_ID = 1,
    ADMIN_LIST_CHAT_CHANNELS_SORT_BY_NAME = 2,
    ADMIN_LIST_CHAT_CHANNELS_SORT_BY_CREATED_AT = 3,
    ADMIN_LIST_CHAT_CHANNELS_SORT_BY_UPDATED_AT = 4,
    ADMIN_LIST_CHAT_CHANNELS_SORT_BY_LAST_MESSAGE_AT = 5,
    ADMIN_LIST_CHAT_CHANNELS_SORT_BY_CHANNEL_TYPE = 6,
    ADMIN_LIST_CHAT_CHANNELS_SORT_BY_CREATED_BY_USER_ID = 7,
    UNRECOGNIZED = -1
}
export declare function adminListChatChannelsSortByFromJSON(object: any): AdminListChatChannelsSortBy;
export declare function adminListChatChannelsSortByToJSON(object: AdminListChatChannelsSortBy): string;
/** Request to list authentication tokens */
export declare enum AdminListTokensSortBy {
    ADMIN_LIST_TOKENS_SORT_BY_UNSPECIFIED = 0,
    ADMIN_LIST_TOKENS_SORT_BY_ISSUED_AT = 1,
    ADMIN_LIST_TOKENS_SORT_BY_EXPIRES_AT = 2,
    ADMIN_LIST_TOKENS_SORT_BY_LAST_USED_AT = 3,
    ADMIN_LIST_TOKENS_SORT_BY_USER_ID = 4,
    ADMIN_LIST_TOKENS_SORT_BY_TOKEN_TYPE = 5,
    UNRECOGNIZED = -1
}
export declare function adminListTokensSortByFromJSON(object: any): AdminListTokensSortBy;
export declare function adminListTokensSortByToJSON(object: AdminListTokensSortBy): string;
/** Request to list users with filtering and pagination */
export interface AdminListUsersRequest {
    pagination?: PaginationRequest | undefined;
    /** Search by email, username, name, or exact numeric user ID */
    search: string;
    /** Filter by user type */
    userTypeFilter: UserType;
    /** Filter by banned status (null = all, true = banned only, false = active only) */
    bannedFilter?: boolean | undefined;
    /** Sort parameters */
    sort?: SortRequest | undefined;
    /** Common filter parameters */
    filter?: FilterRequest | undefined;
    sortBy: AdminListUsersSortBy;
    /** Filter by effective email-verification status */
    emailVerifiedFilter?: boolean | undefined;
    /** Filter bot (true) vs human (false) accounts */
    isBotFilter?: boolean | undefined;
}
/** Detailed user information for admin view */
export interface AdminUserDetails {
    user?: User | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    lastLogin?: Date | undefined;
    totalLogins: number;
    activeSessions: number;
    /** ["password", "google", "github"] */
    authMethods: string[];
    totalAttachments: bigint;
    storageUsedBytes: bigint;
    emailVerified: boolean;
    /** Invitation issued for current email; password setup incomplete */
    invitationPending: boolean;
}
/** Response for listing users with pagination */
export interface AdminListUsersResponse {
    users: AdminUserDetails[];
    pagination?: PaginationResponse | undefined;
}
/** Request to get a specific user's details */
export interface AdminGetUserRequest {
    userId: bigint;
}
/** Response with user details */
export interface AdminGetUserResponse {
    user?: AdminUserDetails | undefined;
}
/** Request to ban/unban a user */
export interface AdminBanUserRequest {
    userId: bigint;
    /** true to ban, false to unban */
    banned: boolean;
    /** Reason for ban/unban */
    reason: string;
}
/** Response for ban/unban operation */
export interface AdminBanUserResponse {
}
/** Request to change a user's type/role */
export interface AdminChangeUserTypeRequest {
    userId: bigint;
    newUserType: UserType;
    /** Reason for change */
    reason: string;
}
/** Response for user type change */
export interface AdminChangeUserTypeResponse {
}
/**
 * Request to change a user's username.
 * This operation should be audit logged with both actor and target user context.
 */
export interface AdminChangeUsernameRequest {
    userId: bigint;
    newUsername: string;
    /** Reason for username change */
    reason: string;
}
/** Response for username change */
export interface AdminChangeUsernameResponse {
}
/** Username change audit entry for admin history views. */
export interface AdminUsernameChangeHistoryEntry {
    id: bigint;
    targetUserId: bigint;
    oldUsername: string;
    newUsername: string;
    /** Null for system-initiated changes */
    actorUserId?: bigint | undefined;
    /** Plain-text reason (includes actor kind) */
    reason: string;
    createdAt?: Date | undefined;
    /** Embedded target user with attribute filtering */
    targetUser?: User | undefined;
    /** Embedded actor user with attribute filtering */
    actorUser?: User | undefined;
}
export interface AdminListUsernameChangeHistoryRequest {
    pagination?: PaginationRequest | undefined;
    targetUserIdFilter?: bigint | undefined;
    actorUserIdFilter?: bigint | undefined;
    /** Match old/new username */
    usernameFilter: string;
    /** Inclusive lower bound */
    fromTime?: Date | undefined;
    /** Inclusive upper bound */
    toTime?: Date | undefined;
    /** Default: created_at desc */
    sort?: SortRequest | undefined;
    /** Common filter parameters */
    filter?: FilterRequest | undefined;
    sortBy: AdminListUsernameChangeHistorySortBy;
}
/** Response for listing username change audit history. */
export interface AdminListUsernameChangeHistoryResponse {
    entries: AdminUsernameChangeHistoryEntry[];
    pagination?: PaginationResponse | undefined;
}
/** Request to delete a user account */
export interface AdminDeleteUserRequest {
    userId: bigint;
    /** Whether to delete user's files */
    deleteAttachments: boolean;
    /** Reason for deletion */
    reason: string;
}
/** Response for user deletion */
export interface AdminDeleteUserResponse {
}
/** Request to revoke all user sessions */
export interface AdminRevokeUserSessionsRequest {
    userId: bigint;
    reason: string;
}
/** Response for session revocation */
export interface AdminRevokeUserSessionsResponse {
    sessionsRevoked: number;
}
/** Request to create a presigned POST upload for a user's new profile picture */
export interface AdminCreateUserProfilePictureUploadURLRequest {
    userId: bigint;
    filename: string;
    contentType?: string | undefined;
}
/** Response for profile picture upload URL creation */
export interface AdminCreateUserProfilePictureUploadURLResponse {
    uploadUrl: string;
    formData: {
        [key: string]: string;
    };
    attachmentId: bigint;
    expiry?: Date | undefined;
}
export interface AdminCreateUserProfilePictureUploadURLResponse_FormDataEntry {
    key: string;
    value: string;
}
/** Request to clear a user's profile picture */
export interface AdminClearUserProfilePictureRequest {
    userId: bigint;
}
/** Response for clearing user profile picture */
export interface AdminClearUserProfilePictureResponse {
}
export interface AdminCreateUserRequest {
    email: string;
    username: string;
    firstName: string;
    lastName: string;
    userType: UserType;
    reason?: string | undefined;
    isBot: boolean;
    accessMode: AdminUserAccessMode;
    password?: string | undefined;
    frontendOrigin?: string | undefined;
}
export interface AdminCreateUserResponse {
    user?: AdminUserDetails | undefined;
}
export interface AdminResendUserInvitationRequest {
    userId: bigint;
    frontendOrigin?: string | undefined;
}
export interface AdminResendUserInvitationResponse {
}
/** Contact message details for admin view */
export interface AdminContactMessage {
    id: bigint;
    /** Optional - null if submitted by non-user */
    userId: bigint;
    name: string;
    email: string;
    subject: string;
    message: string;
    ipAddress: string;
    userAgent: string;
    /** "pending", "reviewed", "responded", "spam" */
    status: string;
    adminNotes: string;
    /** Trace ID for tracking */
    referenceId: string;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export interface AdminListContactMessagesRequest {
    pagination?: PaginationRequest | undefined;
    /** Filter by status */
    statusFilter: string;
    /** Filter by email */
    emailFilter: string;
    /** Sort parameters */
    sort?: SortRequest | undefined;
    /** Common filter parameters */
    filter?: FilterRequest | undefined;
    sortBy: AdminListContactMessagesSortBy;
}
/** Response for listing contact messages with pagination */
export interface AdminListContactMessagesResponse {
    messages: AdminContactMessage[];
    pagination?: PaginationResponse | undefined;
}
/** Request to get a specific contact message */
export interface AdminGetContactMessageRequest {
    messageId: bigint;
}
/** Response with contact message details */
export interface AdminGetContactMessageResponse {
    message?: AdminContactMessage | undefined;
}
/** Request to get a contact message by reference ID */
export interface AdminGetContactMessageByReferenceIDRequest {
    referenceId: string;
}
/** Response with contact message details (reuses existing response) */
export interface AdminGetContactMessageByReferenceIDResponse {
    message?: AdminContactMessage | undefined;
}
/** Request to list job postings in the admin careers interface. */
export interface AdminListCareerJobPostingsRequest {
    pagination?: PaginationRequest | undefined;
    statusFilter: CareerJobPostingStatus;
    teamFilter: string;
    locationFilter: string;
    sort?: SortRequest | undefined;
    filter?: FilterRequest | undefined;
    sortBy: AdminListCareerJobPostingsSortBy;
}
/** Response for listing job postings in admin. */
export interface AdminListCareerJobPostingsResponse {
    jobs: CareerJobPosting[];
    pagination?: PaginationResponse | undefined;
}
/** Request to fetch a specific job posting by id in admin. */
export interface AdminGetCareerJobPostingRequest {
    jobPostingId: bigint;
}
/** Response containing a specific admin job posting. */
export interface AdminGetCareerJobPostingResponse {
    job?: CareerJobPosting | undefined;
}
/** Request to create a new job posting. */
export interface AdminCreateCareerJobPostingRequest {
    slug: string;
    title: string;
    team: string;
    locationLabel: string;
    workplaceMode: CareerWorkplaceMode;
    employmentType: CareerEmploymentType;
    summary: string;
    description: string;
    closesAt?: Date | undefined;
}
/** Response for creating a job posting. */
export interface AdminCreateCareerJobPostingResponse {
    job?: CareerJobPosting | undefined;
}
/** Request to update mutable job posting content. */
export interface AdminUpdateCareerJobPostingRequest {
    jobPostingId: bigint;
    slug: string;
    title: string;
    team: string;
    locationLabel: string;
    workplaceMode: CareerWorkplaceMode;
    employmentType: CareerEmploymentType;
    summary: string;
    description: string;
    closesAt?: Date | undefined;
}
/** Response for updating a job posting. */
export interface AdminUpdateCareerJobPostingResponse {
    job?: CareerJobPosting | undefined;
}
/** Request to transition a posting between lifecycle states. */
export interface AdminTransitionCareerJobPostingStatusRequest {
    jobPostingId: bigint;
    status: CareerJobPostingStatus;
}
/** Response for posting status transitions. */
export interface AdminTransitionCareerJobPostingStatusResponse {
    job?: CareerJobPosting | undefined;
}
/** Admin view of an application, including the resume download URL. */
export interface AdminCareerApplication {
    application?: CareerApplication | undefined;
    resumeDownloadUrl: string;
}
export interface AdminListCareerApplicationsRequest {
    pagination?: PaginationRequest | undefined;
    jobPostingIdFilter?: bigint | undefined;
    statusFilter: CareerApplicationStatus;
    emailFilter: string;
    referenceIdFilter: string;
    sort?: SortRequest | undefined;
    filter?: FilterRequest | undefined;
    sortBy: AdminListCareerApplicationsSortBy;
}
/** Response for listing career applications. */
export interface AdminListCareerApplicationsResponse {
    applications: AdminCareerApplication[];
    pagination?: PaginationResponse | undefined;
}
/** Request to fetch a specific application by id. */
export interface AdminGetCareerApplicationRequest {
    applicationId: bigint;
}
/** Response containing a specific application. */
export interface AdminGetCareerApplicationResponse {
    application?: AdminCareerApplication | undefined;
}
/** Request to fetch a specific application by reference id. */
export interface AdminGetCareerApplicationByReferenceIDRequest {
    referenceId: string;
}
/** Response containing an application fetched by reference id. */
export interface AdminGetCareerApplicationByReferenceIDResponse {
    application?: AdminCareerApplication | undefined;
}
/** Request to update application review status and notes. */
export interface AdminUpdateCareerApplicationStatusRequest {
    applicationId: bigint;
    status: CareerApplicationStatus;
    adminNotes: string;
}
/** Response for application status updates. */
export interface AdminUpdateCareerApplicationStatusResponse {
    application?: AdminCareerApplication | undefined;
}
/** Attachment details for admin view */
export interface AdminAttachmentDetails {
    id: bigint;
    userId: string;
    originalFilename: string;
    contentType: string;
    sizeBytes: bigint;
    /** Numeric UploadStatus: 0 pending_upload, 1 pending_processing, 2 processing, 3 vetted, 4 rejected */
    uploadStatus: bigint;
    fileHash: string;
    validationDetails: string;
    uploadTime?: Date | undefined;
    processingStartTime?: Date | undefined;
    processingEndTime?: Date | undefined;
    createdAt?: Date | undefined;
    temporaryObjectName: string;
    finalObjectName: string;
    /** Stable public URL or expiring private presigned URL, according to visibility */
    downloadUrl: string;
    /** Permission-filtered attachment owner details for admin display */
    user?: User | undefined;
    /**
     * Storage visibility: which bucket final_object_name lives in, and whether
     * download_url is stable/anonymous or presigned. Unset == private.
     */
    visibility?: AttachmentVisibility | undefined;
}
export interface AdminListAttachmentsRequest {
    pagination?: PaginationRequest | undefined;
    userIdFilter?: bigint | undefined;
    statusFilter: string;
    contentTypeFilter: string;
    minSizeBytes: bigint;
    maxSizeBytes: bigint;
    /** Sort parameters */
    sort?: SortRequest | undefined;
    /** Common filter parameters */
    filter?: FilterRequest | undefined;
    sortBy: AdminListAttachmentsSortBy;
}
/** Response for listing attachments with pagination */
export interface AdminListAttachmentsResponse {
    attachments: AdminAttachmentDetails[];
    pagination?: PaginationResponse | undefined;
}
/** Channel details for admin views. */
export interface AdminChannelDetails {
    channel?: Channel | undefined;
    activeParticipantCount: bigint;
    /** Permission-filtered channel creator details for admin display */
    createdByUser?: User | undefined;
}
export interface AdminListChatChannelsRequest {
    pagination?: PaginationRequest | undefined;
    /** Search by name/description/ID (implementation-defined) */
    search: string;
    channelTypeFilter: ChannelType;
    includeArchived: boolean;
    includeDeleted: boolean;
    sort?: SortRequest | undefined;
    channelIdFilter?: bigint | undefined;
    createdByUserIdFilter?: bigint | undefined;
    /** Filter by participant user ID */
    participantUserIdFilter?: bigint | undefined;
    sortBy: AdminListChatChannelsSortBy;
}
/** Response for listing chat channels. */
export interface AdminListChatChannelsResponse {
    channels: AdminChannelDetails[];
    pagination?: PaginationResponse | undefined;
}
/** Request to get a specific chat channel. */
export interface AdminGetChatChannelRequest {
    channelId: bigint;
    includeDeleted: boolean;
}
/** Response with channel details. */
export interface AdminGetChatChannelResponse {
    channel?: AdminChannelDetails | undefined;
}
/** Request to update a chat channel (admin). */
export interface AdminUpdateChatChannelRequest {
    channelId: bigint;
    name?: string | undefined;
    description?: string | undefined;
    avatarAttachmentId?: bigint | undefined;
    isArchived?: boolean | undefined;
    /** Per-channel feature flags */
    supportReplies?: boolean | undefined;
    supportThreads?: boolean | undefined;
    supportMessageEdits?: boolean | undefined;
    supportMessageDeletes?: boolean | undefined;
    supportMessageReactions?: boolean | undefined;
    allowMultipleReactionsPerUser?: boolean | undefined;
    supportEmbeds?: boolean | undefined;
    supportAttachments?: boolean | undefined;
    allowNativeEmbeds?: boolean | undefined;
    allowCustomEmbeds?: boolean | undefined;
    supportInferenceUsage?: boolean | undefined;
    /** Optional per-channel context metadata updates. */
    contextId?: bigint | undefined;
    contextDisplayName?: string | undefined;
    clearContext?: boolean | undefined;
    contextEntityId?: bigint | undefined;
}
/** Response for channel updates. */
export interface AdminUpdateChatChannelResponse {
    channel?: AdminChannelDetails | undefined;
}
/** Request to delete (soft-delete) a chat channel. */
export interface AdminDeleteChatChannelRequest {
    channelId: bigint;
    reason: string;
}
/** Response for channel deletion. */
export interface AdminDeleteChatChannelResponse {
}
/** Request to list chat channel participants. */
export interface AdminListChatChannelParticipantsRequest {
    channelId: bigint;
    pagination?: PaginationRequest | undefined;
    includeLeft: boolean;
}
/** Response for listing channel participants. */
export interface AdminListChatChannelParticipantsResponse {
    participants: ChannelParticipant[];
    pagination?: PaginationResponse | undefined;
}
/** Request to add participants to a chat channel (admin). */
export interface AdminAddChatChannelParticipantsRequest {
    channelId: bigint;
    userIds: bigint[];
    reason?: string | undefined;
}
/** Response for adding participants. */
export interface AdminAddChatChannelParticipantsResponse {
    addedParticipants: ChannelParticipant[];
}
/** Request to remove a participant from a chat channel (admin). */
export interface AdminRemoveChatChannelParticipantRequest {
    channelId: bigint;
    userId: bigint;
    reason?: string | undefined;
}
/** Response for removing a participant. */
export interface AdminRemoveChatChannelParticipantResponse {
}
/** Request to update a participant role (admin). */
export interface AdminUpdateChatChannelParticipantRoleRequest {
    channelId: bigint;
    userId: bigint;
    role: ChannelRole;
    reason?: string | undefined;
}
/** Response for participant role update. */
export interface AdminUpdateChatChannelParticipantRoleResponse {
    participant?: ChannelParticipant | undefined;
}
/** Response with attachment details */
export interface AdminGetAttachmentResponse {
    attachment?: AdminAttachmentDetails | undefined;
}
/** Request to update attachment status */
export interface AdminUpdateAttachmentStatusRequest {
    attachmentId: bigint;
    /** "vetted" or "rejected" */
    status: string;
    validationDetails: string;
}
/** Response for attachment status update */
export interface AdminUpdateAttachmentStatusResponse {
}
/** Request to delete an attachment */
export interface AdminDeleteAttachmentRequest {
    attachmentId: bigint;
    /** Whether to delete actual files from storage */
    deleteFiles: boolean;
    reason: string;
}
/** Response for attachment deletion */
export interface AdminDeleteAttachmentResponse {
}
/** Request for user analytics */
export interface AdminUserAnalyticsRequest {
    /** Date range and other filters */
    filter?: FilterRequest | undefined;
    /** "day", "week", "month" */
    groupBy: string;
}
/** Analytics data structures */
export interface UserRegistrationStats {
    date?: Date | undefined;
    newRegistrations: bigint;
    emailRegistrations: bigint;
    oauthRegistrations: bigint;
}
export interface UserActivityStats {
    date?: Date | undefined;
    activeUsers: bigint;
    totalLogins: bigint;
    uniqueLogins: bigint;
}
export interface UserTypeDistribution {
    /** UserType enum name -> count */
    userTypeCounts: {
        [key: string]: bigint;
    };
}
export interface UserTypeDistribution_UserTypeCountsEntry {
    key: string;
    value: bigint;
}
/** Response for user analytics */
export interface AdminUserAnalyticsResponse {
    registrationStats: UserRegistrationStats[];
    activityStats: UserActivityStats[];
    userTypeDistribution?: UserTypeDistribution | undefined;
    /** Effective bucket granularity after server normalization */
    groupBy: string;
}
/** Request for storage analytics */
export interface AdminStorageAnalyticsRequest {
    /** Date range and other filters */
    filter?: FilterRequest | undefined;
    /** Optional "day", "week", or "month"; server may coarsen */
    groupBy: string;
}
export interface StorageByUserType {
    userType: UserType;
    totalBytes: bigint;
    attachmentCount: bigint;
}
export interface StorageByContentType {
    contentType: string;
    totalBytes: bigint;
    attachmentCount: bigint;
}
export interface StorageGrowthStats {
    date?: Date | undefined;
    totalBytes: bigint;
    newBytes: bigint;
    newAttachments: bigint;
}
/** Response for storage analytics */
export interface AdminStorageAnalyticsResponse {
    totalStorageBytes: bigint;
    totalAttachments: bigint;
    storageByUserType: StorageByUserType[];
    /** Top 50 by bytes */
    storageByContentType: StorageByContentType[];
    growthStats: StorageGrowthStats[];
    /** Effective bucket granularity after server normalization */
    groupBy: string;
    storageByContentTypeTruncated: boolean;
    storageByContentTypeLimit: number;
}
/** Session token details for admin view */
export interface AdminSessionToken {
    tokenId: string;
    userId: string;
    tokenType: TokenType;
    createdAt?: Date | undefined;
    expiresAt?: Date | undefined;
    lastUsedAt?: Date | undefined;
    ipAddress: string;
    userAgent: string;
    /** Permission-filtered user details for admin display */
    user?: User | undefined;
    /** Calculated lifecycle status for admin display/filtering */
    status: TokenStatus;
}
export interface AdminListTokensRequest {
    pagination?: PaginationRequest | undefined;
    userIdFilter?: bigint | undefined;
    tokenTypeFilter: TokenType;
    /** Sort parameters */
    sort?: SortRequest | undefined;
    statusFilter: TokenStatus;
    /** from_date/to_date apply to issued_at; search is metadata search */
    filter?: FilterRequest | undefined;
    /** Exact token lookup for incident response; never echoed back to clients */
    rawTokenFilter: string;
    sortBy: AdminListTokensSortBy;
}
/** Response for listing tokens with pagination */
export interface AdminListTokensResponse {
    tokens: AdminSessionToken[];
    pagination?: PaginationResponse | undefined;
}
/** AdminInferenceProvider exposes configured provider capabilities without credentials. */
export interface AdminInferenceProvider {
    id: string;
    displayName: string;
    defaultApi: InferenceAPI;
    supportedApis: InferenceAPI[];
}
export interface ListAdminInferenceProvidersRequest {
}
export interface ListAdminInferenceProvidersResponse {
    providers: AdminInferenceProvider[];
}
/** AdminInferenceModel wraps one supported-model catalog row for admin views. */
export interface AdminInferenceModel {
    inferenceModel?: InferenceModel | undefined;
}
export interface ListAdminInferenceModelsRequest {
    pagination?: PaginationRequest | undefined;
}
export interface ListAdminInferenceModelsResponse {
    inferenceModels: AdminInferenceModel[];
    pagination?: PaginationResponse | undefined;
}
export interface CreateAdminInferenceModelRequest {
    providerId: string;
    providerModelId: string;
    displayName: string;
    active?: boolean | undefined;
}
export interface CreateAdminInferenceModelResponse {
    inferenceModel?: AdminInferenceModel | undefined;
}
export interface UpdateAdminInferenceModelRequest {
    inferenceModelId: bigint;
    providerId: string;
    providerModelId: string;
    displayName: string;
    active: boolean;
    updateMask?: string[] | undefined;
}
export interface UpdateAdminInferenceModelResponse {
    inferenceModel?: AdminInferenceModel | undefined;
}
export interface DeleteAdminInferenceModelRequest {
    inferenceModelId: bigint;
}
export interface DeleteAdminInferenceModelResponse {
}
/** Request for system stats (no pagination needed) */
export interface AdminSystemStatsRequest {
}
/** Database-backed account, contact, attachment, and session statistics */
export interface AdminSystemStatsResponse {
    totalUsers: bigint;
    activeUsersLast30Days: bigint;
    totalContactMessages: bigint;
    pendingContactMessages: bigint;
    totalAttachments: bigint;
    totalStorageBytes: bigint;
    activeSessions: bigint;
    systemStartTime?: Date | undefined;
}
/**
 * Request to directly add a user to an organization (bypasses invitation system)
 * This is admin-only and does not require user consent
 */
export interface AdminAddUserToOrganizationRequest {
    organizationId: bigint;
    userId: bigint;
    role: OrganizationRole;
    /** Admin reason for adding user without consent */
    reason?: string | undefined;
}
/** Response for admin user addition to organization */
export interface AdminAddUserToOrganizationResponse {
    organizationUser?: OrganizationUser | undefined;
}
/**
 * Request to directly add a user to an organization by email or username.
 * This is admin-only and bypasses organization type capability gates.
 */
export interface AdminAddUserToOrganizationByIdentifierRequest {
    organizationId: bigint;
    identifierType: UserIdentifierType;
    identifier: string;
    role: OrganizationRole;
}
/** Response for admin direct add by identifier. */
export interface AdminAddUserToOrganizationByIdentifierResponse {
    userAdded: boolean;
    autoAddPending: boolean;
    organizationUser?: OrganizationUser | undefined;
    autoAddEntry?: OrganizationInvitation | undefined;
}
/** Request to update a user's organization role with admin privilege. */
export interface AdminUpdateUserRoleInOrganizationRequest {
    organizationId: bigint;
    userId: bigint;
    role: OrganizationRole;
}
/** Response for admin role update. */
export interface AdminUpdateUserRoleInOrganizationResponse {
    organizationUser?: OrganizationUser | undefined;
}
/** Request to get a user's organization membership details with admin privilege. */
export interface AdminGetOrganizationMemberRequest {
    organizationId: bigint;
    userId: bigint;
}
/** Response for admin organization member detail. */
export interface AdminGetOrganizationMemberResponse {
    memberDetails?: OrganizationMemberDetails | undefined;
}
/** Request for admins to create an organization email domain mapping */
export interface AdminCreateOrganizationEmailDomainRequest {
    organizationId: bigint;
    domain: string;
}
/** Response containing the newly created organization email domain */
export interface AdminCreateOrganizationEmailDomainResponse {
    emailDomain?: OrganizationEmailDomain | undefined;
}
/** Request for admins to delete an organization email domain mapping */
export interface AdminDeleteOrganizationEmailDomainRequest {
    organizationEmailDomainId: bigint;
}
/** Response for admin email domain deletion */
export interface AdminDeleteOrganizationEmailDomainResponse {
}
/** Request to list organization email domains for a specific organization */
export interface AdminListOrganizationEmailDomainsRequest {
    organizationId: bigint;
    pagination?: PaginationRequest | undefined;
}
/** Response containing organization email domains for admin view */
export interface AdminListOrganizationEmailDomainsResponse {
    emailDomains: OrganizationEmailDomain[];
    pagination?: PaginationResponse | undefined;
}
export declare const AdminListUsersRequest: MessageFns<AdminListUsersRequest>;
export declare const AdminUserDetails: MessageFns<AdminUserDetails>;
export declare const AdminListUsersResponse: MessageFns<AdminListUsersResponse>;
export declare const AdminGetUserRequest: MessageFns<AdminGetUserRequest>;
export declare const AdminGetUserResponse: MessageFns<AdminGetUserResponse>;
export declare const AdminBanUserRequest: MessageFns<AdminBanUserRequest>;
export declare const AdminBanUserResponse: MessageFns<AdminBanUserResponse>;
export declare const AdminChangeUserTypeRequest: MessageFns<AdminChangeUserTypeRequest>;
export declare const AdminChangeUserTypeResponse: MessageFns<AdminChangeUserTypeResponse>;
export declare const AdminChangeUsernameRequest: MessageFns<AdminChangeUsernameRequest>;
export declare const AdminChangeUsernameResponse: MessageFns<AdminChangeUsernameResponse>;
export declare const AdminUsernameChangeHistoryEntry: MessageFns<AdminUsernameChangeHistoryEntry>;
export declare const AdminListUsernameChangeHistoryRequest: MessageFns<AdminListUsernameChangeHistoryRequest>;
export declare const AdminListUsernameChangeHistoryResponse: MessageFns<AdminListUsernameChangeHistoryResponse>;
export declare const AdminDeleteUserRequest: MessageFns<AdminDeleteUserRequest>;
export declare const AdminDeleteUserResponse: MessageFns<AdminDeleteUserResponse>;
export declare const AdminRevokeUserSessionsRequest: MessageFns<AdminRevokeUserSessionsRequest>;
export declare const AdminRevokeUserSessionsResponse: MessageFns<AdminRevokeUserSessionsResponse>;
export declare const AdminCreateUserProfilePictureUploadURLRequest: MessageFns<AdminCreateUserProfilePictureUploadURLRequest>;
export declare const AdminCreateUserProfilePictureUploadURLResponse: MessageFns<AdminCreateUserProfilePictureUploadURLResponse>;
export declare const AdminCreateUserProfilePictureUploadURLResponse_FormDataEntry: MessageFns<AdminCreateUserProfilePictureUploadURLResponse_FormDataEntry>;
export declare const AdminClearUserProfilePictureRequest: MessageFns<AdminClearUserProfilePictureRequest>;
export declare const AdminClearUserProfilePictureResponse: MessageFns<AdminClearUserProfilePictureResponse>;
export declare const AdminCreateUserRequest: MessageFns<AdminCreateUserRequest>;
export declare const AdminCreateUserResponse: MessageFns<AdminCreateUserResponse>;
export declare const AdminResendUserInvitationRequest: MessageFns<AdminResendUserInvitationRequest>;
export declare const AdminResendUserInvitationResponse: MessageFns<AdminResendUserInvitationResponse>;
export declare const AdminContactMessage: MessageFns<AdminContactMessage>;
export declare const AdminListContactMessagesRequest: MessageFns<AdminListContactMessagesRequest>;
export declare const AdminListContactMessagesResponse: MessageFns<AdminListContactMessagesResponse>;
export declare const AdminGetContactMessageRequest: MessageFns<AdminGetContactMessageRequest>;
export declare const AdminGetContactMessageResponse: MessageFns<AdminGetContactMessageResponse>;
export declare const AdminGetContactMessageByReferenceIDRequest: MessageFns<AdminGetContactMessageByReferenceIDRequest>;
export declare const AdminGetContactMessageByReferenceIDResponse: MessageFns<AdminGetContactMessageByReferenceIDResponse>;
export declare const AdminListCareerJobPostingsRequest: MessageFns<AdminListCareerJobPostingsRequest>;
export declare const AdminListCareerJobPostingsResponse: MessageFns<AdminListCareerJobPostingsResponse>;
export declare const AdminGetCareerJobPostingRequest: MessageFns<AdminGetCareerJobPostingRequest>;
export declare const AdminGetCareerJobPostingResponse: MessageFns<AdminGetCareerJobPostingResponse>;
export declare const AdminCreateCareerJobPostingRequest: MessageFns<AdminCreateCareerJobPostingRequest>;
export declare const AdminCreateCareerJobPostingResponse: MessageFns<AdminCreateCareerJobPostingResponse>;
export declare const AdminUpdateCareerJobPostingRequest: MessageFns<AdminUpdateCareerJobPostingRequest>;
export declare const AdminUpdateCareerJobPostingResponse: MessageFns<AdminUpdateCareerJobPostingResponse>;
export declare const AdminTransitionCareerJobPostingStatusRequest: MessageFns<AdminTransitionCareerJobPostingStatusRequest>;
export declare const AdminTransitionCareerJobPostingStatusResponse: MessageFns<AdminTransitionCareerJobPostingStatusResponse>;
export declare const AdminCareerApplication: MessageFns<AdminCareerApplication>;
export declare const AdminListCareerApplicationsRequest: MessageFns<AdminListCareerApplicationsRequest>;
export declare const AdminListCareerApplicationsResponse: MessageFns<AdminListCareerApplicationsResponse>;
export declare const AdminGetCareerApplicationRequest: MessageFns<AdminGetCareerApplicationRequest>;
export declare const AdminGetCareerApplicationResponse: MessageFns<AdminGetCareerApplicationResponse>;
export declare const AdminGetCareerApplicationByReferenceIDRequest: MessageFns<AdminGetCareerApplicationByReferenceIDRequest>;
export declare const AdminGetCareerApplicationByReferenceIDResponse: MessageFns<AdminGetCareerApplicationByReferenceIDResponse>;
export declare const AdminUpdateCareerApplicationStatusRequest: MessageFns<AdminUpdateCareerApplicationStatusRequest>;
export declare const AdminUpdateCareerApplicationStatusResponse: MessageFns<AdminUpdateCareerApplicationStatusResponse>;
export declare const AdminAttachmentDetails: MessageFns<AdminAttachmentDetails>;
export declare const AdminListAttachmentsRequest: MessageFns<AdminListAttachmentsRequest>;
export declare const AdminListAttachmentsResponse: MessageFns<AdminListAttachmentsResponse>;
export declare const AdminChannelDetails: MessageFns<AdminChannelDetails>;
export declare const AdminListChatChannelsRequest: MessageFns<AdminListChatChannelsRequest>;
export declare const AdminListChatChannelsResponse: MessageFns<AdminListChatChannelsResponse>;
export declare const AdminGetChatChannelRequest: MessageFns<AdminGetChatChannelRequest>;
export declare const AdminGetChatChannelResponse: MessageFns<AdminGetChatChannelResponse>;
export declare const AdminUpdateChatChannelRequest: MessageFns<AdminUpdateChatChannelRequest>;
export declare const AdminUpdateChatChannelResponse: MessageFns<AdminUpdateChatChannelResponse>;
export declare const AdminDeleteChatChannelRequest: MessageFns<AdminDeleteChatChannelRequest>;
export declare const AdminDeleteChatChannelResponse: MessageFns<AdminDeleteChatChannelResponse>;
export declare const AdminListChatChannelParticipantsRequest: MessageFns<AdminListChatChannelParticipantsRequest>;
export declare const AdminListChatChannelParticipantsResponse: MessageFns<AdminListChatChannelParticipantsResponse>;
export declare const AdminAddChatChannelParticipantsRequest: MessageFns<AdminAddChatChannelParticipantsRequest>;
export declare const AdminAddChatChannelParticipantsResponse: MessageFns<AdminAddChatChannelParticipantsResponse>;
export declare const AdminRemoveChatChannelParticipantRequest: MessageFns<AdminRemoveChatChannelParticipantRequest>;
export declare const AdminRemoveChatChannelParticipantResponse: MessageFns<AdminRemoveChatChannelParticipantResponse>;
export declare const AdminUpdateChatChannelParticipantRoleRequest: MessageFns<AdminUpdateChatChannelParticipantRoleRequest>;
export declare const AdminUpdateChatChannelParticipantRoleResponse: MessageFns<AdminUpdateChatChannelParticipantRoleResponse>;
export declare const AdminGetAttachmentResponse: MessageFns<AdminGetAttachmentResponse>;
export declare const AdminUpdateAttachmentStatusRequest: MessageFns<AdminUpdateAttachmentStatusRequest>;
export declare const AdminUpdateAttachmentStatusResponse: MessageFns<AdminUpdateAttachmentStatusResponse>;
export declare const AdminDeleteAttachmentRequest: MessageFns<AdminDeleteAttachmentRequest>;
export declare const AdminDeleteAttachmentResponse: MessageFns<AdminDeleteAttachmentResponse>;
export declare const AdminUserAnalyticsRequest: MessageFns<AdminUserAnalyticsRequest>;
export declare const UserRegistrationStats: MessageFns<UserRegistrationStats>;
export declare const UserActivityStats: MessageFns<UserActivityStats>;
export declare const UserTypeDistribution: MessageFns<UserTypeDistribution>;
export declare const UserTypeDistribution_UserTypeCountsEntry: MessageFns<UserTypeDistribution_UserTypeCountsEntry>;
export declare const AdminUserAnalyticsResponse: MessageFns<AdminUserAnalyticsResponse>;
export declare const AdminStorageAnalyticsRequest: MessageFns<AdminStorageAnalyticsRequest>;
export declare const StorageByUserType: MessageFns<StorageByUserType>;
export declare const StorageByContentType: MessageFns<StorageByContentType>;
export declare const StorageGrowthStats: MessageFns<StorageGrowthStats>;
export declare const AdminStorageAnalyticsResponse: MessageFns<AdminStorageAnalyticsResponse>;
export declare const AdminSessionToken: MessageFns<AdminSessionToken>;
export declare const AdminListTokensRequest: MessageFns<AdminListTokensRequest>;
export declare const AdminListTokensResponse: MessageFns<AdminListTokensResponse>;
export declare const AdminInferenceProvider: MessageFns<AdminInferenceProvider>;
export declare const ListAdminInferenceProvidersRequest: MessageFns<ListAdminInferenceProvidersRequest>;
export declare const ListAdminInferenceProvidersResponse: MessageFns<ListAdminInferenceProvidersResponse>;
export declare const AdminInferenceModel: MessageFns<AdminInferenceModel>;
export declare const ListAdminInferenceModelsRequest: MessageFns<ListAdminInferenceModelsRequest>;
export declare const ListAdminInferenceModelsResponse: MessageFns<ListAdminInferenceModelsResponse>;
export declare const CreateAdminInferenceModelRequest: MessageFns<CreateAdminInferenceModelRequest>;
export declare const CreateAdminInferenceModelResponse: MessageFns<CreateAdminInferenceModelResponse>;
export declare const UpdateAdminInferenceModelRequest: MessageFns<UpdateAdminInferenceModelRequest>;
export declare const UpdateAdminInferenceModelResponse: MessageFns<UpdateAdminInferenceModelResponse>;
export declare const DeleteAdminInferenceModelRequest: MessageFns<DeleteAdminInferenceModelRequest>;
export declare const DeleteAdminInferenceModelResponse: MessageFns<DeleteAdminInferenceModelResponse>;
export declare const AdminSystemStatsRequest: MessageFns<AdminSystemStatsRequest>;
export declare const AdminSystemStatsResponse: MessageFns<AdminSystemStatsResponse>;
export declare const AdminAddUserToOrganizationRequest: MessageFns<AdminAddUserToOrganizationRequest>;
export declare const AdminAddUserToOrganizationResponse: MessageFns<AdminAddUserToOrganizationResponse>;
export declare const AdminAddUserToOrganizationByIdentifierRequest: MessageFns<AdminAddUserToOrganizationByIdentifierRequest>;
export declare const AdminAddUserToOrganizationByIdentifierResponse: MessageFns<AdminAddUserToOrganizationByIdentifierResponse>;
export declare const AdminUpdateUserRoleInOrganizationRequest: MessageFns<AdminUpdateUserRoleInOrganizationRequest>;
export declare const AdminUpdateUserRoleInOrganizationResponse: MessageFns<AdminUpdateUserRoleInOrganizationResponse>;
export declare const AdminGetOrganizationMemberRequest: MessageFns<AdminGetOrganizationMemberRequest>;
export declare const AdminGetOrganizationMemberResponse: MessageFns<AdminGetOrganizationMemberResponse>;
export declare const AdminCreateOrganizationEmailDomainRequest: MessageFns<AdminCreateOrganizationEmailDomainRequest>;
export declare const AdminCreateOrganizationEmailDomainResponse: MessageFns<AdminCreateOrganizationEmailDomainResponse>;
export declare const AdminDeleteOrganizationEmailDomainRequest: MessageFns<AdminDeleteOrganizationEmailDomainRequest>;
export declare const AdminDeleteOrganizationEmailDomainResponse: MessageFns<AdminDeleteOrganizationEmailDomainResponse>;
export declare const AdminListOrganizationEmailDomainsRequest: MessageFns<AdminListOrganizationEmailDomainsRequest>;
export declare const AdminListOrganizationEmailDomainsResponse: MessageFns<AdminListOrganizationEmailDomainsResponse>;
type Builtin = Date | Function | Uint8Array | string | number | boolean | bigint | undefined;
type DeepPartial<T> = T extends bigint ? string | number | bigint : T extends Builtin ? T : T extends globalThis.Array<infer U> ? globalThis.Array<DeepPartial<U>> : T extends ReadonlyArray<infer U> ? ReadonlyArray<DeepPartial<U>> : T extends {} ? {
    [K in keyof T]?: DeepPartial<T[K]>;
} : Partial<T>;
type KeysOfUnion<T> = T extends T ? keyof T : never;
type Exact<P, I extends P> = P extends Builtin ? P : P & {
    [K in keyof P]: Exact<P[K], I[K]>;
} & {
    [K in Exclude<keyof I, KeysOfUnion<P>>]: never;
};
interface MessageFns<T> {
    encode(message: T, writer?: BinaryWriter): BinaryWriter;
    decode(input: BinaryReader | Uint8Array, length?: number): T;
    fromJSON(object: any): T;
    toJSON(message: T): unknown;
    create<I extends Exact<DeepPartial<T>, I>>(base?: I): T;
    fromPartial<I extends Exact<DeepPartial<T>, I>>(object: I): T;
}
export {};
//# sourceMappingURL=admin_api.d.ts.map