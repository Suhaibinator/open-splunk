export declare enum Language {
    /** LANGUAGE_UNSPECIFIED - Default unspecified state */
    LANGUAGE_UNSPECIFIED = 0,
    /** LANGUAGE_ENGLISH - English language */
    LANGUAGE_ENGLISH = 1,
    /** LANGUAGE_SPANISH - Spanish language */
    LANGUAGE_SPANISH = 2,
    /** LANGUAGE_FRENCH - French language */
    LANGUAGE_FRENCH = 3,
    /** LANGUAGE_GERMAN - German language */
    LANGUAGE_GERMAN = 4,
    /** LANGUAGE_CHINESE - Chinese language */
    LANGUAGE_CHINESE = 5,
    /** LANGUAGE_RUSSIAN - Russian language */
    LANGUAGE_RUSSIAN = 6,
    /** LANGUAGE_ARABIC - Arabic language */
    LANGUAGE_ARABIC = 7,
    /** LANGUAGE_PORTUGUESE - Portuguese language */
    LANGUAGE_PORTUGUESE = 8,
    /** LANGUAGE_HINDI - Hindi language */
    LANGUAGE_HINDI = 9,
    /** LANGUAGE_JAPANESE - Japanese language */
    LANGUAGE_JAPANESE = 10,
    /** LANGUAGE_KOREAN - Korean language */
    LANGUAGE_KOREAN = 11,
    /** LANGUAGE_ITALIAN - Italian language */
    LANGUAGE_ITALIAN = 12,
    /** LANGUAGE_DUTCH - Dutch language */
    LANGUAGE_DUTCH = 13,
    /** LANGUAGE_SWEDISH - Swedish language */
    LANGUAGE_SWEDISH = 14,
    /** LANGUAGE_TURKISH - Turkish language */
    LANGUAGE_TURKISH = 15,
    /** LANGUAGE_POLISH - Polish language */
    LANGUAGE_POLISH = 16,
    /** LANGUAGE_DANISH - Danish language */
    LANGUAGE_DANISH = 17,
    /** LANGUAGE_NORWEGIAN - Norwegian language */
    LANGUAGE_NORWEGIAN = 18,
    /** LANGUAGE_FINNISH - Finnish language */
    LANGUAGE_FINNISH = 19,
    /** LANGUAGE_CZECH - Czech language */
    LANGUAGE_CZECH = 20,
    /** LANGUAGE_HUNGARIAN - Hungarian language */
    LANGUAGE_HUNGARIAN = 21,
    /** LANGUAGE_ROMANIAN - Romanian language */
    LANGUAGE_ROMANIAN = 22,
    /** LANGUAGE_BULGARIAN - Bulgarian language */
    LANGUAGE_BULGARIAN = 23,
    /** LANGUAGE_CROATIAN - Croatian language */
    LANGUAGE_CROATIAN = 24,
    /** LANGUAGE_SLOVAK - Slovak language */
    LANGUAGE_SLOVAK = 25,
    /** LANGUAGE_SERBIAN - Serbian language */
    LANGUAGE_SERBIAN = 26,
    /** LANGUAGE_SLOVENIAN - Slovenian language */
    LANGUAGE_SLOVENIAN = 27,
    /** LANGUAGE_UKRAINIAN - Ukrainian language */
    LANGUAGE_UKRAINIAN = 28,
    /** LANGUAGE_BASQUE - Basque language */
    LANGUAGE_BASQUE = 29,
    /** LANGUAGE_CATALAN - Catalan language */
    LANGUAGE_CATALAN = 30,
    /** LANGUAGE_WELSH - Welsh language */
    LANGUAGE_WELSH = 31,
    /** LANGUAGE_GREEK - Greek language */
    LANGUAGE_GREEK = 32,
    /** LANGUAGE_THAI - Thai language */
    LANGUAGE_THAI = 33,
    /** LANGUAGE_VIETNAMESE - Vietnamese language */
    LANGUAGE_VIETNAMESE = 34,
    /** LANGUAGE_INDONESIAN - Indonesian language */
    LANGUAGE_INDONESIAN = 35,
    /** LANGUAGE_MALAY - Malay language */
    LANGUAGE_MALAY = 36,
    /** LANGUAGE_FILIPINO - Filipino language */
    LANGUAGE_FILIPINO = 37,
    /** LANGUAGE_SWAHILI - Swahili language */
    LANGUAGE_SWAHILI = 38,
    /** LANGUAGE_TAMIL - Tamil language */
    LANGUAGE_TAMIL = 39,
    /** LANGUAGE_TELUGU - Telugu language */
    LANGUAGE_TELUGU = 40,
    /** LANGUAGE_BENGALI - Bengali language */
    LANGUAGE_BENGALI = 41,
    /** LANGUAGE_PUNJABI - Punjabi language */
    LANGUAGE_PUNJABI = 42,
    /** LANGUAGE_URDU - Urdu language */
    LANGUAGE_URDU = 43,
    /** LANGUAGE_MARATHI - Marathi language */
    LANGUAGE_MARATHI = 44,
    /** LANGUAGE_GUJARATI - Gujarati language */
    LANGUAGE_GUJARATI = 45,
    /** LANGUAGE_KANNADA - Kannada language */
    LANGUAGE_KANNADA = 46,
    /** LANGUAGE_MALAYALAM - Malayalam language */
    LANGUAGE_MALAYALAM = 47,
    /** LANGUAGE_PERSIAN - Persian language */
    LANGUAGE_PERSIAN = 48,
    /** LANGUAGE_HEBREW - Hebrew language */
    LANGUAGE_HEBREW = 49,
    UNRECOGNIZED = -1
}
export declare function languageFromJSON(object: any): Language;
export declare function languageToJSON(object: Language): string;
//# sourceMappingURL=language.d.ts.map