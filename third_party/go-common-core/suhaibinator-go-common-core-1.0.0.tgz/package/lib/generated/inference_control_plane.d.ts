import { BinaryReader, BinaryWriter } from "@bufbuild/protobuf/wire";
import { InferenceCallPurpose } from "./chat";
import { Duration } from "./google/protobuf/duration";
import { InferenceAPI } from "./inference";
/** InferenceAttemptStatus is the lifecycle state of one provider attempt. */
export declare enum InferenceAttemptStatus {
    INFERENCE_ATTEMPT_STATUS_UNSPECIFIED = 0,
    INFERENCE_ATTEMPT_STATUS_SUCCEEDED = 1,
    INFERENCE_ATTEMPT_STATUS_FAILED = 2,
    INFERENCE_ATTEMPT_STATUS_IN_FLIGHT = 3,
    /** INFERENCE_ATTEMPT_STATUS_OUTCOME_UNKNOWN - The deadline passed without a recorded completion; a late completion may replace this. */
    INFERENCE_ATTEMPT_STATUS_OUTCOME_UNKNOWN = 4,
    UNRECOGNIZED = -1
}
export declare function inferenceAttemptStatusFromJSON(object: any): InferenceAttemptStatus;
export declare function inferenceAttemptStatusToJSON(object: InferenceAttemptStatus): string;
/**
 * InferenceRetryReason is the typed classification of why a failed attempt was
 * judged retryable or terminal. Values mirror the kernel classifier.
 */
export declare enum InferenceRetryReason {
    INFERENCE_RETRY_REASON_UNSPECIFIED = 0,
    INFERENCE_RETRY_REASON_CONTEXT_CANCELED = 1,
    INFERENCE_RETRY_REASON_CONTEXT_DEADLINE_EXCEEDED = 2,
    INFERENCE_RETRY_REASON_HTTP_STATUS = 3,
    INFERENCE_RETRY_REASON_HTTP_STATUS_TERMINAL = 4,
    INFERENCE_RETRY_REASON_NETWORK_TIMEOUT = 5,
    INFERENCE_RETRY_REASON_NETWORK_TEMPORARY = 6,
    INFERENCE_RETRY_REASON_MESSAGE_HTTP_STATUS = 7,
    INFERENCE_RETRY_REASON_MESSAGE_RATE_LIMIT = 8,
    INFERENCE_RETRY_REASON_MESSAGE_UNAVAILABLE = 9,
    INFERENCE_RETRY_REASON_MESSAGE_TIMEOUT = 10,
    INFERENCE_RETRY_REASON_SCHEMA_GENERATION = 11,
    INFERENCE_RETRY_REASON_NOT_RETRYABLE = 12,
    INFERENCE_RETRY_REASON_STREAM_COMMITTED = 13,
    UNRECOGNIZED = -1
}
export declare function inferenceRetryReasonFromJSON(object: any): InferenceRetryReason;
export declare function inferenceRetryReasonToJSON(object: InferenceRetryReason): string;
/**
 * InferenceRetryOutcome is the disposition of a failed attempt within the retry
 * loop. It is a bounded metric/diagnostic label, not persisted on the row.
 */
export declare enum InferenceRetryOutcome {
    INFERENCE_RETRY_OUTCOME_UNSPECIFIED = 0,
    INFERENCE_RETRY_OUTCOME_RETRIED = 1,
    INFERENCE_RETRY_OUTCOME_EXHAUSTED = 2,
    INFERENCE_RETRY_OUTCOME_NOT_RETRYABLE = 3,
    UNRECOGNIZED = -1
}
export declare function inferenceRetryOutcomeFromJSON(object: any): InferenceRetryOutcome;
export declare function inferenceRetryOutcomeToJSON(object: InferenceRetryOutcome): string;
/**
 * InferenceThrottleKind identifies which bucket blocked an attempt before the
 * provider call.
 */
export declare enum InferenceThrottleKind {
    INFERENCE_THROTTLE_KIND_UNSPECIFIED = 0,
    INFERENCE_THROTTLE_KIND_REQUEST = 1,
    INFERENCE_THROTTLE_KIND_TOKEN = 2,
    UNRECOGNIZED = -1
}
export declare function inferenceThrottleKindFromJSON(object: any): InferenceThrottleKind;
export declare function inferenceThrottleKindToJSON(object: InferenceThrottleKind): string;
/**
 * InferenceTokenSource classifies how the token counts on an attempt were
 * obtained: provider-reported versus locally estimated.
 */
export declare enum InferenceTokenSource {
    INFERENCE_TOKEN_SOURCE_UNSPECIFIED = 0,
    INFERENCE_TOKEN_SOURCE_PROVIDER_REPORTED = 1,
    INFERENCE_TOKEN_SOURCE_ESTIMATED = 2,
    UNRECOGNIZED = -1
}
export declare function inferenceTokenSourceFromJSON(object: any): InferenceTokenSource;
export declare function inferenceTokenSourceToJSON(object: InferenceTokenSource): string;
/**
 * InferenceOperationRoute is the wire projection of one operation's persisted
 * route configuration. The owning operation is carried by
 * InferenceOperationRouteEntry. Request/token limits are not carried here; they
 * live on the model-level rate-limit policy.
 */
export interface InferenceOperationRoute {
    api: InferenceAPI;
    effectiveApi: InferenceAPI;
    inferenceModelId: bigint;
    providerId: string;
    providerModelId: string;
    totalTimeout?: Duration | undefined;
    maxAttempts: number;
    initialBackoff?: Duration | undefined;
    maxBackoff?: Duration | undefined;
    temperature?: number | undefined;
    configVersion?: bigint | undefined;
    updaterUserId?: bigint | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
/** InferenceRateLimitBucket is one token-bucket configuration. */
export interface InferenceRateLimitBucket {
    capacity: bigint;
    refillInterval?: Duration | undefined;
    refillUnits: bigint;
    waitCap?: Duration | undefined;
}
/**
 * InferenceModelRateLimitPolicy carries the optional, all-or-none request and
 * token buckets shared by every route targeting one inference model.
 */
export interface InferenceModelRateLimitPolicy {
    inferenceModelId: bigint;
    requestBucket?: InferenceRateLimitBucket | undefined;
    tokenBucket?: InferenceRateLimitBucket | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
/**
 * InferenceAttempt is the wire projection of one attempt-ledger row. It never
 * carries prompts, completions, reasoning, raw provider bodies, or secrets;
 * error strings are bounded and context JSON is allowlisted and size-capped.
 * Current attribution summaries, absent when the referenced entity is unavailable.
 * These are read-time projections, not historical snapshots.
 */
export interface InferenceAttemptActor {
    id: bigint;
    username: string;
    firstName: string;
    lastName: string;
    isBot: boolean;
}
export interface InferenceAttemptOrganization {
    id: bigint;
    name: string;
    slug: string;
}
export interface InferenceAttempt {
    /** Server-owned effective temperature and retry/rate-limit policies; no credentials. */
    effectiveSettingsJson: Uint8Array;
    /** Effective wire shape; historical attempts remain unspecified. */
    api: InferenceAPI;
    id: bigint;
    operation: number;
    symbolicName: string;
    invocationId: string;
    attemptNumber: number;
    runtimePurpose: InferenceCallPurpose;
    inferenceModelId: bigint;
    providerId: string;
    providerModelId: string;
    status: InferenceAttemptStatus;
    errorClass: string;
    errorMessage: string;
    retryable: boolean;
    retryReason: InferenceRetryReason;
    requestTraceId: string;
    actorUserId?: bigint | undefined;
    tokenSource: InferenceTokenSource;
    inputTokens: bigint;
    outputTokens: bigint;
    totalTokens: bigint;
    cachedTokens: bigint;
    thoughtTokens: bigint;
    inputCharacters: bigint;
    inputImages: bigint;
    inputVideos: bigint;
    inputAudioFiles: bigint;
    customUsageJson: Uint8Array;
    sanitizedContextJson: Uint8Array;
    startedAt?: Date | undefined;
    endedAt?: Date | undefined;
    createdAt?: Date | undefined;
    latency?: Duration | undefined;
    displayName: string;
    /**
     * Organization that owns and is charged for this inference invocation.
     * Optional only so historical rows created before organization attribution
     * can still be represented; every new execution requires a positive value.
     */
    organizationId?: bigint | undefined;
    actor?: InferenceAttemptActor | undefined;
    organization?: InferenceAttemptOrganization | undefined;
    /** Output tokens / full attempt seconds; absent when usage or duration is unavailable. */
    requestTokensPerSecond?: number | undefined;
    /** Approximate output tokens / seconds from first content chunk to completion. */
    generationTokensPerSecond?: number | undefined;
    /** First client-observed text/tool chunk; absent for historical and buffered calls. */
    firstOutputAt?: Date | undefined;
}
/**
 * InferenceAttemptFilter carries the generic attempt-list filters. All fields
 * are optional; metadata containment accepts only registered/allowlisted keys.
 */
export interface InferenceAttemptFilter {
    fromTime?: Date | undefined;
    toTime?: Date | undefined;
    providerId?: string | undefined;
    inferenceModelId?: bigint | undefined;
    operation?: number | undefined;
    status?: InferenceAttemptStatus | undefined;
    tokenSource?: InferenceTokenSource | undefined;
    actorUserId?: bigint | undefined;
    requestTraceId?: string | undefined;
    invocationId?: string | undefined;
    /** metadata is an allowlisted-key -> value map applied as JSON containment. */
    metadata: {
        [key: string]: string;
    };
    /**
     * List page size: 0 uses inference_attempt_list_default_limit (default 100); the HTTP API
     * rejects negative values and values above inference_attempt_list_max_limit (default 500).
     */
    limit: number;
    /** List offset; the HTTP API rejects negative values. */
    offset: number;
    /**
     * query is a bounded free-text search over invocation/trace ids, error
     * class/message, and provider model id.
     */
    query?: string | undefined;
    /** Restricts attempts and usage aggregates to the owning organization. */
    organizationId?: bigint | undefined;
}
export interface InferenceAttemptFilter_MetadataEntry {
    key: string;
    value: string;
}
/**
 * ListInferenceAttemptsResponse is a filtered page of attempts. It runs no
 * exact count query.
 */
export interface ListInferenceAttemptsResponse {
    attempts: InferenceAttempt[];
    /**
     * Lower bound on matching rows, not an exact pagination count. A value larger
     * than offset + attempts.length means another page exists. A nonempty final
     * page yields the exact count; an empty page yields zero (including offsets
     * beyond the end). Clients must not infer an exact page count from this value.
     */
    total: bigint;
    /**
     * limit is the page size the server used for this page: the request's limit, or
     * inference_attempt_list_default_limit when the request omitted it. Clients compute the next
     * page's offset from it.
     */
    limit: number;
}
/** InferenceUsageSummary is the aggregate rollup for a filtered attempt set. */
export interface InferenceUsageSummary {
    attemptCount: bigint;
    successCount: bigint;
    failureCount: bigint;
    inputTokens: bigint;
    outputTokens: bigint;
    totalTokens: bigint;
}
/**
 * InferenceUsageBreakdownRow is one grouped aggregation row (by provider,
 * operation, and status). symbolic_name/display_name are the server-provided
 * fallbacks for consumers without a translated operation label.
 */
export interface InferenceUsageBreakdownRow {
    providerId: string;
    operation: number;
    status: InferenceAttemptStatus;
    attemptCount: bigint;
    totalTokens: bigint;
    symbolicName: string;
    displayName: string;
}
/** ListInferenceRoutesRequest lists every registered operation and its route. */
export interface ListInferenceRoutesRequest {
}
/**
 * InferenceOperationRouteEntry pairs one code-registered operation with its
 * persisted route. route is absent when the operation has no route configured.
 */
export interface InferenceOperationRouteEntry {
    operation: number;
    symbolicName: string;
    displayName: string;
    sortOrder: number;
    required: boolean;
    route?: InferenceOperationRoute | undefined;
}
/**
 * ListInferenceRoutesResponse is every registered operation with its route,
 * ordered by sort order and enum value.
 */
export interface ListInferenceRoutesResponse {
    routes: InferenceOperationRouteEntry[];
}
/**
 * UpdateInferenceRouteRequest replaces the mutable route fields for one
 * operation. An absent temperature clears the stored temperature.
 */
export interface UpdateInferenceRouteRequest {
    /** Absent preserves the stored selection; explicit UNSPECIFIED resets it. */
    api?: InferenceAPI | undefined;
    operation: number;
    inferenceModelId: bigint;
    totalTimeout?: Duration | undefined;
    maxAttempts: number;
    initialBackoff?: Duration | undefined;
    maxBackoff?: Duration | undefined;
    temperature?: number | undefined;
}
/** UpdateInferenceRouteResponse returns the stored route after the update. */
export interface UpdateInferenceRouteResponse {
    route?: InferenceOperationRouteEntry | undefined;
}
/** ListInferenceRateLimitPoliciesRequest lists every model rate-limit policy. */
export interface ListInferenceRateLimitPoliciesRequest {
}
/**
 * ListInferenceRateLimitPoliciesResponse is every configured model rate-limit
 * policy ordered by inference model id.
 */
export interface ListInferenceRateLimitPoliciesResponse {
    policies: InferenceModelRateLimitPolicy[];
}
/**
 * UpdateInferenceRateLimitPolicyRequest replaces one model's optional,
 * all-or-none request and token buckets. An absent bucket clears that limit.
 */
export interface UpdateInferenceRateLimitPolicyRequest {
    inferenceModelId: bigint;
    requestBucket?: InferenceRateLimitBucket | undefined;
    tokenBucket?: InferenceRateLimitBucket | undefined;
}
/**
 * UpdateInferenceRateLimitPolicyResponse returns the stored policy after the
 * update. The in-process buckets rebuild on the next execution that loads it.
 */
export interface UpdateInferenceRateLimitPolicyResponse {
    policy?: InferenceModelRateLimitPolicy | undefined;
}
/** ListInferenceAttemptsRequest is a filtered, paginated attempt-ledger read. */
export interface ListInferenceAttemptsRequest {
    filter?: InferenceAttemptFilter | undefined;
}
/** GetInferenceAttemptRequest loads one attempt row by ledger id. */
export interface GetInferenceAttemptRequest {
    id: bigint;
}
/** GetInferenceAttemptResponse includes a bounded snapshot of the invocation history. */
export interface GetInferenceAttemptResponse {
    attempt?: InferenceAttempt | undefined;
    /**
     * Up to 50 other attempts, ordered by attempt number then id. The requested
     * attempt is always returned separately, even when history is truncated.
     */
    relatedAttempts: InferenceAttempt[];
    relatedAttemptsTruncated: boolean;
}
/** GetInferenceUsageRequest aggregates the filtered attempt set. */
export interface GetInferenceUsageRequest {
    filter?: InferenceAttemptFilter | undefined;
}
/**
 * GetInferenceUsageResponse carries the rollup plus the
 * provider/operation/status breakdown for one filtered attempt set.
 */
export interface GetInferenceUsageResponse {
    summary?: InferenceUsageSummary | undefined;
    breakdown: InferenceUsageBreakdownRow[];
}
/**
 * SelectableInferenceModel is one active catalog model whose provider is
 * currently configured. It carries display identity and API choices only.
 */
export interface SelectableInferenceModel {
    id: bigint;
    displayName: string;
    providerId: string;
    providerDisplayName: string;
    providerModelId: string;
    defaultApi: InferenceAPI;
    supportedApis: InferenceAPI[];
}
/**
 * ListSelectableInferenceModelsRequest optionally names the operation the
 * selection will apply to, so the response can describe its routed default.
 */
export interface ListSelectableInferenceModelsRequest {
    operation?: number | undefined;
}
/**
 * ListSelectableInferenceModelsResponse lists the selectable models. The routed
 * fields are present only when the named operation currently has a route.
 */
export interface ListSelectableInferenceModelsResponse {
    models: SelectableInferenceModel[];
    routedInferenceModelId?: bigint | undefined;
    routedEffectiveApi?: InferenceAPI | undefined;
    /** Display identity of the routed model, present even when it is not selectable. */
    routedModelDisplayName?: string | undefined;
}
export declare const InferenceOperationRoute: MessageFns<InferenceOperationRoute>;
export declare const InferenceRateLimitBucket: MessageFns<InferenceRateLimitBucket>;
export declare const InferenceModelRateLimitPolicy: MessageFns<InferenceModelRateLimitPolicy>;
export declare const InferenceAttemptActor: MessageFns<InferenceAttemptActor>;
export declare const InferenceAttemptOrganization: MessageFns<InferenceAttemptOrganization>;
export declare const InferenceAttempt: MessageFns<InferenceAttempt>;
export declare const InferenceAttemptFilter: MessageFns<InferenceAttemptFilter>;
export declare const InferenceAttemptFilter_MetadataEntry: MessageFns<InferenceAttemptFilter_MetadataEntry>;
export declare const ListInferenceAttemptsResponse: MessageFns<ListInferenceAttemptsResponse>;
export declare const InferenceUsageSummary: MessageFns<InferenceUsageSummary>;
export declare const InferenceUsageBreakdownRow: MessageFns<InferenceUsageBreakdownRow>;
export declare const ListInferenceRoutesRequest: MessageFns<ListInferenceRoutesRequest>;
export declare const InferenceOperationRouteEntry: MessageFns<InferenceOperationRouteEntry>;
export declare const ListInferenceRoutesResponse: MessageFns<ListInferenceRoutesResponse>;
export declare const UpdateInferenceRouteRequest: MessageFns<UpdateInferenceRouteRequest>;
export declare const UpdateInferenceRouteResponse: MessageFns<UpdateInferenceRouteResponse>;
export declare const ListInferenceRateLimitPoliciesRequest: MessageFns<ListInferenceRateLimitPoliciesRequest>;
export declare const ListInferenceRateLimitPoliciesResponse: MessageFns<ListInferenceRateLimitPoliciesResponse>;
export declare const UpdateInferenceRateLimitPolicyRequest: MessageFns<UpdateInferenceRateLimitPolicyRequest>;
export declare const UpdateInferenceRateLimitPolicyResponse: MessageFns<UpdateInferenceRateLimitPolicyResponse>;
export declare const ListInferenceAttemptsRequest: MessageFns<ListInferenceAttemptsRequest>;
export declare const GetInferenceAttemptRequest: MessageFns<GetInferenceAttemptRequest>;
export declare const GetInferenceAttemptResponse: MessageFns<GetInferenceAttemptResponse>;
export declare const GetInferenceUsageRequest: MessageFns<GetInferenceUsageRequest>;
export declare const GetInferenceUsageResponse: MessageFns<GetInferenceUsageResponse>;
export declare const SelectableInferenceModel: MessageFns<SelectableInferenceModel>;
export declare const ListSelectableInferenceModelsRequest: MessageFns<ListSelectableInferenceModelsRequest>;
export declare const ListSelectableInferenceModelsResponse: MessageFns<ListSelectableInferenceModelsResponse>;
type Builtin = Date | Function | Uint8Array | string | number | boolean | bigint | undefined;
type DeepPartial<T> = T extends bigint ? string | number | bigint : T extends Builtin ? T : T extends globalThis.Array<infer U> ? globalThis.Array<DeepPartial<U>> : T extends ReadonlyArray<infer U> ? ReadonlyArray<DeepPartial<U>> : T extends {} ? {
    [K in keyof T]?: DeepPartial<T[K]>;
} : Partial<T>;
type KeysOfUnion<T> = T extends T ? keyof T : never;
type Exact<P, I extends P> = P extends Builtin ? P : P & {
    [K in keyof P]: Exact<P[K], I[K]>;
} & {
    [K in Exclude<keyof I, KeysOfUnion<P>>]: never;
};
interface MessageFns<T> {
    encode(message: T, writer?: BinaryWriter): BinaryWriter;
    decode(input: BinaryReader | Uint8Array, length?: number): T;
    fromJSON(object: any): T;
    toJSON(message: T): unknown;
    create<I extends Exact<DeepPartial<T>, I>>(base?: I): T;
    fromPartial<I extends Exact<DeepPartial<T>, I>>(object: I): T;
}
export {};
//# sourceMappingURL=inference_control_plane.d.ts.map