import { BinaryReader, BinaryWriter } from "@bufbuild/protobuf/wire";
export declare enum AuthProvider {
    /** AUTH_PROVIDER_UNSPECIFIED - Default unspecified state */
    AUTH_PROVIDER_UNSPECIFIED = 0,
    /** AUTH_PROVIDER_EMAIL - Email/password authentication */
    AUTH_PROVIDER_EMAIL = 9,
    /** AUTH_PROVIDER_PHONE - Phone/SMS authentication */
    AUTH_PROVIDER_PHONE = 10,
    /** AUTH_PROVIDER_OAUTH - OAuth/OIDC authentication; the provider is identified by slug */
    AUTH_PROVIDER_OAUTH = 11,
    UNRECOGNIZED = -1
}
export declare function authProviderFromJSON(object: any): AuthProvider;
export declare function authProviderToJSON(object: AuthProvider): string;
export declare enum TokenType {
    /** TOKEN_TYPE_UNSPECIFIED - Default unspecified state */
    TOKEN_TYPE_UNSPECIFIED = 0,
    /** TOKEN_TYPE_AUTHENTICATION - Standard session authentication token */
    TOKEN_TYPE_AUTHENTICATION = 1,
    /** TOKEN_TYPE_EMAIL_VERIFICATION - Token for verifying email address */
    TOKEN_TYPE_EMAIL_VERIFICATION = 2,
    /** TOKEN_TYPE_PASSWORD_RESET - Token for initiating password reset */
    TOKEN_TYPE_PASSWORD_RESET = 3,
    /** TOKEN_TYPE_ACCOUNT_INVITATION - Admin-created account password setup */
    TOKEN_TYPE_ACCOUNT_INVITATION = 5,
    /** TOKEN_TYPE_PHONE_VERIFICATION - OTP code for verifying phone number */
    TOKEN_TYPE_PHONE_VERIFICATION = 4,
    UNRECOGNIZED = -1
}
export declare function tokenTypeFromJSON(object: any): TokenType;
export declare function tokenTypeToJSON(object: TokenType): string;
export declare enum TokenStatus {
    /** TOKEN_STATUS_UNSPECIFIED - Treated as ALL when omitted in filters */
    TOKEN_STATUS_UNSPECIFIED = 0,
    TOKEN_STATUS_ALL = 1,
    TOKEN_STATUS_ACTIVE = 2,
    TOKEN_STATUS_EXPIRED = 3,
    TOKEN_STATUS_REVOKED = 4,
    UNRECOGNIZED = -1
}
export declare function tokenStatusFromJSON(object: any): TokenStatus;
export declare function tokenStatusToJSON(object: TokenStatus): string;
export declare enum MessageType {
    /** MESSAGE_TYPE_UNSPECIFIED - Default unspecified state */
    MESSAGE_TYPE_UNSPECIFIED = 0,
    /** MESSAGE_TYPE_SMS - Regular SMS message */
    MESSAGE_TYPE_SMS = 1,
    /** MESSAGE_TYPE_WHATSAPP - WhatsApp message */
    MESSAGE_TYPE_WHATSAPP = 2,
    UNRECOGNIZED = -1
}
export declare function messageTypeFromJSON(object: any): MessageType;
export declare function messageTypeToJSON(object: MessageType): string;
/**
 * --------------------
 * Email Registration Messages
 * --------------------
 */
export interface EmailRegistrationRequest {
    /** User's email address */
    email: string;
    /** User's password */
    password: string;
    username?: string | undefined;
    firstName?: string | undefined;
    lastName?: string | undefined;
    /** Phone number in E.164 international format (optional) */
    phoneNumber?: string | undefined;
    /** Origin of the requesting frontend (e.g. "https://students.example.com"); must be in the server's allowed frontend origins */
    frontendOrigin?: string | undefined;
}
export interface EmailRegistrationResponse {
}
/** Request for email/password authentication */
export interface EmailAuthRequest {
    /** User's email address */
    email: string;
    /** User's password */
    password: string;
    /** Optional OTP code for 2FA */
    otpCode?: string | undefined;
}
/**
 * Response for email/password authentication.
 * Successful completed logins issue the session through Set-Cookie.
 */
export interface EmailAuthResponse {
    /** Whether OTP code is required for this user */
    otpRequired: boolean;
    /** Message to display to user (e.g., "Please provide your 6-digit authenticator code") */
    message?: string | undefined;
}
/** Request to reset a password */
export interface PasswordResetRequest {
    /** Email address of the account */
    email: string;
    /** Origin of the requesting frontend (e.g. "https://students.example.com"); must be in the server's allowed frontend origins */
    frontendOrigin?: string | undefined;
}
/** Response to a password reset request */
export interface PasswordResetResponse {
}
/** Request to change a password */
export interface PasswordChangeRequest {
    /** Current password */
    oldPassword: string;
    /** New password */
    newPassword: string;
}
/** Response to a password change request */
export interface PasswordChangeResponse {
}
/** Request to complete password reset using a verification code and new password */
export interface PasswordResetCompleteRequest {
    /** Opaque security token from the password-reset email link */
    verificationCode: string;
    /** The new password chosen by the user */
    newPassword: string;
}
/** Request to verify an email address using a verification code */
export interface EmailVerificationRequest {
    /** Opaque security token from the verification-email link */
    verificationCode: string;
}
/** Request to send a phone verification OTP code */
export interface SendPhoneOTPRequest {
    /** Phone number in E.164 international format */
    phoneNumber: string;
}
/** Response for sending phone OTP */
export interface SendPhoneOTPResponse {
}
/** Request to verify a phone number using OTP code */
export interface VerifyPhoneOTPRequest {
    /** 6-digit OTP code received via SMS */
    otpCode: string;
}
/** Response for phone OTP verification */
export interface VerifyPhoneOTPResponse {
}
/** Request to resend phone verification OTP */
export interface ResendPhoneOTPRequest {
}
/** Response for phone OTP resend */
export interface ResendPhoneOTPResponse {
}
export interface OAuthStateRequest {
    /** Frontend destination after authentication */
    returnUrl: string;
    /** Exact registered callback URI used for this attempt */
    redirectUri: string;
    /** Slug of the configured OAuth provider the state will be used with */
    providerSlug: string;
    /** Frontend callback page the form_post relay redirects to; must be an allowed frontend URL */
    frontendCallbackUrl?: string | undefined;
}
export interface OAuthStateResponse {
    /** Server-issued, browser-bound OAuth state */
    state: string;
    /** Validated callback URI to use in the authorization request */
    redirectUri: string;
    /** Complete provider authorization URL (PKCE, nonce, and response mode included) */
    authorizationUrl: string;
}
export interface OAuthCodeRequest {
    /** OAuth code from the provider */
    code: string;
    /** Opaque server-issued state returned by the provider */
    state: string;
}
export interface OAuthTokenResponse {
    accountCreated: boolean;
    /** Frontend destination recorded in the verified state */
    returnUrl: string;
    /** Slug of the provider that authenticated the user */
    providerSlug: string;
}
/** Public description of a configured OAuth provider, used to render sign-in buttons */
export interface OAuthProviderDescriptor {
    /** Stable provider slug */
    slug: string;
    /** Human-readable provider name */
    displayName: string;
    /** Frontend icon key; empty selects the generic icon */
    iconKey: string;
    /**
     * True when the provider answers with response_mode=form_post. The frontend
     * then uses the backend relay (/auth/oauth/form-post) as redirect_uri and
     * passes its own callback page as frontend_callback_url.
     */
    formPost: boolean;
}
export interface ListOAuthProvidersResponse {
    providers: OAuthProviderDescriptor[];
}
/** Request to logout */
export interface LogoutRequest {
    /** Optional: logout from all devices/sessions */
    logoutEverywhere: boolean;
}
/** Response for logout */
export interface LogoutResponse {
}
export interface ActiveSession {
    sessionId: string;
    current: boolean;
    authMethod: AuthProvider;
    ipAddress: string;
    userAgent: string;
    deviceId: string;
    issuedAt?: Date | undefined;
    expiresAt?: Date | undefined;
    lastUsedAt?: Date | undefined;
    /** Set when auth_method is AUTH_PROVIDER_OAUTH */
    oauthProviderSlug?: string | undefined;
}
/** Request to add password authentication to an existing account */
export interface AddPasswordRequest {
    /** The password to set for the account */
    password: string;
    /** Password confirmation to prevent typos */
    confirmPassword: string;
}
/** Response for add password request */
export interface AddPasswordResponse {
}
/** Information about an OAuth provider connection */
export interface OAuthProviderInfo {
    /** Email associated with this provider */
    email: string;
    /** When this provider was first linked */
    firstLogin?: Date | undefined;
    /** Most recent login with this provider */
    lastLogin?: Date | undefined;
    /** Number of times user has logged in with this provider */
    loginCount: number;
    /** Slug of the linked OAuth provider */
    providerSlug: string;
    /** Provider display name from the current provider sample; empty when no longer configured */
    displayName: string;
}
/** Response containing user's authentication methods */
export interface GetAuthMethodsResponse {
    /** Whether the user has password authentication set up */
    hasPassword: boolean;
    /** List of connected OAuth providers */
    oauthProviders: OAuthProviderInfo[];
    /** Password method plus linked OAuth providers; TOTP is not counted separately */
    totalMethods: number;
    /** Whether OTP/TOTP 2FA is enabled for the user */
    otpEnabled: boolean;
    /** When OTP/TOTP 2FA was enabled (if available) */
    otpVerifiedAt?: Date | undefined;
}
/** Request to set up OTP/TOTP 2FA */
export interface SetupOTPRequest {
    /** Current password required for security */
    currentPassword: string;
}
/** Response containing OTP setup information */
export interface SetupOTPResponse {
    /** Base32 encoded TOTP secret for QR code */
    secret?: string | undefined;
    /** otpauth:// URI; the frontend generates its QR code from this URI */
    qrCodeUrl?: string | undefined;
}
/** Request to verify OTP setup with a test code */
export interface VerifyOTPSetupRequest {
    /** 6-digit TOTP code from authenticator app */
    otpCode: string;
    /** Current password required for security */
    currentPassword: string;
}
/** Response for OTP setup verification */
export interface VerifyOTPSetupResponse {
}
/** Request to disable OTP/TOTP 2FA */
export interface DisableOTPRequest {
    /** Current password required for security */
    currentPassword: string;
}
/** Response for OTP disable request */
export interface DisableOTPResponse {
}
export interface EmailAcceptInvitationRequest {
    token: string;
    password: string;
}
export interface EmailAcceptInvitationResponse {
}
export declare const EmailRegistrationRequest: MessageFns<EmailRegistrationRequest>;
export declare const EmailRegistrationResponse: MessageFns<EmailRegistrationResponse>;
export declare const EmailAuthRequest: MessageFns<EmailAuthRequest>;
export declare const EmailAuthResponse: MessageFns<EmailAuthResponse>;
export declare const PasswordResetRequest: MessageFns<PasswordResetRequest>;
export declare const PasswordResetResponse: MessageFns<PasswordResetResponse>;
export declare const PasswordChangeRequest: MessageFns<PasswordChangeRequest>;
export declare const PasswordChangeResponse: MessageFns<PasswordChangeResponse>;
export declare const PasswordResetCompleteRequest: MessageFns<PasswordResetCompleteRequest>;
export declare const EmailVerificationRequest: MessageFns<EmailVerificationRequest>;
export declare const SendPhoneOTPRequest: MessageFns<SendPhoneOTPRequest>;
export declare const SendPhoneOTPResponse: MessageFns<SendPhoneOTPResponse>;
export declare const VerifyPhoneOTPRequest: MessageFns<VerifyPhoneOTPRequest>;
export declare const VerifyPhoneOTPResponse: MessageFns<VerifyPhoneOTPResponse>;
export declare const ResendPhoneOTPRequest: MessageFns<ResendPhoneOTPRequest>;
export declare const ResendPhoneOTPResponse: MessageFns<ResendPhoneOTPResponse>;
export declare const OAuthStateRequest: MessageFns<OAuthStateRequest>;
export declare const OAuthStateResponse: MessageFns<OAuthStateResponse>;
export declare const OAuthCodeRequest: MessageFns<OAuthCodeRequest>;
export declare const OAuthTokenResponse: MessageFns<OAuthTokenResponse>;
export declare const OAuthProviderDescriptor: MessageFns<OAuthProviderDescriptor>;
export declare const ListOAuthProvidersResponse: MessageFns<ListOAuthProvidersResponse>;
export declare const LogoutRequest: MessageFns<LogoutRequest>;
export declare const LogoutResponse: MessageFns<LogoutResponse>;
export declare const ActiveSession: MessageFns<ActiveSession>;
export declare const AddPasswordRequest: MessageFns<AddPasswordRequest>;
export declare const AddPasswordResponse: MessageFns<AddPasswordResponse>;
export declare const OAuthProviderInfo: MessageFns<OAuthProviderInfo>;
export declare const GetAuthMethodsResponse: MessageFns<GetAuthMethodsResponse>;
export declare const SetupOTPRequest: MessageFns<SetupOTPRequest>;
export declare const SetupOTPResponse: MessageFns<SetupOTPResponse>;
export declare const VerifyOTPSetupRequest: MessageFns<VerifyOTPSetupRequest>;
export declare const VerifyOTPSetupResponse: MessageFns<VerifyOTPSetupResponse>;
export declare const DisableOTPRequest: MessageFns<DisableOTPRequest>;
export declare const DisableOTPResponse: MessageFns<DisableOTPResponse>;
export declare const EmailAcceptInvitationRequest: MessageFns<EmailAcceptInvitationRequest>;
export declare const EmailAcceptInvitationResponse: MessageFns<EmailAcceptInvitationResponse>;
type Builtin = Date | Function | Uint8Array | string | number | boolean | bigint | undefined;
type DeepPartial<T> = T extends bigint ? string | number | bigint : T extends Builtin ? T : T extends globalThis.Array<infer U> ? globalThis.Array<DeepPartial<U>> : T extends ReadonlyArray<infer U> ? ReadonlyArray<DeepPartial<U>> : T extends {} ? {
    [K in keyof T]?: DeepPartial<T[K]>;
} : Partial<T>;
type KeysOfUnion<T> = T extends T ? keyof T : never;
type Exact<P, I extends P> = P extends Builtin ? P : P & {
    [K in keyof P]: Exact<P[K], I[K]>;
} & {
    [K in Exclude<keyof I, KeysOfUnion<P>>]: never;
};
interface MessageFns<T> {
    encode(message: T, writer?: BinaryWriter): BinaryWriter;
    decode(input: BinaryReader | Uint8Array, length?: number): T;
    fromJSON(object: any): T;
    toJSON(message: T): unknown;
    create<I extends Exact<DeepPartial<T>, I>>(base?: I): T;
    fromPartial<I extends Exact<DeepPartial<T>, I>>(object: I): T;
}
export {};
//# sourceMappingURL=authentication.d.ts.map