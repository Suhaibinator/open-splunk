import { BinaryReader, BinaryWriter } from "@bufbuild/protobuf/wire";
/** PaginationRequest provides standard pagination parameters for list endpoints */
export interface PaginationRequest {
    /** Page number (1-based, default: 1) */
    page: number;
    /** Items per page; 0 uses default_pagination_limit and larger than max_pagination_limit is rejected, unless the route documents its own keys */
    limit: number;
    /** Optional cursor for cursor-based pagination */
    cursor: bigint;
    /** Opt in to exact total count metadata where supported; default false */
    includeTotalCount: boolean;
}
/** PaginationResponse provides pagination metadata for list responses */
export interface PaginationResponse {
    /** Current page number */
    currentPage: number;
    /** Exact total pages only when total_count_included is true */
    totalPages: number;
    /** Exact total items only when total_count_included is true */
    totalItems: bigint;
    /** Number of items per page */
    itemsPerPage: number;
    /** Whether there are more pages */
    hasNextPage: boolean;
    /** Whether there are previous pages */
    hasPrevPage: boolean;
    /** Cursor for next page (if using cursor pagination) */
    nextCursor: bigint;
    /** Cursor for previous page (if using cursor pagination) */
    prevCursor: bigint;
    /** Whether total_items and total_pages are authoritative */
    totalCountIncluded: boolean;
}
/** SortRequest provides standard sorting parameters */
export interface SortRequest {
    /** Whether to sort descending (default: false) */
    sortDesc: boolean;
}
/** FilterRequest provides common filtering parameters */
export interface FilterRequest {
    /** Inclusive lower timestamp bound; the route chooses the timestamp field */
    fromDate?: Date | undefined;
    /** Inclusive upper timestamp bound; the route chooses the timestamp field */
    toDate?: Date | undefined;
    /** General search term */
    search: string;
}
export declare const PaginationRequest: MessageFns<PaginationRequest>;
export declare const PaginationResponse: MessageFns<PaginationResponse>;
export declare const SortRequest: MessageFns<SortRequest>;
export declare const FilterRequest: MessageFns<FilterRequest>;
type Builtin = Date | Function | Uint8Array | string | number | boolean | bigint | undefined;
type DeepPartial<T> = T extends bigint ? string | number | bigint : T extends Builtin ? T : T extends globalThis.Array<infer U> ? globalThis.Array<DeepPartial<U>> : T extends ReadonlyArray<infer U> ? ReadonlyArray<DeepPartial<U>> : T extends {} ? {
    [K in keyof T]?: DeepPartial<T[K]>;
} : Partial<T>;
type KeysOfUnion<T> = T extends T ? keyof T : never;
type Exact<P, I extends P> = P extends Builtin ? P : P & {
    [K in keyof P]: Exact<P[K], I[K]>;
} & {
    [K in Exclude<keyof I, KeysOfUnion<P>>]: never;
};
interface MessageFns<T> {
    encode(message: T, writer?: BinaryWriter): BinaryWriter;
    decode(input: BinaryReader | Uint8Array, length?: number): T;
    fromJSON(object: any): T;
    toJSON(message: T): unknown;
    create<I extends Exact<DeepPartial<T>, I>>(base?: I): T;
    fromPartial<I extends Exact<DeepPartial<T>, I>>(object: I): T;
}
export {};
//# sourceMappingURL=pagination.d.ts.map