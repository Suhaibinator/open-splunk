import { BinaryReader, BinaryWriter } from "@bufbuild/protobuf/wire";
import { OrganizationRole } from "./organization";
/** IDs 1-999 are reserved for go-common; application types start at 1000. */
export declare enum NativeNotificationType {
    NATIVE_NOTIFICATION_TYPE_UNSPECIFIED = 0,
    NATIVE_NOTIFICATION_TYPE_UNREAD_CHAT = 1,
    NATIVE_NOTIFICATION_TYPE_TOOL_APPROVAL = 2,
    NATIVE_NOTIFICATION_TYPE_ORGANIZATION_INVITATION = 3,
    UNRECOGNIZED = -1
}
export declare function nativeNotificationTypeFromJSON(object: any): NativeNotificationType;
export declare function nativeNotificationTypeToJSON(object: NativeNotificationType): string;
/** Recipient email is source authority, never display payload. */
export interface OrganizationInvitationNotificationPayload {
    invitationId: bigint;
    organizationId: bigint;
    organizationName: string;
    inviterId: bigint;
    inviterDisplayName: string;
    role: OrganizationRole;
    expiresAt?: Date | undefined;
}
/**
 * Immutable native event envelope. Display fields are prepared from the source
 * separately so name edits cannot change an accepted async event's fingerprint.
 */
export interface OrganizationInvitationNotificationSourcePayload {
    invitationId: bigint;
    recipientId: bigint;
}
export interface Notification {
    id: bigint;
    type: number;
    payload: Uint8Array;
    fallbackText: string;
    revision: bigint;
    readRevision: bigint;
    resolved: boolean;
    unavailable: boolean;
    activityScope: string;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    occurrenceCount: bigint;
    /**
     * Optional per-type display view, computed at read time by the type's source
     * evaluator from the same snapshot that authorized the row and never
     * persisted. Present only for rows authorized at this read; absent for
     * unavailable rows and for types whose evaluator returns no view. Decode it
     * with the type's view decoder, never with the payload decoder.
     */
    view: Uint8Array;
}
export interface ChatNotificationPayload {
    channelId: bigint;
    parentMessageId: bigint;
    messageId: bigint;
    agentRunId: bigint;
    /**
     * The message is a thread reply also shown on the main timeline; parent_message_id
     * still names the thread root so clients can navigate into the thread.
     */
    broadcastToChannel: boolean;
}
/**
 * Read-time view for both native chat types (unread chat and tool approval),
 * built from the snapshot that authorized the entry and never persisted. Every
 * name is the current one at read time. A view whose fields are all empty is
 * not sent.
 */
export interface ChatNotificationView {
    /** Group channel's current name; empty for direct messages and unnamed channels. */
    channelName: string;
    /**
     * Direct messages: the other participant's current display name. Empty for
     * group channels, self-conversations, and a missing or deleted counterpart.
     */
    counterpartName: string;
    /**
     * Unread chat only: the channel's current last_message_preview. Empty for
     * tool approvals and when the recipient sent the channel's last message.
     */
    lastMessagePreview: string;
    /**
     * Unread chat only: current display name of the last message's sender. Empty
     * when unknown, deleted, or the recipient themself.
     */
    lastSenderName: string;
}
/**
 * Durable native source envelope. Mention recipients are captured when the
 * source message is recorded and never reconstructed from later message edits.
 */
export interface ChatNotificationSourcePayload {
    target?: ChatNotificationPayload | undefined;
    mentionUserIds: bigint[];
}
export interface ListNotificationsRequest {
    beforeId: bigint;
    limit: number;
    unreadOnly: boolean;
    /** Exact registered activity scope; omitted lists the global inbox. */
    activityScope?: string | undefined;
}
export interface ListNotificationsResponse {
    notifications: Notification[];
    nextBeforeId: bigint;
}
export interface GetNotificationRequest {
    id: bigint;
}
export interface NotificationCountRequest {
}
/**
 * A bounded count under current source authorization. When complete is false,
 * unread_count is a confirmed lower bound; zero means unknown, not an empty inbox.
 */
export interface NotificationCountResponse {
    unreadCount: bigint;
    complete: boolean;
}
export interface NotificationReadReceipt {
    id: bigint;
    revision: bigint;
}
/** Explicit observed revisions make bulk acknowledgement safe against new arrivals. */
export interface MarkNotificationsReadRequest {
    receipts: NotificationReadReceipt[];
}
export interface NotificationMutationResponse {
    success: boolean;
}
export interface ClaimNotificationAlertRequest {
    id: bigint;
    revision: bigint;
}
export interface ClaimNotificationAlertResponse {
    claimed: boolean;
    notification?: Notification | undefined;
    /**
     * Present only when the qualifying source is too young for the sampled alert
     * window. Retry this observed revision after this delay; other refusals are final.
     */
    retryAfterMs?: number | undefined;
}
export interface NotificationPreference {
    type: number;
    alertsEnabled?: boolean | undefined;
    emailEnabled?: boolean | undefined;
}
export interface NotificationPreferencesRequest {
}
export interface NotificationTypeInfo {
    type: number;
    name: string;
    alertsAvailable: boolean;
    emailAvailable: boolean;
}
export interface NotificationPreferencesResponse {
    inAppAlertsEnabled: boolean;
    preferences: NotificationPreference[];
    types: NotificationTypeInfo[];
    emailNotificationsEnabled: boolean;
    chatEmailNotificationsEnabled: boolean;
}
export interface UpdateNotificationPreferencesRequest {
    inAppAlertsEnabled?: boolean | undefined;
    preferences: NotificationPreference[];
}
export interface NotificationChanged {
    id: bigint;
    revision: bigint;
}
/** One complete scope set per connection; an empty set releases all its activity. */
export interface NotificationActivity {
    scopes: string[];
}
export declare const OrganizationInvitationNotificationPayload: MessageFns<OrganizationInvitationNotificationPayload>;
export declare const OrganizationInvitationNotificationSourcePayload: MessageFns<OrganizationInvitationNotificationSourcePayload>;
export declare const Notification: MessageFns<Notification>;
export declare const ChatNotificationPayload: MessageFns<ChatNotificationPayload>;
export declare const ChatNotificationView: MessageFns<ChatNotificationView>;
export declare const ChatNotificationSourcePayload: MessageFns<ChatNotificationSourcePayload>;
export declare const ListNotificationsRequest: MessageFns<ListNotificationsRequest>;
export declare const ListNotificationsResponse: MessageFns<ListNotificationsResponse>;
export declare const GetNotificationRequest: MessageFns<GetNotificationRequest>;
export declare const NotificationCountRequest: MessageFns<NotificationCountRequest>;
export declare const NotificationCountResponse: MessageFns<NotificationCountResponse>;
export declare const NotificationReadReceipt: MessageFns<NotificationReadReceipt>;
export declare const MarkNotificationsReadRequest: MessageFns<MarkNotificationsReadRequest>;
export declare const NotificationMutationResponse: MessageFns<NotificationMutationResponse>;
export declare const ClaimNotificationAlertRequest: MessageFns<ClaimNotificationAlertRequest>;
export declare const ClaimNotificationAlertResponse: MessageFns<ClaimNotificationAlertResponse>;
export declare const NotificationPreference: MessageFns<NotificationPreference>;
export declare const NotificationPreferencesRequest: MessageFns<NotificationPreferencesRequest>;
export declare const NotificationTypeInfo: MessageFns<NotificationTypeInfo>;
export declare const NotificationPreferencesResponse: MessageFns<NotificationPreferencesResponse>;
export declare const UpdateNotificationPreferencesRequest: MessageFns<UpdateNotificationPreferencesRequest>;
export declare const NotificationChanged: MessageFns<NotificationChanged>;
export declare const NotificationActivity: MessageFns<NotificationActivity>;
type Builtin = Date | Function | Uint8Array | string | number | boolean | bigint | undefined;
type DeepPartial<T> = T extends bigint ? string | number | bigint : T extends Builtin ? T : T extends globalThis.Array<infer U> ? globalThis.Array<DeepPartial<U>> : T extends ReadonlyArray<infer U> ? ReadonlyArray<DeepPartial<U>> : T extends {} ? {
    [K in keyof T]?: DeepPartial<T[K]>;
} : Partial<T>;
type KeysOfUnion<T> = T extends T ? keyof T : never;
type Exact<P, I extends P> = P extends Builtin ? P : P & {
    [K in keyof P]: Exact<P[K], I[K]>;
} & {
    [K in Exclude<keyof I, KeysOfUnion<P>>]: never;
};
interface MessageFns<T> {
    encode(message: T, writer?: BinaryWriter): BinaryWriter;
    decode(input: BinaryReader | Uint8Array, length?: number): T;
    fromJSON(object: any): T;
    toJSON(message: T): unknown;
    create<I extends Exact<DeepPartial<T>, I>>(base?: I): T;
    fromPartial<I extends Exact<DeepPartial<T>, I>>(object: I): T;
}
export {};
//# sourceMappingURL=notification.d.ts.map