import { BinaryReader, BinaryWriter } from "@bufbuild/protobuf/wire";
import { AgentSessionSummary } from "./chat";
import { InferenceAPI } from "./inference";
export interface InferenceSessionPinVersion {
    agentSessionId: bigint;
    expectedPinVersion: bigint;
}
export interface RetargetInferenceSessionRequest {
    agentSessionId: bigint;
    expectedPinVersion: bigint;
    inferenceModelId: bigint;
    api?: InferenceAPI | undefined;
    siteOverride: boolean;
}
export interface RetargetInferenceSessionResponse {
    session?: AgentSessionSummary | undefined;
}
export interface RetargetInferenceSessionsRequest {
    organizationId: bigint;
    sessions: InferenceSessionPinVersion[];
    inferenceModelId: bigint;
    api?: InferenceAPI | undefined;
    siteOverride: boolean;
}
export interface RetargetInferenceSessionsResponse {
    sessions: AgentSessionSummary[];
}
export declare const InferenceSessionPinVersion: MessageFns<InferenceSessionPinVersion>;
export declare const RetargetInferenceSessionRequest: MessageFns<RetargetInferenceSessionRequest>;
export declare const RetargetInferenceSessionResponse: MessageFns<RetargetInferenceSessionResponse>;
export declare const RetargetInferenceSessionsRequest: MessageFns<RetargetInferenceSessionsRequest>;
export declare const RetargetInferenceSessionsResponse: MessageFns<RetargetInferenceSessionsResponse>;
type Builtin = Date | Function | Uint8Array | string | number | boolean | bigint | undefined;
type DeepPartial<T> = T extends bigint ? string | number | bigint : T extends Builtin ? T : T extends globalThis.Array<infer U> ? globalThis.Array<DeepPartial<U>> : T extends ReadonlyArray<infer U> ? ReadonlyArray<DeepPartial<U>> : T extends {} ? {
    [K in keyof T]?: DeepPartial<T[K]>;
} : Partial<T>;
type KeysOfUnion<T> = T extends T ? keyof T : never;
type Exact<P, I extends P> = P extends Builtin ? P : P & {
    [K in keyof P]: Exact<P[K], I[K]>;
} & {
    [K in Exclude<keyof I, KeysOfUnion<P>>]: never;
};
interface MessageFns<T> {
    encode(message: T, writer?: BinaryWriter): BinaryWriter;
    decode(input: BinaryReader | Uint8Array, length?: number): T;
    fromJSON(object: any): T;
    toJSON(message: T): unknown;
    create<I extends Exact<DeepPartial<T>, I>>(base?: I): T;
    fromPartial<I extends Exact<DeepPartial<T>, I>>(object: I): T;
}
export {};
//# sourceMappingURL=inference_routing_api.d.ts.map