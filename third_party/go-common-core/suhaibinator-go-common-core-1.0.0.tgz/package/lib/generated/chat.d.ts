import { BinaryReader, BinaryWriter } from "@bufbuild/protobuf/wire";
import { AttachmentVisibility, UploadedAttachment } from "./attachment";
import { InferenceAPI } from "./inference";
import { InferenceBlockReason, InferenceSelectionSource, InferenceSessionRetarget } from "./inference_routing";
import { PublicUser } from "./user";
export declare enum ChannelType {
    CHANNEL_TYPE_UNSPECIFIED = 0,
    /** CHANNEL_TYPE_DIRECT - 1:1 channel */
    CHANNEL_TYPE_DIRECT = 1,
    /** CHANNEL_TYPE_GROUP - group channel */
    CHANNEL_TYPE_GROUP = 2,
    UNRECOGNIZED = -1
}
export declare function channelTypeFromJSON(object: any): ChannelType;
export declare function channelTypeToJSON(object: ChannelType): string;
export declare enum ChannelRole {
    CHANNEL_ROLE_UNSPECIFIED = 0,
    /** CHANNEL_ROLE_MEMBER - Regular member */
    CHANNEL_ROLE_MEMBER = 1,
    /** CHANNEL_ROLE_ADMIN - Admin (can manage participants) */
    CHANNEL_ROLE_ADMIN = 2,
    /** CHANNEL_ROLE_OWNER - Owner (highest channel participant role) */
    CHANNEL_ROLE_OWNER = 3,
    UNRECOGNIZED = -1
}
export declare function channelRoleFromJSON(object: any): ChannelRole;
export declare function channelRoleToJSON(object: ChannelRole): string;
export declare enum MessageContentType {
    MESSAGE_CONTENT_TYPE_UNSPECIFIED = 0,
    /** MESSAGE_CONTENT_TYPE_TEXT - Plain text */
    MESSAGE_CONTENT_TYPE_TEXT = 1,
    /** MESSAGE_CONTENT_TYPE_MARKDOWN - Markdown formatted text */
    MESSAGE_CONTENT_TYPE_MARKDOWN = 2,
    UNRECOGNIZED = -1
}
export declare function messageContentTypeFromJSON(object: any): MessageContentType;
export declare function messageContentTypeToJSON(object: MessageContentType): string;
export declare enum MessageStreamState {
    MESSAGE_STREAM_STATE_UNSPECIFIED = 0,
    MESSAGE_STREAM_STATE_STREAMING = 1,
    MESSAGE_STREAM_STATE_COMPLETE = 2,
    MESSAGE_STREAM_STATE_FAILED = 3,
    UNRECOGNIZED = -1
}
export declare function messageStreamStateFromJSON(object: any): MessageStreamState;
export declare function messageStreamStateToJSON(object: MessageStreamState): string;
/**
 * MessageKind discriminates ordinary chat messages from the richer agentic
 * transcript rows (tool calls/results, system events, compaction, agent notes).
 * Stored message kinds must be specified.
 */
export declare enum MessageKind {
    /** MESSAGE_KIND_UNSPECIFIED - invalid for stored messages */
    MESSAGE_KIND_UNSPECIFIED = 0,
    MESSAGE_KIND_STANDARD = 1,
    /** MESSAGE_KIND_SYSTEM_EVENT - join/leave/rename/etc. — human-visible lifecycle */
    MESSAGE_KIND_SYSTEM_EVENT = 2,
    /** MESSAGE_KIND_TOOL_CALL - assistant-initiated tool invocation */
    MESSAGE_KIND_TOOL_CALL = 3,
    /** MESSAGE_KIND_TOOL_RESULT - result of a tool invocation */
    MESSAGE_KIND_TOOL_RESULT = 4,
    /** MESSAGE_KIND_COMPACTION_SUMMARY - context checkpoint */
    MESSAGE_KIND_COMPACTION_SUMMARY = 5,
    /** MESSAGE_KIND_AGENT_NOTE - LLM-only scratchpad / injected instruction */
    MESSAGE_KIND_AGENT_NOTE = 6,
    /** MESSAGE_KIND_PROVIDER_STATE - opaque provider continuation state; internal-only */
    MESSAGE_KIND_PROVIDER_STATE = 7,
    UNRECOGNIZED = -1
}
export declare function messageKindFromJSON(object: any): MessageKind;
export declare function messageKindToJSON(object: MessageKind): string;
/** MessageRole is the explicit LLM role stored by the writer. */
export declare enum MessageRole {
    MESSAGE_ROLE_UNSPECIFIED = 0,
    MESSAGE_ROLE_USER = 1,
    MESSAGE_ROLE_ASSISTANT = 2,
    MESSAGE_ROLE_SYSTEM = 3,
    MESSAGE_ROLE_TOOL = 4,
    UNRECOGNIZED = -1
}
export declare function messageRoleFromJSON(object: any): MessageRole;
export declare function messageRoleToJSON(object: MessageRole): string;
/**
 * ToolCallApprovalStatus tracks the human-in-the-loop approval lifecycle of a
 * consequential TOOL_CALL. UNSPECIFIED is treated as NOT_REQUIRED.
 */
export declare enum ToolCallApprovalStatus {
    /** TOOL_CALL_APPROVAL_STATUS_UNSPECIFIED - treated as NOT_REQUIRED */
    TOOL_CALL_APPROVAL_STATUS_UNSPECIFIED = 0,
    TOOL_CALL_APPROVAL_STATUS_NOT_REQUIRED = 1,
    TOOL_CALL_APPROVAL_STATUS_PENDING = 2,
    TOOL_CALL_APPROVAL_STATUS_APPROVED = 3,
    TOOL_CALL_APPROVAL_STATUS_DENIED = 4,
    /** TOOL_CALL_APPROVAL_STATUS_EXPIRED - timed out waiting; treated as denied */
    TOOL_CALL_APPROVAL_STATUS_EXPIRED = 5,
    UNRECOGNIZED = -1
}
export declare function toolCallApprovalStatusFromJSON(object: any): ToolCallApprovalStatus;
export declare function toolCallApprovalStatusToJSON(object: ToolCallApprovalStatus): string;
/**
 * ToolCallExecutionState is the durable execution state machine for an
 * approval-gated / claimable TOOL_CALL row (see Decision 6). The approved
 * TOOL_CALL row itself is the durable work queue, so these states drive
 * worker claim/lease/retry behavior, not just observability.
 */
export declare enum ToolCallExecutionState {
    TOOL_CALL_EXECUTION_STATE_UNSPECIFIED = 0,
    /** TOOL_CALL_EXECUTION_STATE_WAITING_FOR_APPROVAL - approval_status=PENDING */
    TOOL_CALL_EXECUTION_STATE_WAITING_FOR_APPROVAL = 1,
    /** TOOL_CALL_EXECUTION_STATE_PENDING_EXECUTION - approved/not-required and ready to claim */
    TOOL_CALL_EXECUTION_STATE_PENDING_EXECUTION = 2,
    /** TOOL_CALL_EXECUTION_STATE_EXECUTING - claimed by a worker/dispatcher lease */
    TOOL_CALL_EXECUTION_STATE_EXECUTING = 3,
    /** TOOL_CALL_EXECUTION_STATE_EXECUTED - paired TOOL_RESULT persisted */
    TOOL_CALL_EXECUTION_STATE_EXECUTED = 4,
    /** TOOL_CALL_EXECUTION_STATE_EXECUTION_FAILED - terminal/manual intervention after retry policy */
    TOOL_CALL_EXECUTION_STATE_EXECUTION_FAILED = 5,
    UNRECOGNIZED = -1
}
export declare function toolCallExecutionStateFromJSON(object: any): ToolCallExecutionState;
export declare function toolCallExecutionStateToJSON(object: ToolCallExecutionState): string;
/**
 * ChatAgentRunStatus is the run-level lifecycle state for one logical agent
 * turn/resume chain (see Decision 1 / Decision 6). WAITING_FOR_APPROVAL is
 * never terminal; COMPLETED/FAILED/CANCELLED/MODEL_STEP_LIMIT_EXCEEDED set completed_at.
 */
export declare enum ChatAgentRunStatus {
    CHAT_AGENT_RUN_STATUS_UNSPECIFIED = 0,
    CHAT_AGENT_RUN_STATUS_RUNNING = 1,
    CHAT_AGENT_RUN_STATUS_WAITING_FOR_APPROVAL = 2,
    CHAT_AGENT_RUN_STATUS_COMPLETED = 3,
    CHAT_AGENT_RUN_STATUS_FAILED = 4,
    CHAT_AGENT_RUN_STATUS_CANCELLED = 5,
    CHAT_AGENT_RUN_STATUS_RETRYABLE = 6,
    CHAT_AGENT_RUN_STATUS_MODEL_STEP_LIMIT_EXCEEDED = 7,
    UNRECOGNIZED = -1
}
export declare function chatAgentRunStatusFromJSON(object: any): ChatAgentRunStatus;
export declare function chatAgentRunStatusToJSON(object: ChatAgentRunStatus): string;
/**
 * ChatAgentRunStatusReason qualifies a run status with the structured cause go-common could
 * establish. It accompanies terminal statuses and RETRYABLE, and is also used as the
 * drive-retry reason while a RUNNING run waits out a backoff. UNSPECIFIED means no cause was
 * established: COMPLETED + UNSPECIFIED is an ordinary completion, and any other status with
 * UNSPECIFIED must be presented as "execution stopped" without inventing a cause.
 */
export declare enum ChatAgentRunStatusReason {
    CHAT_AGENT_RUN_STATUS_REASON_UNSPECIFIED = 0,
    /** CHAT_AGENT_RUN_STATUS_REASON_APPROVAL_NOT_GRANTED - a required approval was denied or expired */
    CHAT_AGENT_RUN_STATUS_REASON_APPROVAL_NOT_GRANTED = 1,
    /** CHAT_AGENT_RUN_STATUS_REASON_CANCELLED_BY_APPLICATION - application control-plane cancel */
    CHAT_AGENT_RUN_STATUS_REASON_CANCELLED_BY_APPLICATION = 2,
    /** CHAT_AGENT_RUN_STATUS_REASON_PARENT_WORKFLOW_TERMINATED - owning workflow ended/retired the run */
    CHAT_AGENT_RUN_STATUS_REASON_PARENT_WORKFLOW_TERMINATED = 3,
    CHAT_AGENT_RUN_STATUS_REASON_BUDGET_ACTIVE_DURATION = 4,
    CHAT_AGENT_RUN_STATUS_REASON_BUDGET_GENERATIONS = 5,
    CHAT_AGENT_RUN_STATUS_REASON_BUDGET_TOOL_CALLS = 6,
    CHAT_AGENT_RUN_STATUS_REASON_MODEL_STEP_LIMIT = 7,
    CHAT_AGENT_RUN_STATUS_REASON_TOOL_EXECUTION_FAILED = 8,
    CHAT_AGENT_RUN_STATUS_REASON_CONTEXT_LIMIT = 9,
    CHAT_AGENT_RUN_STATUS_REASON_COMPACTION_FAILED = 10,
    /** CHAT_AGENT_RUN_STATUS_REASON_PROVIDER_REJECTED - non-retryable provider/model error */
    CHAT_AGENT_RUN_STATUS_REASON_PROVIDER_REJECTED = 11,
    CHAT_AGENT_RUN_STATUS_REASON_PROVIDER_TIMEOUT = 12,
    /** CHAT_AGENT_RUN_STATUS_REASON_PROVIDER_UNAVAILABLE - retryable provider failure (5xx, rate limit, network) */
    CHAT_AGENT_RUN_STATUS_REASON_PROVIDER_UNAVAILABLE = 13,
    /** CHAT_AGENT_RUN_STATUS_REASON_INCOMPLETE_STEP - crash left an unsealed model step */
    CHAT_AGENT_RUN_STATUS_REASON_INCOMPLETE_STEP = 14,
    CHAT_AGENT_RUN_STATUS_REASON_INTERNAL = 15,
    /** CHAT_AGENT_RUN_STATUS_REASON_STOPPED_BY_USER - a person stopped the run from the chat */
    CHAT_AGENT_RUN_STATUS_REASON_STOPPED_BY_USER = 16,
    /** CHAT_AGENT_RUN_STATUS_REASON_INFERENCE_BLOCKED - RETRYABLE: routing policy blocked the session's pinned model; the session's inference_blocked_reason says why */
    CHAT_AGENT_RUN_STATUS_REASON_INFERENCE_BLOCKED = 17,
    UNRECOGNIZED = -1
}
export declare function chatAgentRunStatusReasonFromJSON(object: any): ChatAgentRunStatusReason;
export declare function chatAgentRunStatusReasonToJSON(object: ChatAgentRunStatusReason): string;
/**
 * ChatAgentInputMode decides what happens to human input sent to an agent session while one of its
 * runs is active (RUNNING, WAITING_FOR_APPROVAL or RETRYABLE) or the session is suspended. Input
 * sent to an idle session starts a run in every mode. UNSPECIFIED is never stored: an agent
 * default of UNSPECIFIED resolves to IMMEDIATE.
 */
export declare enum ChatAgentInputMode {
    CHAT_AGENT_INPUT_MODE_UNSPECIFIED = 0,
    /** CHAT_AGENT_INPUT_MODE_IMMEDIATE - admitted into the active run at its next step */
    CHAT_AGENT_INPUT_MODE_IMMEDIATE = 1,
    /** CHAT_AGENT_INPUT_MODE_QUEUE - waits for the run to end, then all waiting input starts one run */
    CHAT_AGENT_INPUT_MODE_QUEUE = 2,
    /** CHAT_AGENT_INPUT_MODE_BLOCKED - rejected while a run is active or the session is suspended */
    CHAT_AGENT_INPUT_MODE_BLOCKED = 3,
    UNRECOGNIZED = -1
}
export declare function chatAgentInputModeFromJSON(object: any): ChatAgentInputMode;
export declare function chatAgentInputModeToJSON(object: ChatAgentInputMode): string;
/**
 * DelegationWakeState is the durable outcome of a delegated child run's parent wake, stored on the
 * run. Values are database data; do not renumber them.
 */
export declare enum DelegationWakeState {
    /** DELEGATION_WAKE_STATE_UNSPECIFIED - no wake settled: not a delegated child run, still active, or skipped by a guard */
    DELEGATION_WAKE_STATE_UNSPECIFIED = 0,
    /** DELEGATION_WAKE_STATE_RUN_CREATED - the ending minted a parent run */
    DELEGATION_WAKE_STATE_RUN_CREATED = 1,
    /** DELEGATION_WAKE_STATE_COALESCED - the parent had an active run, so the wake was recorded on its pending fields */
    DELEGATION_WAKE_STATE_COALESCED = 2,
    /** DELEGATION_WAKE_STATE_SUPERSEDED_BY_FOLLOW_UP - the child still owed answers to steering, so a child follow-up run reports instead */
    DELEGATION_WAKE_STATE_SUPERSEDED_BY_FOLLOW_UP = 3,
    /** DELEGATION_WAKE_STATE_DEFERRED_TO_GROUP - WITH_SIBLINGS and another live group member was nonterminal; the group's last ending wakes */
    DELEGATION_WAKE_STATE_DEFERRED_TO_GROUP = 4,
    UNRECOGNIZED = -1
}
export declare function delegationWakeStateFromJSON(object: any): DelegationWakeState;
export declare function delegationWakeStateToJSON(object: DelegationWakeState): string;
/**
 * DelegationCreation is who may create the delegated children of a delegating agent type. It is
 * registration configuration; UNSPECIFIED is rejected.
 */
export declare enum DelegationCreation {
    DELEGATION_CREATION_UNSPECIFIED = 0,
    /** DELEGATION_CREATION_APP_ONLY - only the application, through the Go API */
    DELEGATION_CREATION_APP_ONLY = 1,
    /** DELEGATION_CREATION_AGENT_ONLY - only the parent agent, through spawn_subagent */
    DELEGATION_CREATION_AGENT_ONLY = 2,
    /** DELEGATION_CREATION_APP_AND_AGENT - both */
    DELEGATION_CREATION_APP_AND_AGENT = 3,
    UNRECOGNIZED = -1
}
export declare function delegationCreationFromJSON(object: any): DelegationCreation;
export declare function delegationCreationToJSON(object: DelegationCreation): string;
/**
 * DelegationCreationOrigin records which path created an agent session: a delegated child's
 * creator, or a fork clone. UNSPECIFIED marks an ordinary session, or one created before the origin
 * was recorded.
 */
export declare enum DelegationCreationOrigin {
    DELEGATION_CREATION_ORIGIN_UNSPECIFIED = 0,
    /** DELEGATION_CREATION_ORIGIN_APP - the application created it */
    DELEGATION_CREATION_ORIGIN_APP = 1,
    /** DELEGATION_CREATION_ORIGIN_AGENT - the parent agent spawned it */
    DELEGATION_CREATION_ORIGIN_AGENT = 2,
    /** DELEGATION_CREATION_ORIGIN_FORK - a channel fork cloned it from the source channel's session */
    DELEGATION_CREATION_ORIGIN_FORK = 3,
    UNRECOGNIZED = -1
}
export declare function delegationCreationOriginFromJSON(object: any): DelegationCreationOrigin;
export declare function delegationCreationOriginToJSON(object: DelegationCreationOrigin): string;
/** ChatForkWhoMayFork is who may fork a channel. Values are database data; do not renumber them. */
export declare enum ChatForkWhoMayFork {
    /** CHAT_FORK_WHO_MAY_FORK_UNSPECIFIED - forking is disabled */
    CHAT_FORK_WHO_MAY_FORK_UNSPECIFIED = 0,
    /** CHAT_FORK_WHO_MAY_FORK_ANY_READER - anyone who may read the channel: participants, org readers, site admins; not readers admitted only by public read */
    CHAT_FORK_WHO_MAY_FORK_ANY_READER = 1,
    /** CHAT_FORK_WHO_MAY_FORK_PARTICIPANTS - participants who may write to the channel */
    CHAT_FORK_WHO_MAY_FORK_PARTICIPANTS = 2,
    /** CHAT_FORK_WHO_MAY_FORK_ADMINS - channel admins and owners */
    CHAT_FORK_WHO_MAY_FORK_ADMINS = 3,
    UNRECOGNIZED = -1
}
export declare function chatForkWhoMayForkFromJSON(object: any): ChatForkWhoMayFork;
export declare function chatForkWhoMayForkToJSON(object: ChatForkWhoMayFork): string;
/**
 * ChatForkMemberPool is whom a forker may add to the fork. The forker is always its OWNER. Values
 * are database data; do not renumber them.
 */
export declare enum ChatForkMemberPool {
    /** CHAT_FORK_MEMBER_POOL_UNSPECIFIED - the forker only */
    CHAT_FORK_MEMBER_POOL_UNSPECIFIED = 0,
    /** CHAT_FORK_MEMBER_POOL_SOURCE_PARTICIPANTS - current participants of the source channel */
    CHAT_FORK_MEMBER_POOL_SOURCE_PARTICIPANTS = 1,
    /** CHAT_FORK_MEMBER_POOL_ANYONE - anyone CreateChannel would accept */
    CHAT_FORK_MEMBER_POOL_ANYONE = 2,
    UNRECOGNIZED = -1
}
export declare function chatForkMemberPoolFromJSON(object: any): ChatForkMemberPool;
export declare function chatForkMemberPoolToJSON(object: ChatForkMemberPool): string;
/**
 * ChatForkCarryOver is whether a fork keeps a group of source channel settings. Values are
 * database data; do not renumber them.
 */
export declare enum ChatForkCarryOver {
    /** CHAT_FORK_CARRY_OVER_UNSPECIFIED - always dropped */
    CHAT_FORK_CARRY_OVER_UNSPECIFIED = 0,
    /** CHAT_FORK_CARRY_OVER_ALWAYS_KEEP - always kept */
    CHAT_FORK_CARRY_OVER_ALWAYS_KEEP = 1,
    /** CHAT_FORK_CARRY_OVER_FORKER_CHOOSES - kept when the fork request asks for it */
    CHAT_FORK_CARRY_OVER_FORKER_CHOOSES = 2,
    UNRECOGNIZED = -1
}
export declare function chatForkCarryOverFromJSON(object: any): ChatForkCarryOver;
export declare function chatForkCarryOverToJSON(object: ChatForkCarryOver): string;
/**
 * WakePolicy decides when a delegated child's ending or report wakes its parent. Agent spawns
 * leave it UNSPECIFIED, which means IMMEDIATE.
 */
export declare enum WakePolicy {
    WAKE_POLICY_UNSPECIFIED = 0,
    /** WAKE_POLICY_IMMEDIATE - every ending or report wakes the parent */
    WAKE_POLICY_IMMEDIATE = 1,
    /** WAKE_POLICY_WITH_SIBLINGS - the parent wakes once no other live member of the wake group is nonterminal */
    WAKE_POLICY_WITH_SIBLINGS = 2,
    /** WAKE_POLICY_NEVER - the parent is never woken; the application resumes it */
    WAKE_POLICY_NEVER = 3,
    UNRECOGNIZED = -1
}
export declare function wakePolicyFromJSON(object: any): WakePolicy;
export declare function wakePolicyToJSON(object: WakePolicy): string;
/** ChatAgentMessageReceiptKind is what a delegation message receipt records. */
export declare enum ChatAgentMessageReceiptKind {
    CHAT_AGENT_MESSAGE_RECEIPT_KIND_UNSPECIFIED = 0,
    /** CHAT_AGENT_MESSAGE_RECEIPT_KIND_CHILD_MESSAGE - a parent's message to a delegated child */
    CHAT_AGENT_MESSAGE_RECEIPT_KIND_CHILD_MESSAGE = 1,
    /** CHAT_AGENT_MESSAGE_RECEIPT_KIND_PARENT_RESUME - an application's resume of the parent itself */
    CHAT_AGENT_MESSAGE_RECEIPT_KIND_PARENT_RESUME = 2,
    UNRECOGNIZED = -1
}
export declare function chatAgentMessageReceiptKindFromJSON(object: any): ChatAgentMessageReceiptKind;
export declare function chatAgentMessageReceiptKindToJSON(object: ChatAgentMessageReceiptKind): string;
/** GraphOutcome is how one drive of an owner-driven delegation graph ended. */
export declare enum GraphOutcome {
    GRAPH_OUTCOME_UNSPECIFIED = 0,
    /** GRAPH_OUTCOME_COMPLETED - the root's result is ready */
    GRAPH_OUTCOME_COMPLETED = 1,
    /** GRAPH_OUTCOME_STALLED - nothing is drivable now or later and no result exists */
    GRAPH_OUTCOME_STALLED = 2,
    /** GRAPH_OUTCOME_OUT_OF_BUDGET - a graph budget pool limit is used up */
    GRAPH_OUTCOME_OUT_OF_BUDGET = 3,
    /** GRAPH_OUTCOME_PARKED - nothing is drivable until an external event arrives */
    GRAPH_OUTCOME_PARKED = 4,
    /** GRAPH_OUTCOME_CLAIM_LOST - the caller lost its claim; drives were suspended */
    GRAPH_OUTCOME_CLAIM_LOST = 5,
    UNRECOGNIZED = -1
}
export declare function graphOutcomeFromJSON(object: any): GraphOutcome;
export declare function graphOutcomeToJSON(object: GraphOutcome): string;
/** GraphParkReason is an external event a parked delegation graph waits for. */
export declare enum GraphParkReason {
    GRAPH_PARK_REASON_UNSPECIFIED = 0,
    /** GRAPH_PARK_REASON_APPROVAL - only approval-waiting runs remain */
    GRAPH_PARK_REASON_APPROVAL = 1,
    /** GRAPH_PARK_REASON_INFERENCE_BLOCKED - a session is inference-blocked with deferred wakes or undrivable runs */
    GRAPH_PARK_REASON_INFERENCE_BLOCKED = 2,
    UNRECOGNIZED = -1
}
export declare function graphParkReasonFromJSON(object: any): GraphParkReason;
export declare function graphParkReasonToJSON(object: GraphParkReason): string;
/** GraphEventKind is the kind of event that advanced a delegation graph root's resume revision. */
export declare enum GraphEventKind {
    GRAPH_EVENT_KIND_UNSPECIFIED = 0,
    /** GRAPH_EVENT_KIND_APPROVAL - an approval was resolved or expired */
    GRAPH_EVENT_KIND_APPROVAL = 1,
    /** GRAPH_EVENT_KIND_INFERENCE_RETARGET - a retarget cleared an inference block of a session with work */
    GRAPH_EVENT_KIND_INFERENCE_RETARGET = 2,
    /** GRAPH_EVENT_KIND_PARENT_RESUME - the application resumed the parent (ResumeParent) */
    GRAPH_EVENT_KIND_PARENT_RESUME = 3,
    /** GRAPH_EVENT_KIND_WAKE_GROUP_RELEASED - archiving a wake group's last working member woke the root */
    GRAPH_EVENT_KIND_WAKE_GROUP_RELEASED = 4,
    UNRECOGNIZED = -1
}
export declare function graphEventKindFromJSON(object: any): GraphEventKind;
export declare function graphEventKindToJSON(object: GraphEventKind): string;
/** GraphBudgetReason is the graph budget pool limit that was used up. */
export declare enum GraphBudgetReason {
    GRAPH_BUDGET_REASON_UNSPECIFIED = 0,
    GRAPH_BUDGET_REASON_GENERATIONS = 1,
    GRAPH_BUDGET_REASON_TOOL_CALLS = 2,
    GRAPH_BUDGET_REASON_ACTIVE_DURATION = 3,
    UNRECOGNIZED = -1
}
export declare function graphBudgetReasonFromJSON(object: any): GraphBudgetReason;
export declare function graphBudgetReasonToJSON(object: GraphBudgetReason): string;
/**
 * ChatAgentSessionActivity is what an agent session is doing as far as its composer is concerned.
 * It is derived at read time from the session and its newest run and never persisted.
 */
export declare enum ChatAgentSessionActivity {
    CHAT_AGENT_SESSION_ACTIVITY_UNSPECIFIED = 0,
    /** CHAT_AGENT_SESSION_ACTIVITY_IDLE - no active run; a send starts one */
    CHAT_AGENT_SESSION_ACTIVITY_IDLE = 1,
    CHAT_AGENT_SESSION_ACTIVITY_RUNNING = 2,
    CHAT_AGENT_SESSION_ACTIVITY_WAITING_FOR_APPROVAL = 3,
    /** CHAT_AGENT_SESSION_ACTIVITY_RETRYING - the active run is RETRYABLE */
    CHAT_AGENT_SESSION_ACTIVITY_RETRYING = 4,
    /** CHAT_AGENT_SESSION_ACTIVITY_SUSPENDED - stopped by a person; nothing starts until Resume */
    CHAT_AGENT_SESSION_ACTIVITY_SUSPENDED = 5,
    UNRECOGNIZED = -1
}
export declare function chatAgentSessionActivityFromJSON(object: any): ChatAgentSessionActivity;
export declare function chatAgentSessionActivityToJSON(object: ChatAgentSessionActivity): string;
/**
 * ChatAgentInputReceiptState tells the sender what happened to a send that reached an agent session.
 * It is distinct from the message's transport and read statuses.
 */
export declare enum ChatAgentInputReceiptState {
    CHAT_AGENT_INPUT_RECEIPT_STATE_UNSPECIFIED = 0,
    /** CHAT_AGENT_INPUT_RECEIPT_STATE_RUN_STARTED - the message started a run on its own */
    CHAT_AGENT_INPUT_RECEIPT_STATE_RUN_STARTED = 1,
    /** CHAT_AGENT_INPUT_RECEIPT_STATE_PENDING - queued for the active run (IMMEDIATE) or its end (QUEUE) */
    CHAT_AGENT_INPUT_RECEIPT_STATE_PENDING = 2,
    /** CHAT_AGENT_INPUT_RECEIPT_STATE_HELD - queued while the session is suspended */
    CHAT_AGENT_INPUT_RECEIPT_STATE_HELD = 3,
    /** CHAT_AGENT_INPUT_RECEIPT_STATE_ADMITTED - the send's queued input was delivered into a run as the message */
    CHAT_AGENT_INPUT_RECEIPT_STATE_ADMITTED = 4,
    UNRECOGNIZED = -1
}
export declare function chatAgentInputReceiptStateFromJSON(object: any): ChatAgentInputReceiptState;
export declare function chatAgentInputReceiptStateToJSON(object: ChatAgentInputReceiptState): string;
/**
 * AgentRunActivity is what a non-terminal run is observably doing. It is never persisted:
 * the status read derives the durable subset (EXECUTING_TOOL, WAITING_TO_RETRY,
 * WAITING_FOR_APPROVAL) and the runtime reports the rest through ephemeral
 * CHAT_EVENT_TYPE_AGENT_RUN_STATE events. UNSPECIFIED means "no finer detail is known";
 * clients show the lifecycle status alone rather than guessing.
 */
export declare enum AgentRunActivity {
    AGENT_RUN_ACTIVITY_UNSPECIFIED = 0,
    AGENT_RUN_ACTIVITY_WAITING_FOR_MODEL = 1,
    AGENT_RUN_ACTIVITY_EXECUTING_TOOL = 2,
    AGENT_RUN_ACTIVITY_WAITING_TO_RETRY = 3,
    AGENT_RUN_ACTIVITY_WAITING_FOR_APPROVAL = 4,
    UNRECOGNIZED = -1
}
export declare function agentRunActivityFromJSON(object: any): AgentRunActivity;
export declare function agentRunActivityToJSON(object: AgentRunActivity): string;
/**
 * InferenceCallPurpose records why a single model/provider invocation happened
 * (see Decision 2.5). Used for compaction/agent-only accounting views.
 */
export declare enum InferenceCallPurpose {
    INFERENCE_CALL_PURPOSE_UNSPECIFIED = 0,
    /** INFERENCE_CALL_PURPOSE_ASSISTANT_TURN - model call that directly produced an assistant-visible turn */
    INFERENCE_CALL_PURPOSE_ASSISTANT_TURN = 1,
    /** INFERENCE_CALL_PURPOSE_TOOL_LOOP - intermediate model call that produced tool requests or resumed after tool results */
    INFERENCE_CALL_PURPOSE_TOOL_LOOP = 2,
    /** INFERENCE_CALL_PURPOSE_COMPACTION - model call that produced a COMPACTION_SUMMARY */
    INFERENCE_CALL_PURPOSE_COMPACTION = 3,
    /** INFERENCE_CALL_PURPOSE_RETRY - retry after a transient/provider failure */
    INFERENCE_CALL_PURPOSE_RETRY = 4,
    /** INFERENCE_CALL_PURPOSE_FALLBACK - fallback model/provider call after primary failure */
    INFERENCE_CALL_PURPOSE_FALLBACK = 5,
    /** INFERENCE_CALL_PURPOSE_MANUAL - app-supplied accounting record that does not fit the above */
    INFERENCE_CALL_PURPOSE_MANUAL = 6,
    UNRECOGNIZED = -1
}
export declare function inferenceCallPurposeFromJSON(object: any): InferenceCallPurpose;
export declare function inferenceCallPurposeToJSON(object: InferenceCallPurpose): string;
/**
 * MessageModelPayloadType discriminates which structured payload is serialized
 * into Message.model_payload (mirrors MessageEmbed.embed_type for embed_data).
 */
export declare enum MessageModelPayloadType {
    MESSAGE_MODEL_PAYLOAD_TYPE_UNSPECIFIED = 0,
    MESSAGE_MODEL_PAYLOAD_TYPE_TOOL_CALL = 1,
    MESSAGE_MODEL_PAYLOAD_TYPE_TOOL_RESULT = 2,
    MESSAGE_MODEL_PAYLOAD_TYPE_COMPACTION = 3,
    MESSAGE_MODEL_PAYLOAD_TYPE_PROVIDER_STATE = 4,
    MESSAGE_MODEL_PAYLOAD_TYPE_CONTEXT_EVENT = 5,
    UNRECOGNIZED = -1
}
export declare function messageModelPayloadTypeFromJSON(object: any): MessageModelPayloadType;
export declare function messageModelPayloadTypeToJSON(object: MessageModelPayloadType): string;
/**
 * ChatEventType identifies realtime chat events. Durable transitions publish after
 * commit; typing, streaming activity, and compaction indicators are ephemeral.
 */
export declare enum ChatEventType {
    CHAT_EVENT_TYPE_UNSPECIFIED = 0,
    /** CHAT_EVENT_TYPE_CHANNEL_CREATED - Channels */
    CHAT_EVENT_TYPE_CHANNEL_CREATED = 1,
    CHAT_EVENT_TYPE_CHANNEL_UPDATED = 2,
    CHAT_EVENT_TYPE_CHANNEL_DELETED = 3,
    /** CHAT_EVENT_TYPE_PARTICIPANT_PREFERENCES_UPDATED - Personal preferences changed; participant payload, sent only to its owner. */
    CHAT_EVENT_TYPE_PARTICIPANT_PREFERENCES_UPDATED = 4,
    /** CHAT_EVENT_TYPE_MESSAGE_SENT - Messages */
    CHAT_EVENT_TYPE_MESSAGE_SENT = 10,
    CHAT_EVENT_TYPE_MESSAGE_EDITED = 11,
    CHAT_EVENT_TYPE_MESSAGE_DELETED = 12,
    CHAT_EVENT_TYPE_MESSAGE_ATTACHMENTS_READY = 13,
    CHAT_EVENT_TYPE_MESSAGE_STREAM_STARTED = 14,
    CHAT_EVENT_TYPE_MESSAGE_STREAM_DELTA = 15,
    CHAT_EVENT_TYPE_MESSAGE_STREAM_FINISHED = 16,
    CHAT_EVENT_TYPE_MESSAGE_STREAM_FAILED = 17,
    /**
     * CHAT_EVENT_TYPE_INFERENCE_USAGE_UPDATED - An inference call was recorded: cumulative channel/session totals, plus the
     * linked message's summary when there is one.
     */
    CHAT_EVENT_TYPE_INFERENCE_USAGE_UPDATED = 18,
    /** CHAT_EVENT_TYPE_REACTION_ADDED - Reactions */
    CHAT_EVENT_TYPE_REACTION_ADDED = 20,
    CHAT_EVENT_TYPE_REACTION_REMOVED = 21,
    /** CHAT_EVENT_TYPE_TYPING - Ephemeral indicators */
    CHAT_EVENT_TYPE_TYPING = 30,
    /**
     * CHAT_EVENT_TYPE_TOOL_CALL_RESOLUTION - Tool approval (server -> client). Fanned out when a TOOL_CALL transitions
     * PENDING -> APPROVED/DENIED/EXPIRED so all sessions update the approval card
     * live. This is the realtime approval-state event, not a tool-execution request.
     */
    CHAT_EVENT_TYPE_TOOL_CALL_RESOLUTION = 40,
    /**
     * CHAT_EVENT_TYPE_CONTEXT_COMPACTION - Ephemeral: an agent run started or stopped summarizing its context. Never persisted and
     * never replayed; a client that misses the stop clears the indicator on its own timeout.
     */
    CHAT_EVENT_TYPE_CONTEXT_COMPACTION = 50,
    /**
     * CHAT_EVENT_TYPE_AGENT_RUN_STATE - An agent run changed lifecycle status (published after commit) or observable activity
     * (ephemeral, never persisted or replayed). A hint only: the agent-run status read is
     * authoritative, and a client expires live activity on its own timeout.
     */
    CHAT_EVENT_TYPE_AGENT_RUN_STATE = 51,
    /**
     * CHAT_EVENT_TYPE_AGENT_SESSION_INTERACTION - An agent session's interaction state changed after commit: input was enqueued, admitted or
     * withdrawn, a session run ended, the session was stopped, resumed or archived, or its
     * interaction policy changed. An invalidation only: the payload names the session, and the
     * client re-reads its interaction, which depends on the viewer.
     */
    CHAT_EVENT_TYPE_AGENT_SESSION_INTERACTION = 52,
    UNRECOGNIZED = -1
}
export declare function chatEventTypeFromJSON(object: any): ChatEventType;
export declare function chatEventTypeToJSON(object: ChatEventType): string;
/**
 * ChatChannelPublicRead is how far beyond its participants a channel can be read. Levels are
 * ordered, so a check reads `level >= SIGNED_IN`. Public readers are read-only, never become
 * participants, and never see the channel in ListChannels. A public channel is addressed by its
 * plain ID, so ANYONE channels can be found by enumerating IDs: public means discoverable.
 */
export declare enum ChatChannelPublicRead {
    /** CHAT_CHANNEL_PUBLIC_READ_UNSPECIFIED - off: participants (and org/admin readers) only */
    CHAT_CHANNEL_PUBLIC_READ_UNSPECIFIED = 0,
    /** CHAT_CHANNEL_PUBLIC_READ_SIGNED_IN - any signed-in user with the ID, with realtime */
    CHAT_CHANNEL_PUBLIC_READ_SIGNED_IN = 1,
    /** CHAT_CHANNEL_PUBLIC_READ_ANYONE - also logged-out visitors, over REST only */
    CHAT_CHANNEL_PUBLIC_READ_ANYONE = 2,
    UNRECOGNIZED = -1
}
export declare function chatChannelPublicReadFromJSON(object: any): ChatChannelPublicRead;
export declare function chatChannelPublicReadToJSON(object: ChatChannelPublicRead): string;
/** Personal interruption preference; inbox entries and unread counts remain visible. */
export declare enum ChannelNotificationMode {
    CHANNEL_NOTIFICATION_MODE_UNSPECIFIED = 0,
    CHANNEL_NOTIFICATION_MODE_ALL_MESSAGES = 1,
    CHANNEL_NOTIFICATION_MODE_MENTIONS_ONLY = 2,
    CHANNEL_NOTIFICATION_MODE_MUTED = 3,
    UNRECOGNIZED = -1
}
export declare function channelNotificationModeFromJSON(object: any): ChannelNotificationMode;
export declare function channelNotificationModeToJSON(object: ChannelNotificationMode): string;
export declare enum ContextEventKind {
    CONTEXT_EVENT_KIND_UNSPECIFIED = 0,
    /** CONTEXT_EVENT_KIND_TRUNCATED - History was omitted without a summary (budget_trim, or the truncate failure policy). */
    CONTEXT_EVENT_KIND_TRUNCATED = 1,
    /** CONTEXT_EVENT_KIND_COMPACTION_FAILED - Summarization failed and generation stopped without discarding history. */
    CONTEXT_EVENT_KIND_COMPACTION_FAILED = 2,
    UNRECOGNIZED = -1
}
export declare function contextEventKindFromJSON(object: any): ContextEventKind;
export declare function contextEventKindToJSON(object: ContextEventKind): string;
/**
 * ChatAgentSessionStatus is the lifecycle state of an agent session. A delegated child stays
 * ACTIVE after its run completes so people can keep talking to it in its thread.
 */
export declare enum ChatAgentSessionStatus {
    CHAT_AGENT_SESSION_STATUS_UNSPECIFIED = 0,
    CHAT_AGENT_SESSION_STATUS_ACTIVE = 1,
    CHAT_AGENT_SESSION_STATUS_ARCHIVED = 2,
    UNRECOGNIZED = -1
}
export declare function chatAgentSessionStatusFromJSON(object: any): ChatAgentSessionStatus;
export declare function chatAgentSessionStatusToJSON(object: ChatAgentSessionStatus): string;
export interface Channel {
    /** Ordinary unread notifications only; tool approval notifications remain independent. */
    unreadNotificationsEnabled: boolean;
    id: bigint;
    /** Optional name (for group chats) */
    name: string;
    /** Optional description */
    description: string;
    /** Optional avatar image attachment ID */
    avatarAttachmentId: bigint;
    /** Computed URL for the avatar */
    avatarUrl: string;
    channelType: ChannelType;
    isArchived: boolean;
    createdByUserId: bigint;
    lastMessageAt?: Date | undefined;
    lastMessagePreview: string;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    deletedAt?: Date | undefined;
    /** Per-channel feature flags */
    supportReplies: boolean;
    supportThreads: boolean;
    supportMessageEdits: boolean;
    supportMessageDeletes: boolean;
    supportMessageReactions: boolean;
    allowMultipleReactionsPerUser: boolean;
    supportEmbeds: boolean;
    supportAttachments: boolean;
    allowNativeEmbeds: boolean;
    allowCustomEmbeds: boolean;
    /** Readers see token usage: badges, usage routes and realtime usage events. */
    supportInferenceUsage: boolean;
    /** Optional per-channel context metadata (e.g., tenancy or domain-specific scope). */
    contextId?: bigint | undefined;
    contextDisplayName?: string | undefined;
    contextEntityId?: bigint | undefined;
    /**
     * Who beyond participants may read the channel. Takes effect only while the server's
     * enable_public_chat_read flag is on.
     */
    publicRead: ChatChannelPublicRead;
    /** Fork rules, set at creation and immutable afterwards; a fork copies them from its source. */
    forkRules?: ChannelForkRules | undefined;
    /**
     * Provenance of a fork: the source channel and the message it was forked at. Unset on channels
     * that are not forks. The source may since have been deleted or become unreadable to the viewer.
     */
    forkedFromChannelId?: bigint | undefined;
    forkPointMessageId?: bigint | undefined;
}
/** ChannelForkRules controls forking of a channel. The zero value disables forking. */
export interface ChannelForkRules {
    whoMayFork: ChatForkWhoMayFork;
    memberPool: ChatForkMemberPool;
    /** Whether the fork keeps the source's organization access (organization and minimum read role). */
    orgAccess: ChatForkCarryOver;
    /**
     * Whether the fork keeps the source's context fields (context_id, context_display_name,
     * context_entity_id).
     */
    context: ChatForkCarryOver;
}
export interface ChannelParticipant {
    channelId: bigint;
    userId: bigint;
    role: ChannelRole;
    isPinned: boolean;
    lastReadMessageId: bigint;
    joinedAt?: Date | undefined;
    updatedAt?: Date | undefined;
    /** If set, user has left the channel */
    leftAt?: Date | undefined;
    /** Expanded user data (for responses) */
    user?: PublicUser | undefined;
    notificationMode: ChannelNotificationMode;
}
export interface Message {
    id: bigint;
    channelId: bigint;
    senderId: bigint;
    content: string;
    contentType: MessageContentType;
    /** Thread root ID (0 = main timeline) */
    parentMessageId: bigint;
    isEdited: boolean;
    editedAt?: Date | undefined;
    /** Original content if edited (optional/internal) */
    originalContent: string;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    deletedAt?: Date | undefined;
    /** Expanded sender data */
    sender?: PublicUser | undefined;
    /** Collections */
    embeds: MessageEmbed[];
    attachmentIds: bigint[];
    attachments: UploadedAttachment[];
    reactions: MessageReaction[];
    mentions: MessageMention[];
    /**
     * Reply reference (Discord-style "replying to...") (0 = none).
     * Must refer to a message in the same channel; service layer enforces thread/timeline constraints.
     */
    replyToMessageId: bigint;
    /**
     * Number of thread replies to this message (0 = no replies/no thread).
     * Computed at query time when threads are enabled.
     */
    replyCount: number;
    /** Explicit streaming lifecycle for bot/LLM-authored messages. */
    streamState: MessageStreamState;
    /**
     * Discriminates standard chat from tool calls/results, system events,
     * compaction summaries, and agent notes. Stored values must be specified.
     */
    kind: MessageKind;
    /** Explicit LLM role assigned by the message writer. */
    role: MessageRole;
    /**
     * Visibility flags use `optional` so an explicit false is distinguishable
     * from "unset" (per-kind defaults are applied server-side only when unset).
     */
    excludeFromAiContext?: boolean | undefined;
    /** never shown to regular users (filtered server-side) */
    hiddenFromUsers?: boolean | undefined;
    /**
     * References ChatAgentRun.id — the go-common-owned durable run row for one
     * logical agent turn/run. Groups every transcript row produced by that run
     * (assistant text + TOOL_CALL/TOOL_RESULT rows) without relying on
     * sender+ID adjacency. Optional for messages produced outside an agent run.
     */
    agentRunId?: bigint | undefined;
    /**
     * Reconstruction boundary inside one run: assistant text/tool calls from one
     * model step plus the matching tool results share a step index; the next
     * model response increments it (Decision 1). Indexed with agent_run_id.
     */
    agentStepIndex?: number | undefined;
    /**
     * Denormalized pairing key for TOOL_CALL/TOOL_RESULT rows. Must match the
     * payload's tool_call_id; exists so DB constraints/lookups never deserialize
     * protobuf bytes (Decision 1 / Decision 2). Nullable string (unset on others).
     */
    toolCallId?: string | undefined;
    /**
     * Structured payload serialized as bytes + a type discriminator, mirroring
     * MessageEmbed.embed_data. Holds a MessageModelPayload (tool call/result/compaction).
     */
    modelPayload: Uint8Array;
    payloadType: MessageModelPayloadType;
    /** --- Tool-call approval state (authoritative columns; see Decision 6) --- */
    approvalStatus: ToolCallApprovalStatus;
    /** run's human triggering actor, eligible for approval */
    triggeringUserId: bigint;
    resolvedByUserId: bigint;
    resolvedAt?: Date | undefined;
    resolutionReason: string;
    approvalExpiresAt?: Date | undefined;
    /**
     * --- Tool-call execution state (operational columns; the approved TOOL_CALL
     * row is the durable work queue — see Decision 6). Not model payload. ---
     */
    executionState: ToolCallExecutionState;
    executionAttemptCount: number;
    executionLeaseOwner: string;
    executionLeaseExpiresAt?: Date | undefined;
    executionStartedAt?: Date | undefined;
    executedAt?: Date | undefined;
    /** capped operational error text */
    lastExecutionError: string;
    /**
     * Thread reply that also appears on the channel's main timeline (Slack-style
     * "also send to channel"). One row serves both views, so parent_message_id
     * still names the thread root for navigation. Set only at send time.
     */
    broadcastToChannel: boolean;
    /**
     * Control subtype of an AGENT_NOTE row ("note", "app_resume", ...); empty on other kinds.
     * Clients render subtypes they know (app_resume is an application message) and show any
     * other note as reasoning.
     */
    agentNoteSubtype: string;
}
/** MessageModelPayload is the structured body serialized into Message.model_payload. */
export interface MessageModelPayload {
    toolCall?: ToolCallPayload | undefined;
    toolResult?: ToolResultPayload | undefined;
    compaction?: CompactionPayload | undefined;
    providerState?: ProviderStatePayload | undefined;
    contextEvent?: ContextEventPayload | undefined;
}
/**
 * ContextEventPayload types a context-management SYSTEM_EVENT so clients can localize and style
 * it. The row's content stays a complete English sentence for clients that ignore the payload.
 */
export interface ContextEventPayload {
    kind: ContextEventKind;
    omittedMessageCount: number;
    estimatedBeforeTokens: bigint;
    estimatedAfterTokens: bigint;
}
/**
 * ProviderStatePayload is a reference-only integrity envelope for opaque
 * provider continuation state. The provider bytes live in an internal
 * attachment and are never serialized into the transcript row or public wire
 * payload. One hidden PROVIDER_STATE row belongs to one agent run + model step.
 */
export interface ProviderStatePayload {
    api: InferenceAPI;
    providerModelId: string;
    destinationFingerprint: string;
    providerId: string;
    format: string;
    version: number;
    responseId: string;
    attachmentId: bigint;
    contentSha256: string;
    sizeBytes: bigint;
    visibleProjectionSha256: string;
    toolManifestSha256: string;
}
export interface ToolCallPayload {
    /** non-empty, step-unique internal Genkit Ref; pairs with ToolResultPayload */
    toolCallId: string;
    toolName: string;
    /** JSON-encoded arguments (provider-portable) */
    argumentsJson: string;
    /**
     * Optional display-only renderer hint (server-authoritative, from
     * AgentToolDefinition.RendererKey). Lets the UI resolve a TranscriptRenderer
     * by renderer_key. Empty = none. NOT used for DB constraints, security, or
     * context reconstruction (Decision 0 / Decision 8).
     */
    rendererKey: string;
    /**
     * Opaque Vertex/Gemini thought signature that must be echoed with the
     * function call on continuation. Stored for model replay only.
     */
    thoughtSignature: Uint8Array;
    /**
     * Exact provider FunctionCall.id received with the model response. Presence
     * is significant; tool_call_id remains the non-empty internal pairing key.
     */
    providerCallId?: string | undefined;
    /**
     * NOTE: approval state is NOT stored here — it lives in authoritative,
     * queryable columns on the message row (see Message.approval_status etc).
     */
    rejectedArguments?: RejectedToolArguments | undefined;
}
/**
 * A completed, identified call rejected before any application execution.
 * raw_arguments is opaque text: duplicate keys and invalid JSON must survive audit/replay.
 */
export interface RejectedToolArguments {
    toolName: string;
    providerToolName: string;
    callId: string;
    itemId: string;
    outputIndex: number;
    rawArguments: string;
    diagnostic: string;
}
export interface ToolResultPayload {
    /** must equal Message.tool_call_id and an existing TOOL_CALL in the same run */
    toolCallId: string;
    /** JSON-encoded result (genkit ToolResponse.Output) */
    contentJson: string;
    isError: boolean;
    /**
     * Genkit ToolResponse.Content is []*Part and may include text, JSON/data, or
     * media (e.g. a tool returning an image). content_json remains the simple
     * default result path; content_parts preserves multipart results for
     * provider round-trips. Empty for plain text/JSON results (Decision 2).
     */
    contentParts: MessagePart[];
    /**
     * Optional display-only renderer hint (server-authoritative, from
     * AgentToolDefinition.RendererKey); same semantics as ToolCallPayload. Empty
     * = none. NOT used for DB constraints, security, or reconstruction.
     */
    rendererKey: string;
}
/**
 * MessagePart mirrors the genkit Part model for multipart tool results so the
 * transcript survives provider round-trips (Decision 2). Validators size-cap
 * inline_data and DataPart.data; large media should prefer url/attachment_id.
 */
export interface MessagePart {
    text?: TextPart | undefined;
    media?: MediaPart | undefined;
    data?: DataPart | undefined;
}
export interface TextPart {
    text: string;
}
export interface MediaPart {
    /** e.g. image/png, audio/mpeg, video/mp4 */
    contentType: string;
    /** optional display/file name */
    name: string;
    /** preferred for persisted media/attachments */
    url?: string | undefined;
    /** size-capped; only for small payloads */
    inlineData?: Uint8Array | undefined;
    /** existing uploaded attachment reference when available */
    attachmentId?: string | undefined;
    /** provider image detail hint (e.g. auto, low, high, original) */
    detail: string;
    /**
     * Persisted byte size for attachment_id sources. Required when attachment_id is set so
     * context reconstruction can drop old atomic tool groups before reading/presigning blobs.
     * Zero for url and inline_data sources.
     */
    sizeBytes: bigint;
}
export interface DataPart {
    /** usually application/json */
    contentType: string;
    /** serialized payload, size-capped */
    data: Uint8Array;
}
export interface CompactionPayload {
    /** watermark: summary covers messages with id <= this */
    coversThroughMessageId: bigint;
    summarizedMessageCount: number;
    estimatedBeforeTokens: bigint;
    estimatedAfterTokens: bigint;
    triggerReason: string;
    /** A prior main-model call's measured input, not a measurement of the new checkpoint. */
    observedInputTokens: bigint;
    observedInferenceCallId: string;
    /** Protected context copied verbatim when its original row falls behind the watermark. */
    retainedUserMessageId: bigint;
    retainedUserContent: string;
    workflowStateMessageId: bigint;
    workflowState: string;
}
export interface MessageEmbed {
    id: bigint;
    messageId: bigint;
    /** 1-999 (Native), 1000+ (Custom/App-specific); 0 is invalid */
    embedType: number;
    /** Protobuf serialized data specific to embed_type */
    embedData: Uint8Array;
    fallbackText: string;
    position: number;
    createdAt?: Date | undefined;
}
export interface MessageReaction {
    messageId: bigint;
    userId: bigint;
    emoji: string;
    createdAt?: Date | undefined;
    /** Expanded user data */
    user?: PublicUser | undefined;
}
export interface MessageMention {
    messageId: bigint;
    userId: bigint;
    createdAt?: Date | undefined;
    /** Expanded user data */
    user?: PublicUser | undefined;
}
export interface ChatMessageEditHistoryEntry {
    id: bigint;
    messageId: bigint;
    versionNumber: number;
    editedByUserId: bigint;
    versionStartedAt?: Date | undefined;
    versionEndedAt?: Date | undefined;
    content: string;
    contentType: MessageContentType;
    embeds: MessageEmbed[];
    attachmentIds: bigint[];
    mentionUserIds: bigint[];
    createdAt?: Date | undefined;
    /** Expanded editor data */
    editedByUser?: PublicUser | undefined;
}
export interface ImageEmbedData {
    attachmentId: bigint;
    url: string;
    altText: string;
    width?: number | undefined;
    height?: number | undefined;
    thumbnailUrl?: string | undefined;
    /**
     * Storage visibility of attachment_id: whether url/thumbnail_url are stable
     * and cacheable or presigned and expiring. Unset selects private visibility.
     */
    visibility?: AttachmentVisibility | undefined;
}
/**
 * ChatAgentRun is the go-common-owned durable run row for one logical agent
 * turn/resume chain. Its id is the value stored as Message.agent_run_id and
 * ChatInferenceCall.agent_run_id (Decision 1). agent_session_id /
 * agent_session_config_version pin the per-chat config snapshot used by the run.
 *
 * Full ChatAgentSession/config snapshots stay in persistence/service models;
 * AgentSessionSummary and AgentSessionInteraction expose narrower public projections.
 */
export interface ChatAgentRun {
    requestedInferenceModelId?: bigint | undefined;
    requestedInferenceApi?: InferenceAPI | undefined;
    executionInferenceModelId?: bigint | undefined;
    executionInferenceApi?: InferenceAPI | undefined;
    executionProviderId?: string | undefined;
    executionProviderModelId?: string | undefined;
    id: bigint;
    channelId: bigint;
    /** thread scope; 0 = main timeline */
    parentMessageId: bigint;
    /** set for first-class agent sessions */
    agentSessionId?: bigint | undefined;
    /** captured at run start; required when agent_session_id is set */
    agentSessionConfigVersion?: bigint | undefined;
    botUserId: bigint;
    /** human actor whose message/event caused the run */
    triggeringUserId?: bigint | undefined;
    /** persisted trigger message/event, when present */
    triggeringMessageId?: bigint | undefined;
    status: ChatAgentRunStatus;
    /** app-owned correlation ID (not an FK) */
    externalRunId?: string | undefined;
    genkitTraceId?: string | undefined;
    genkitSessionId?: string | undefined;
    genkitRequestId?: string | undefined;
    /** small sanitized operational metadata only */
    metadataJson: Uint8Array;
    startedAt?: Date | undefined;
    /** set on terminal statuses, including model-step limit */
    completedAt?: Date | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    /** immutable owning-org snapshot; absent when no organization owns the run */
    organizationId?: bigint | undefined;
}
/**
 * AgentRunStatusSnapshot is the viewer-safe status read model for one agent run. It is
 * deliberately narrower than ChatAgentRun: no trace ids, metadata, lease owner, or budgets.
 */
export interface AgentRunStatusSnapshot {
    agentRunId: bigint;
    channelId: bigint;
    /** thread scope; 0 = main timeline */
    parentMessageId: bigint;
    status: ChatAgentRunStatus;
    statusReason: ChatAgentRunStatusReason;
    /** Application-supplied identifier-like code recorded with a cancellation; empty otherwise. */
    statusReasonCode: string;
    startedAt?: Date | undefined;
    /** set on terminal statuses only */
    completedAt?: Date | undefined;
    /** Set only while a drivable run waits out a backoff (deadline still in the future). */
    retryNotBefore?: Date | undefined;
    retryReason: ChatAgentRunStatusReason;
    /**
     * True while a worker holds a live drive or tool-execution lease. Supervision is not progress: a supervised
     * run may be waiting on a provider.
     */
    supervised: boolean;
    /** Durably derivable activity only; UNSPECIFIED when no finer detail is known. */
    activity: AgentRunActivity;
    activityStartedAt?: Date | undefined;
    /** TOOL_CALL message behind the activity; omitted when that row is hidden from users. */
    activityMessageId?: bigint | undefined;
    /** Newest transcript write for the run. Set for non-terminal runs only. */
    lastProgressAt?: Date | undefined;
}
/** ThreadAgentRunStatus groups the runs of one thread location, newest first. */
export interface ThreadAgentRunStatus {
    parentMessageId: bigint;
    /** absent when the location has no run */
    latest?: AgentRunStatusSnapshot | undefined;
    /** older runs, newest first, bounded by history_limit */
    earlier: AgentRunStatusSnapshot[];
    /**
     * True when the location holds a delegated child session (one with a parent agent session).
     * Always false for the main timeline and for ordinary thread agents.
     */
    delegated: boolean;
    /**
     * How the location's agent session takes input right now. Absent when the location has no
     * agent session; present even when it has no run.
     */
    interaction?: AgentSessionInteraction | undefined;
}
/**
 * AgentSessionInteraction is the viewer-specific composer state of one agent session: its
 * effective input policy, what it is doing, and what the viewer may do about it.
 */
export interface AgentSessionInteraction {
    agentSessionId: bigint;
    /** effective mode of the run in flight, else of the session */
    inputMode: ChatAgentInputMode;
    /** the same policy's user-Stop opt-in */
    allowUserStop: boolean;
    activity: ChatAgentSessionActivity;
    /** input waiting for admission (or held while suspended) */
    pendingInputCount: number;
    /** set only while SUSPENDED */
    suspendedByUserId?: bigint | undefined;
    /** set only while SUSPENDED */
    suspendedAt?: Date | undefined;
    viewerCanStop: boolean;
    viewerCanResume: boolean;
    /**
     * False when people's messages never reach the agent as input: a workflow-owned agent, a
     * session that is not live, or one whose automatic runs are disabled. Its messages are ordinary
     * transcript whatever input_mode and activity say, so a composer sends them as usual.
     * viewer_can_stop and viewer_can_resume still say whether Stop and Resume apply (never for a
     * workflow-owned agent, whose owner drives every run).
     */
    acceptsInput: boolean;
}
/**
 * AgentInputReceipt is the outcome of one send for one agent session it targeted. A thread reply
 * broadcast to the channel may target two sessions and so carry two receipts.
 */
export interface AgentInputReceipt {
    agentSessionId: bigint;
    state: ChatAgentInputReceiptState;
    /**
     * The run that received the message: the run it started (RUN_STARTED) or the run its queued
     * input was delivered into (ADMITTED). Absent while the input is queued.
     */
    agentRunId?: bigint | undefined;
}
/**
 * AgentQueuedInput is a person's input waiting in an agent session's queue because the session
 * was busy or suspended when it was sent. It is not a message: it appears in no transcript, model
 * context, unread count or notification. When the agent receives it, the server writes the chat
 * message (a new id, at the bottom of the conversation, announced by MESSAGE_SENT) and the input
 * leaves the queue. Everyone who can read the conversation sees its whole queue.
 */
export interface AgentQueuedInput {
    /** queue order; not a message id */
    id: bigint;
    agentSessionId: bigint;
    channelId: bigint;
    /** the session's location: thread root, 0 = main timeline */
    parentMessageId: bigint;
    senderId: bigint;
    sender?: PublicUser | undefined;
    /** message markup, mention tokens included, as sent or last edited */
    content: string;
    contentType: MessageContentType;
    /** reply reference (0 = none) */
    replyToMessageId: bigint;
    attachmentIds: bigint[];
    attachments: UploadedAttachment[];
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    /**
     * What the viewer may do with it, only while they take part in the channel and it is not
     * archived: edit it when they sent it, and remove it when they sent it or administer the channel,
     * each unless the application's Authorize callback denies it.
     */
    viewerCanEdit: boolean;
    viewerCanRemove: boolean;
    /**
     * Embeds the input carries. They are not editable here: an edit keeps them, so it may leave the
     * text empty while there are any.
     */
    embedCount: number;
}
/**
 * AgentSessionSummary is the read-only identity of one agent session bound to a channel
 * location. Delegated child sessions carry the parent link; run state is read separately
 * through GetAgentRunStatus.
 */
export interface AgentSessionSummary {
    agentSessionId: bigint;
    channelId: bigint;
    /** thread root; 0 is the main timeline */
    parentMessageId: bigint;
    agentType: string;
    /** registry display name, falling back to agent_type */
    agentDisplayName: string;
    botUserId: bigint;
    status: ChatAgentSessionStatus;
    /** set only on delegated child sessions */
    parentAgentSessionId?: bigint | undefined;
    /** the parent run whose spawn created the child */
    spawnedByAgentRunId?: bigint | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    /**
     * Read-only execution diagnostics, exposed through the same channel read gate.
     * Identity values are absent for legacy sessions awaiting their first inference pin.
     */
    executionInferenceModelId?: bigint | undefined;
    executionInferenceApi?: InferenceAPI | undefined;
    executionProviderId?: string | undefined;
    executionProviderModelId?: string | undefined;
    selectionSource: InferenceSelectionSource;
    inferencePinVersion: bigint;
    /** A blocked session retains its lifecycle status and pinned identity. */
    inferenceBlockedReason: InferenceBlockReason;
    inferenceBlockedAt?: Date | undefined;
    /** Application operation captured with the pin; 0 for an unpinned legacy session. */
    inferenceOperation: number;
    /** Work organization that owns the session and whose inference policy governs it. */
    organizationId: bigint;
    /**
     * Application re-target gate of the session's operation; UNSPECIFIED (treated
     * as NEVER) when the agent type or inference routing is not registered.
     */
    inferenceSessionRetarget: InferenceSessionRetarget;
}
/**
 * ChatInferenceCall is the append-only source of truth for per-model-call usage
 * and finish metadata. One row == one model/provider invocation (Decision 2.5).
 */
export interface ChatInferenceCall {
    id: bigint;
    channelId: bigint;
    /** assistant/compaction message most directly associated */
    messageId?: bigint | undefined;
    /** references ChatAgentRun */
    agentRunId?: bigint | undefined;
    /** transcript step this invocation attempted/produced */
    agentStepIndex?: number | undefined;
    /** idempotency/correlation key */
    callId: string;
    /** monotonic invocation order within agent_run_id */
    callIndex: number;
    purpose: InferenceCallPurpose;
    providerId: string;
    /** normalized provider model ID */
    providerModelId: string;
    /** link to go-common's configured inference model row */
    inferenceModelId?: bigint | undefined;
    /** genkit FinishReason; empty if failed before response */
    finishReason: string;
    /** capped provider/genkit detail */
    finishMessage: string;
    latencyMs: bigint;
    /**
     * Usage dimensions (int64 to allow channel/session aggregation; provider
     * values for a single call are smaller). 0 default when not supplied.
     */
    inputTokens: bigint;
    outputTokens: bigint;
    totalTokens: bigint;
    thoughtsTokens: bigint;
    cachedContentTokens: bigint;
    inputCharacters: bigint;
    outputCharacters: bigint;
    inputImages: bigint;
    outputImages: bigint;
    inputVideos: bigint;
    outputVideos: bigint;
    inputAudioFiles: bigint;
    outputAudioFiles: bigint;
    /** serialized GenerationUsage.Custom (preserve float values) */
    customUsageJson: Uint8Array;
    /** per-call trace span correlation, when available */
    genkitSpanId?: string | undefined;
    /** small sanitized operational metadata only */
    metadataJson: Uint8Array;
    createdAt?: Date | undefined;
    /**
     * Durable agent-run attribution copied from ChatAgentRun / ChatAgentSession
     * when the call is produced by the first-class agent runtime. Empty for
     * manual/non-agent generation paths.
     */
    agentSessionId?: bigint | undefined;
    agentSessionConfigVersion?: bigint | undefined;
    agentType: string;
    triggeringUserId?: bigint | undefined;
    actorUserId?: bigint | undefined;
    /** charged organization; absent for uncharged or global generation */
    organizationId?: bigint | undefined;
}
/**
 * ChatInferenceTotals is the denormalized per-channel aggregate cache rebuildable
 * from ChatInferenceCall. It is not the source of truth (Decision 2.5).
 */
export interface ChatInferenceTotals {
    channelId: bigint;
    callCount: bigint;
    inputTokensTotal: bigint;
    outputTokensTotal: bigint;
    totalTokensTotal: bigint;
    thoughtsTokensTotal: bigint;
    cachedContentTokensTotal: bigint;
    inputCharactersTotal: bigint;
    outputCharactersTotal: bigint;
    inputImagesTotal: bigint;
    outputImagesTotal: bigint;
    inputVideosTotal: bigint;
    outputVideosTotal: bigint;
    inputAudioFilesTotal: bigint;
    outputAudioFilesTotal: bigint;
    updatedAt?: Date | undefined;
}
/**
 * AgentSessionUsage is a derived read model: totals scoped to an agent session
 * (its channel) plus optional breakdowns by run, purpose, provider, and model.
 */
export interface AgentSessionUsage {
    agentSessionId: bigint;
    channelId: bigint;
    /** session/channel-scoped aggregate */
    totals?: ChatInferenceTotals | undefined;
    byRun: AgentSessionUsageBreakdown[];
    byPurpose: AgentSessionUsageBreakdown[];
    byProvider: AgentSessionUsageBreakdown[];
    byModel: AgentSessionUsageBreakdown[];
    /**
     * by_session is filled only when includes_children is true: the parent first, then each
     * delegated child by session id.
     */
    bySession: AgentSessionUsageBreakdown[];
    /**
     * includes_children reports that totals and breakdowns cover the session and its delegated
     * children. It is false for a child session even when children were requested.
     */
    includesChildren: boolean;
}
/**
 * AgentSessionUsageBreakdown is one dimensional slice of session usage. Its
 * axis chooses the key fields: run ID, purpose, provider ID, provider/model IDs,
 * or session ID plus agent type. A model/session axis can therefore have two key fields.
 */
export interface AgentSessionUsageBreakdown {
    agentRunId?: bigint | undefined;
    purpose?: InferenceCallPurpose | undefined;
    providerId?: string | undefined;
    providerModelId?: string | undefined;
    callCount: bigint;
    inputTokens: bigint;
    outputTokens: bigint;
    totalTokens: bigint;
    thoughtsTokens: bigint;
    cachedContentTokens: bigint;
    /** by_session axis */
    agentSessionId?: bigint | undefined;
    /** by_session axis: the session's agent type */
    agentType?: string | undefined;
}
/**
 * MessageInferenceSummary is derived usage for one assistant/compaction message,
 * aggregated from linked ChatInferenceCall rows. It is NOT stored on Message
 * (Decision 2.5). Empty/zero when no ledger rows exist for the message.
 */
export interface MessageInferenceSummary {
    messageId: bigint;
    channelId: bigint;
    callCount: bigint;
    inputTokens: bigint;
    outputTokens: bigint;
    totalTokens: bigint;
    thoughtsTokens: bigint;
    cachedContentTokens: bigint;
    providerId: string;
    providerModelId: string;
    finishReason: string;
    latencyMs: bigint;
}
/**
 * ChatInferenceUsageUpdate is the CHAT_EVENT_TYPE_INFERENCE_USAGE_UPDATED payload, read after
 * the ledger write commits. Totals are cumulative, so a client keeps the copy with the higher
 * call_count when frames arrive out of order.
 */
export interface ChatInferenceUsageUpdate {
    channelId: bigint;
    /** Always set. */
    channelTotals?: ChatInferenceTotals | undefined;
    /** 0 when the call belongs to no agent session. */
    agentSessionId: bigint;
    /** That session alone, never a delegation rollup; unset when agent_session_id is 0. */
    sessionTotals?: ChatInferenceTotals | undefined;
    /** The linked message's cumulative summary; unset for calls no visible message records. */
    messageSummary?: MessageInferenceSummary | undefined;
}
export declare const Channel: MessageFns<Channel>;
export declare const ChannelForkRules: MessageFns<ChannelForkRules>;
export declare const ChannelParticipant: MessageFns<ChannelParticipant>;
export declare const Message: MessageFns<Message>;
export declare const MessageModelPayload: MessageFns<MessageModelPayload>;
export declare const ContextEventPayload: MessageFns<ContextEventPayload>;
export declare const ProviderStatePayload: MessageFns<ProviderStatePayload>;
export declare const ToolCallPayload: MessageFns<ToolCallPayload>;
export declare const RejectedToolArguments: MessageFns<RejectedToolArguments>;
export declare const ToolResultPayload: MessageFns<ToolResultPayload>;
export declare const MessagePart: MessageFns<MessagePart>;
export declare const TextPart: MessageFns<TextPart>;
export declare const MediaPart: MessageFns<MediaPart>;
export declare const DataPart: MessageFns<DataPart>;
export declare const CompactionPayload: MessageFns<CompactionPayload>;
export declare const MessageEmbed: MessageFns<MessageEmbed>;
export declare const MessageReaction: MessageFns<MessageReaction>;
export declare const MessageMention: MessageFns<MessageMention>;
export declare const ChatMessageEditHistoryEntry: MessageFns<ChatMessageEditHistoryEntry>;
export declare const ImageEmbedData: MessageFns<ImageEmbedData>;
export declare const ChatAgentRun: MessageFns<ChatAgentRun>;
export declare const AgentRunStatusSnapshot: MessageFns<AgentRunStatusSnapshot>;
export declare const ThreadAgentRunStatus: MessageFns<ThreadAgentRunStatus>;
export declare const AgentSessionInteraction: MessageFns<AgentSessionInteraction>;
export declare const AgentInputReceipt: MessageFns<AgentInputReceipt>;
export declare const AgentQueuedInput: MessageFns<AgentQueuedInput>;
export declare const AgentSessionSummary: MessageFns<AgentSessionSummary>;
export declare const ChatInferenceCall: MessageFns<ChatInferenceCall>;
export declare const ChatInferenceTotals: MessageFns<ChatInferenceTotals>;
export declare const AgentSessionUsage: MessageFns<AgentSessionUsage>;
export declare const AgentSessionUsageBreakdown: MessageFns<AgentSessionUsageBreakdown>;
export declare const MessageInferenceSummary: MessageFns<MessageInferenceSummary>;
export declare const ChatInferenceUsageUpdate: MessageFns<ChatInferenceUsageUpdate>;
type Builtin = Date | Function | Uint8Array | string | number | boolean | bigint | undefined;
type DeepPartial<T> = T extends bigint ? string | number | bigint : T extends Builtin ? T : T extends globalThis.Array<infer U> ? globalThis.Array<DeepPartial<U>> : T extends ReadonlyArray<infer U> ? ReadonlyArray<DeepPartial<U>> : T extends {} ? {
    [K in keyof T]?: DeepPartial<T[K]>;
} : Partial<T>;
type KeysOfUnion<T> = T extends T ? keyof T : never;
type Exact<P, I extends P> = P extends Builtin ? P : P & {
    [K in keyof P]: Exact<P[K], I[K]>;
} & {
    [K in Exclude<keyof I, KeysOfUnion<P>>]: never;
};
interface MessageFns<T> {
    encode(message: T, writer?: BinaryWriter): BinaryWriter;
    decode(input: BinaryReader | Uint8Array, length?: number): T;
    fromJSON(object: any): T;
    toJSON(message: T): unknown;
    create<I extends Exact<DeepPartial<T>, I>>(base?: I): T;
    fromPartial<I extends Exact<DeepPartial<T>, I>>(object: I): T;
}
export {};
//# sourceMappingURL=chat.d.ts.map