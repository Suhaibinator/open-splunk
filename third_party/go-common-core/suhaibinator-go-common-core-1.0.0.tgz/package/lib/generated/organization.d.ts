import { BinaryReader, BinaryWriter } from "@bufbuild/protobuf/wire";
import { PublicUser } from "./user";
/**
 * Defines the role of a user within an organization.
 * Ordered bands/tiers are permission identities. Actual operations are controlled
 * by configured role/user-type thresholds and organization capability policy.
 */
export declare enum OrganizationRole {
    ORGANIZATION_ROLE_UNSPECIFIED = 0,
    /** ORGANIZATION_ROLE_MEMBER_TIER_0 - Member roles (tiers 0-10) - Basic organizational access */
    ORGANIZATION_ROLE_MEMBER_TIER_0 = 1,
    ORGANIZATION_ROLE_MEMBER_TIER_1 = 2,
    ORGANIZATION_ROLE_MEMBER_TIER_2 = 3,
    ORGANIZATION_ROLE_MEMBER_TIER_3 = 4,
    ORGANIZATION_ROLE_MEMBER_TIER_4 = 5,
    ORGANIZATION_ROLE_MEMBER_TIER_5 = 6,
    ORGANIZATION_ROLE_MEMBER_TIER_6 = 7,
    ORGANIZATION_ROLE_MEMBER_TIER_7 = 8,
    ORGANIZATION_ROLE_MEMBER_TIER_8 = 9,
    ORGANIZATION_ROLE_MEMBER_TIER_9 = 10,
    ORGANIZATION_ROLE_MEMBER_TIER_10 = 11,
    /** ORGANIZATION_ROLE_MODERATOR_TIER_0 - Moderator roles (tiers 0-10) - Content and user management */
    ORGANIZATION_ROLE_MODERATOR_TIER_0 = 12,
    ORGANIZATION_ROLE_MODERATOR_TIER_1 = 13,
    ORGANIZATION_ROLE_MODERATOR_TIER_2 = 14,
    ORGANIZATION_ROLE_MODERATOR_TIER_3 = 15,
    ORGANIZATION_ROLE_MODERATOR_TIER_4 = 16,
    ORGANIZATION_ROLE_MODERATOR_TIER_5 = 17,
    ORGANIZATION_ROLE_MODERATOR_TIER_6 = 18,
    ORGANIZATION_ROLE_MODERATOR_TIER_7 = 19,
    ORGANIZATION_ROLE_MODERATOR_TIER_8 = 20,
    ORGANIZATION_ROLE_MODERATOR_TIER_9 = 21,
    ORGANIZATION_ROLE_MODERATOR_TIER_10 = 22,
    /** ORGANIZATION_ROLE_ADMIN_TIER_0 - Admin roles (tiers 0-10) - Administrative and management access */
    ORGANIZATION_ROLE_ADMIN_TIER_0 = 23,
    ORGANIZATION_ROLE_ADMIN_TIER_1 = 24,
    ORGANIZATION_ROLE_ADMIN_TIER_2 = 25,
    ORGANIZATION_ROLE_ADMIN_TIER_3 = 26,
    ORGANIZATION_ROLE_ADMIN_TIER_4 = 27,
    ORGANIZATION_ROLE_ADMIN_TIER_5 = 28,
    ORGANIZATION_ROLE_ADMIN_TIER_6 = 29,
    ORGANIZATION_ROLE_ADMIN_TIER_7 = 30,
    ORGANIZATION_ROLE_ADMIN_TIER_8 = 31,
    ORGANIZATION_ROLE_ADMIN_TIER_9 = 32,
    ORGANIZATION_ROLE_ADMIN_TIER_10 = 33,
    /** ORGANIZATION_ROLE_OWNER_TIER_0 - Owner roles (tiers 0-10) - Ultimate organizational control */
    ORGANIZATION_ROLE_OWNER_TIER_0 = 34,
    ORGANIZATION_ROLE_OWNER_TIER_1 = 35,
    ORGANIZATION_ROLE_OWNER_TIER_2 = 36,
    ORGANIZATION_ROLE_OWNER_TIER_3 = 37,
    ORGANIZATION_ROLE_OWNER_TIER_4 = 38,
    ORGANIZATION_ROLE_OWNER_TIER_5 = 39,
    ORGANIZATION_ROLE_OWNER_TIER_6 = 40,
    ORGANIZATION_ROLE_OWNER_TIER_7 = 41,
    ORGANIZATION_ROLE_OWNER_TIER_8 = 42,
    ORGANIZATION_ROLE_OWNER_TIER_9 = 43,
    ORGANIZATION_ROLE_OWNER_TIER_10 = 44,
    UNRECOGNIZED = -1
}
export declare function organizationRoleFromJSON(object: any): OrganizationRole;
export declare function organizationRoleToJSON(object: OrganizationRole): string;
/**
 * Defines the type/tier of an organization.
 * Uses a tiered approach similar to UserType for feature and capability gating.
 */
export declare enum OrganizationType {
    /** ORGANIZATION_TYPE_UNSPECIFIED - Default unspecified state */
    ORGANIZATION_TYPE_UNSPECIFIED = 0,
    /** ORGANIZATION_TYPE_BASIC_TIER_0 - Basic organizations (tiers 0-10) - Minimal organization capabilities */
    ORGANIZATION_TYPE_BASIC_TIER_0 = 1,
    ORGANIZATION_TYPE_BASIC_TIER_1 = 2,
    ORGANIZATION_TYPE_BASIC_TIER_2 = 3,
    ORGANIZATION_TYPE_BASIC_TIER_3 = 4,
    ORGANIZATION_TYPE_BASIC_TIER_4 = 5,
    ORGANIZATION_TYPE_BASIC_TIER_5 = 6,
    ORGANIZATION_TYPE_BASIC_TIER_6 = 7,
    ORGANIZATION_TYPE_BASIC_TIER_7 = 8,
    ORGANIZATION_TYPE_BASIC_TIER_8 = 9,
    ORGANIZATION_TYPE_BASIC_TIER_9 = 10,
    ORGANIZATION_TYPE_BASIC_TIER_10 = 11,
    /** ORGANIZATION_TYPE_BUSINESS_TIER_0 - Business organizations (tiers 0-10) - Standard organization capabilities */
    ORGANIZATION_TYPE_BUSINESS_TIER_0 = 12,
    ORGANIZATION_TYPE_BUSINESS_TIER_1 = 13,
    ORGANIZATION_TYPE_BUSINESS_TIER_2 = 14,
    ORGANIZATION_TYPE_BUSINESS_TIER_3 = 15,
    ORGANIZATION_TYPE_BUSINESS_TIER_4 = 16,
    ORGANIZATION_TYPE_BUSINESS_TIER_5 = 17,
    ORGANIZATION_TYPE_BUSINESS_TIER_6 = 18,
    ORGANIZATION_TYPE_BUSINESS_TIER_7 = 19,
    ORGANIZATION_TYPE_BUSINESS_TIER_8 = 20,
    ORGANIZATION_TYPE_BUSINESS_TIER_9 = 21,
    ORGANIZATION_TYPE_BUSINESS_TIER_10 = 22,
    /** ORGANIZATION_TYPE_ENTERPRISE_TIER_0 - Enterprise organizations (tiers 0-10) - Expanded organization capabilities */
    ORGANIZATION_TYPE_ENTERPRISE_TIER_0 = 23,
    ORGANIZATION_TYPE_ENTERPRISE_TIER_1 = 24,
    ORGANIZATION_TYPE_ENTERPRISE_TIER_2 = 25,
    ORGANIZATION_TYPE_ENTERPRISE_TIER_3 = 26,
    ORGANIZATION_TYPE_ENTERPRISE_TIER_4 = 27,
    ORGANIZATION_TYPE_ENTERPRISE_TIER_5 = 28,
    ORGANIZATION_TYPE_ENTERPRISE_TIER_6 = 29,
    ORGANIZATION_TYPE_ENTERPRISE_TIER_7 = 30,
    ORGANIZATION_TYPE_ENTERPRISE_TIER_8 = 31,
    ORGANIZATION_TYPE_ENTERPRISE_TIER_9 = 32,
    ORGANIZATION_TYPE_ENTERPRISE_TIER_10 = 33,
    /** ORGANIZATION_TYPE_INTERNAL_TIER_0 - Internal organizations (tiers 0-10) - Internal/system organization capabilities */
    ORGANIZATION_TYPE_INTERNAL_TIER_0 = 34,
    ORGANIZATION_TYPE_INTERNAL_TIER_1 = 35,
    ORGANIZATION_TYPE_INTERNAL_TIER_2 = 36,
    ORGANIZATION_TYPE_INTERNAL_TIER_3 = 37,
    ORGANIZATION_TYPE_INTERNAL_TIER_4 = 38,
    ORGANIZATION_TYPE_INTERNAL_TIER_5 = 39,
    ORGANIZATION_TYPE_INTERNAL_TIER_6 = 40,
    ORGANIZATION_TYPE_INTERNAL_TIER_7 = 41,
    ORGANIZATION_TYPE_INTERNAL_TIER_8 = 42,
    ORGANIZATION_TYPE_INTERNAL_TIER_9 = 43,
    ORGANIZATION_TYPE_INTERNAL_TIER_10 = 44,
    UNRECOGNIZED = -1
}
export declare function organizationTypeFromJSON(object: any): OrganizationType;
export declare function organizationTypeToJSON(object: OrganizationType): string;
/** Represents an organization, which is a collection of users. */
export interface Organization {
    id: bigint;
    name: string;
    /** URL-friendly organization identifier */
    slug: string;
    description?: string | undefined;
    /** URL to the organization's avatar/logo */
    avatarUrl?: string | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    parentOrganizationId?: bigint | undefined;
    /** Ordered list of ancestor org IDs (root -> parent) */
    lineage: bigint[];
    /** Type/tier used for org capability gating */
    organizationType: OrganizationType;
    /** Present for every organization in a personal workspace tree */
    personalOwnerUserId?: bigint | undefined;
}
/** Represents a user's membership and role within an organization. */
export interface OrganizationUser {
    organizationId: bigint;
    userId: bigint;
    explicitRole: OrganizationRole;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    inheritedFromOrganizationId?: bigint | undefined;
    effectiveRole: OrganizationRole;
    /** Absolute depth of org that supplied effective_role (0=root) */
    effectiveRoleDepth?: number | undefined;
}
/**
 * Combines organization information with the user's role in that organization.
 * Used for listing organizations where we need both the org details and user's role.
 */
export interface OrganizationWithUserRole {
    organization?: Organization | undefined;
    explicitRole: OrganizationRole;
    inheritedFromOrganizationId?: bigint | undefined;
    effectiveRole: OrganizationRole;
    /** Absolute depth of org that supplied effective_role (0=root) */
    effectiveRoleDepth?: number | undefined;
}
/** Represents a domain that is associated with an organization for auto-membership. */
export interface OrganizationEmailDomain {
    id: bigint;
    organizationId: bigint;
    /** Normalized (lowercase) domain value */
    domain: string;
    /** Optional user responsible for adding the domain */
    createdByUserId?: bigint | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
}
export interface OrganizationMembershipMaskFilter {
    depth: number;
    explicitRoleMask: bigint;
    organizationTypeMask: bigint;
}
/**
 * Detailed member information including user profile and activity data.
 * Member-attribute visibility is filtered using the configured organization-role
 * and global user-type policy for the requesting viewer.
 */
export interface OrganizationMemberDetails {
    organizationId: bigint;
    userId: bigint;
    explicitRole: OrganizationRole;
    /** When user joined the organization */
    createdAt?: Date | undefined;
    /** When membership was last updated */
    updatedAt?: Date | undefined;
    /** User profile information */
    user?: PublicUser | undefined;
    /** Activity and status information */
    isActive: boolean;
    /** Optional activity timestamp; the built-in user projection does not track it */
    lastActivity?: Date | undefined;
    inheritedFromOrganizationId?: bigint | undefined;
    effectiveRole: OrganizationRole;
    /** Absolute depth of org that supplied effective_role (0=root) */
    effectiveRoleDepth?: number | undefined;
}
/**
 * Represents a pending invitation for a user to join an organization.
 * Used when inviting users by email (who may not have accounts yet) or when
 * the invite flow requires user acceptance before joining.
 */
export interface OrganizationInvitation {
    id: bigint;
    organizationId: bigint;
    /** Email of the invited user (normalized lowercase) */
    email: string;
    /** Role the user will have upon acceptance */
    role: OrganizationRole;
    /** User who sent the invitation */
    invitedByUserId: bigint;
    createdAt?: Date | undefined;
    /** When the invitation expires */
    expiresAt?: Date | undefined;
    /** When the invitation was accepted (null if pending) */
    acceptedAt?: Date | undefined;
    /** When the invitation was declined (null if pending) */
    declinedAt?: Date | undefined;
    /** Organization details for display purposes */
    organization?: Organization | undefined;
    /** True for invite flow; false for auto-add once user registers */
    requiresAcceptance: boolean;
}
export declare const Organization: MessageFns<Organization>;
export declare const OrganizationUser: MessageFns<OrganizationUser>;
export declare const OrganizationWithUserRole: MessageFns<OrganizationWithUserRole>;
export declare const OrganizationEmailDomain: MessageFns<OrganizationEmailDomain>;
export declare const OrganizationMembershipMaskFilter: MessageFns<OrganizationMembershipMaskFilter>;
export declare const OrganizationMemberDetails: MessageFns<OrganizationMemberDetails>;
export declare const OrganizationInvitation: MessageFns<OrganizationInvitation>;
type Builtin = Date | Function | Uint8Array | string | number | boolean | bigint | undefined;
type DeepPartial<T> = T extends bigint ? string | number | bigint : T extends Builtin ? T : T extends globalThis.Array<infer U> ? globalThis.Array<DeepPartial<U>> : T extends ReadonlyArray<infer U> ? ReadonlyArray<DeepPartial<U>> : T extends {} ? {
    [K in keyof T]?: DeepPartial<T[K]>;
} : Partial<T>;
type KeysOfUnion<T> = T extends T ? keyof T : never;
type Exact<P, I extends P> = P extends Builtin ? P : P & {
    [K in keyof P]: Exact<P[K], I[K]>;
} & {
    [K in Exclude<keyof I, KeysOfUnion<P>>]: never;
};
interface MessageFns<T> {
    encode(message: T, writer?: BinaryWriter): BinaryWriter;
    decode(input: BinaryReader | Uint8Array, length?: number): T;
    fromJSON(object: any): T;
    toJSON(message: T): unknown;
    create<I extends Exact<DeepPartial<T>, I>>(base?: I): T;
    fromPartial<I extends Exact<DeepPartial<T>, I>>(object: I): T;
}
export {};
//# sourceMappingURL=organization.d.ts.map