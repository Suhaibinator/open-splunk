import { BinaryReader, BinaryWriter } from "@bufbuild/protobuf/wire";
import { Language } from "./language";
/**
 * Bands and tiers identify ordered user types; enabled features and permissions
 * come from configuration/application policy, not a fixed feature set per enum.
 */
export declare enum UserType {
    /** USER_TYPE_UNSPECIFIED - Default unspecified state (no privileges) */
    USER_TYPE_UNSPECIFIED = 0,
    /** USER_TYPE_LITE_TIER_0 - Lite users (tiers 0-10) - Basic feature access */
    USER_TYPE_LITE_TIER_0 = 1,
    /** USER_TYPE_LITE_TIER_1 - Lite user (tier 1) */
    USER_TYPE_LITE_TIER_1 = 2,
    /** USER_TYPE_LITE_TIER_2 - Lite user (tier 2) */
    USER_TYPE_LITE_TIER_2 = 3,
    /** USER_TYPE_LITE_TIER_3 - Lite user (tier 3) */
    USER_TYPE_LITE_TIER_3 = 4,
    /** USER_TYPE_LITE_TIER_4 - Lite user (tier 4) */
    USER_TYPE_LITE_TIER_4 = 5,
    /** USER_TYPE_LITE_TIER_5 - Lite user (tier 5) */
    USER_TYPE_LITE_TIER_5 = 6,
    /** USER_TYPE_LITE_TIER_6 - Lite user (tier 6) */
    USER_TYPE_LITE_TIER_6 = 7,
    /** USER_TYPE_LITE_TIER_7 - Lite user (tier 7) */
    USER_TYPE_LITE_TIER_7 = 8,
    /** USER_TYPE_LITE_TIER_8 - Lite user (tier 8) */
    USER_TYPE_LITE_TIER_8 = 9,
    /** USER_TYPE_LITE_TIER_9 - Lite user (tier 9) */
    USER_TYPE_LITE_TIER_9 = 10,
    /** USER_TYPE_LITE_TIER_10 - Lite user (tier 10) */
    USER_TYPE_LITE_TIER_10 = 11,
    /** USER_TYPE_REGULAR_TIER_0 - Regular users (tiers 0-10) - Standard feature access */
    USER_TYPE_REGULAR_TIER_0 = 12,
    /** USER_TYPE_REGULAR_TIER_1 - Regular user (tier 1) */
    USER_TYPE_REGULAR_TIER_1 = 13,
    /** USER_TYPE_REGULAR_TIER_2 - Regular user (tier 2) */
    USER_TYPE_REGULAR_TIER_2 = 14,
    /** USER_TYPE_REGULAR_TIER_3 - Regular user (tier 3) */
    USER_TYPE_REGULAR_TIER_3 = 15,
    /** USER_TYPE_REGULAR_TIER_4 - Regular user (tier 4) */
    USER_TYPE_REGULAR_TIER_4 = 16,
    /** USER_TYPE_REGULAR_TIER_5 - Regular user (tier 5) */
    USER_TYPE_REGULAR_TIER_5 = 17,
    /** USER_TYPE_REGULAR_TIER_6 - Regular user (tier 6) */
    USER_TYPE_REGULAR_TIER_6 = 18,
    /** USER_TYPE_REGULAR_TIER_7 - Regular user (tier 7) */
    USER_TYPE_REGULAR_TIER_7 = 19,
    /** USER_TYPE_REGULAR_TIER_8 - Regular user (tier 8) */
    USER_TYPE_REGULAR_TIER_8 = 20,
    /** USER_TYPE_REGULAR_TIER_9 - Regular user (tier 9) */
    USER_TYPE_REGULAR_TIER_9 = 21,
    /** USER_TYPE_REGULAR_TIER_10 - Regular user (tier 10) */
    USER_TYPE_REGULAR_TIER_10 = 22,
    /** USER_TYPE_PREMIUM_TIER_0 - Premium users (tiers 0-10) - Enhanced feature access */
    USER_TYPE_PREMIUM_TIER_0 = 23,
    /** USER_TYPE_PREMIUM_TIER_1 - Premium user (tier 1) */
    USER_TYPE_PREMIUM_TIER_1 = 24,
    /** USER_TYPE_PREMIUM_TIER_2 - Premium user (tier 2) */
    USER_TYPE_PREMIUM_TIER_2 = 25,
    /** USER_TYPE_PREMIUM_TIER_3 - Premium user (tier 3) */
    USER_TYPE_PREMIUM_TIER_3 = 26,
    /** USER_TYPE_PREMIUM_TIER_4 - Premium user (tier 4) */
    USER_TYPE_PREMIUM_TIER_4 = 27,
    /** USER_TYPE_PREMIUM_TIER_5 - Premium user (tier 5) */
    USER_TYPE_PREMIUM_TIER_5 = 28,
    /** USER_TYPE_PREMIUM_TIER_6 - Premium user (tier 6) */
    USER_TYPE_PREMIUM_TIER_6 = 29,
    /** USER_TYPE_PREMIUM_TIER_7 - Premium user (tier 7) */
    USER_TYPE_PREMIUM_TIER_7 = 30,
    /** USER_TYPE_PREMIUM_TIER_8 - Premium user (tier 8) */
    USER_TYPE_PREMIUM_TIER_8 = 31,
    /** USER_TYPE_PREMIUM_TIER_9 - Premium user (tier 9) */
    USER_TYPE_PREMIUM_TIER_9 = 32,
    /** USER_TYPE_PREMIUM_TIER_10 - Premium user (tier 10) */
    USER_TYPE_PREMIUM_TIER_10 = 33,
    /** USER_TYPE_ADMIN_TIER_0 - Admin users (tiers 0-10) - Administrative access */
    USER_TYPE_ADMIN_TIER_0 = 34,
    /** USER_TYPE_ADMIN_TIER_1 - Admin user (tier 1) */
    USER_TYPE_ADMIN_TIER_1 = 35,
    /** USER_TYPE_ADMIN_TIER_2 - Admin user (tier 2) */
    USER_TYPE_ADMIN_TIER_2 = 36,
    /** USER_TYPE_ADMIN_TIER_3 - Admin user (tier 3) */
    USER_TYPE_ADMIN_TIER_3 = 37,
    /** USER_TYPE_ADMIN_TIER_4 - Admin user (tier 4) */
    USER_TYPE_ADMIN_TIER_4 = 38,
    /** USER_TYPE_ADMIN_TIER_5 - Admin user (tier 5) */
    USER_TYPE_ADMIN_TIER_5 = 39,
    /** USER_TYPE_ADMIN_TIER_6 - Admin user (tier 6) */
    USER_TYPE_ADMIN_TIER_6 = 40,
    /** USER_TYPE_ADMIN_TIER_7 - Admin user (tier 7) */
    USER_TYPE_ADMIN_TIER_7 = 41,
    /** USER_TYPE_ADMIN_TIER_8 - Admin user (tier 8) */
    USER_TYPE_ADMIN_TIER_8 = 42,
    /** USER_TYPE_ADMIN_TIER_9 - Admin user (tier 9) */
    USER_TYPE_ADMIN_TIER_9 = 43,
    /** USER_TYPE_ADMIN_TIER_10 - Admin user (tier 10 - highest admin access) */
    USER_TYPE_ADMIN_TIER_10 = 44,
    UNRECOGNIZED = -1
}
export declare function userTypeFromJSON(object: any): UserType;
export declare function userTypeToJSON(object: UserType): string;
/** User identifier types for display purposes */
export declare enum UserIdentifierType {
    /** USER_IDENTIFIER_TYPE_UNSPECIFIED - Default unspecified */
    USER_IDENTIFIER_TYPE_UNSPECIFIED = 0,
    /** USER_IDENTIFIER_TYPE_USERNAME - Display username */
    USER_IDENTIFIER_TYPE_USERNAME = 1,
    /** USER_IDENTIFIER_TYPE_EMAIL - Display email address */
    USER_IDENTIFIER_TYPE_EMAIL = 2,
    /** USER_IDENTIFIER_TYPE_REAL_NAME - Display first_name + last_name combined */
    USER_IDENTIFIER_TYPE_REAL_NAME = 3,
    /** USER_IDENTIFIER_TYPE_USER_ID - Display user ID number */
    USER_IDENTIFIER_TYPE_USER_ID = 4,
    /** USER_IDENTIFIER_TYPE_FIRST_NAME - Display first_name only */
    USER_IDENTIFIER_TYPE_FIRST_NAME = 5,
    /** USER_IDENTIFIER_TYPE_FIRST_NAME_LAST_INITIAL - Display first_name + last initial */
    USER_IDENTIFIER_TYPE_FIRST_NAME_LAST_INITIAL = 6,
    /** USER_IDENTIFIER_TYPE_INITIALS_ONLY - Display initials only */
    USER_IDENTIFIER_TYPE_INITIALS_ONLY = 7,
    UNRECOGNIZED = -1
}
export declare function userIdentifierTypeFromJSON(object: any): UserIdentifierType;
export declare function userIdentifierTypeToJSON(object: UserIdentifierType): string;
export interface UserSettings {
    /** ID of the user these settings belong to (serves as primary key) */
    userId: bigint;
    /** Whether dark mode is enabled */
    darkMode: boolean;
    /** Preferred language */
    language: Language;
    /** Whether email notifications are enabled */
    emailNotifications: boolean;
    /** Whether push notifications are enabled */
    pushNotifications: boolean;
    /** Whether marketing emails are enabled */
    marketingEmails: boolean;
    /** Email for new chats (default: true) */
    chatEmailNotifications: boolean;
    /** Push for new chats (default: true) */
    chatPushNotifications: boolean;
}
export interface User {
    /** Unique identifier for the user */
    id: bigint;
    /** Display username */
    username: string;
    /** URL to the user's avatar image (optional) */
    avatarUrl: string;
    /** User type across lite, regular, premium, and admin bands */
    userType: UserType;
    /** Email address of the user */
    email: string;
    /** Whether the user is banned */
    banned: boolean;
    /** User's first name */
    firstName: string;
    /** User's last name */
    lastName: string;
    /** Phone number in E.164 international format (optional) */
    phoneNumber?: string | undefined;
    /** Whether this is a bot/automated account */
    isBot: boolean;
}
export interface PublicUser {
    /** Unique identifier for the user */
    id: bigint;
    /** User type across lite, regular, premium, and admin bands */
    userType: UserType;
    /** Whether the user is banned */
    banned: boolean;
    /** Primary display string based on configured identifier type */
    displayPrimary: string;
    /** Secondary display string based on configured identifier type (optional) */
    displaySecondary: string;
    /** URL to the user's avatar image (optional) */
    avatarUrl: string;
    /** Whether this is a bot/automated account */
    isBot: boolean;
}
/**
 * Response for the current-user profile endpoint (GET /user/me). Wraps the
 * shared User message with session-bootstrap data that only this endpoint
 * resolves.
 */
export interface GetCurrentUserResponse {
    /** The authenticated user's profile */
    user?: User | undefined;
    /**
     * The user's active personal workspace root organization. Absent when
     * organizations are disabled, the workspace is not yet provisioned, or the
     * workspace is archived. Corrupt workspace state is logged and omitted; other
     * workspace lookup failures fail the endpoint.
     */
    personalWorkspaceRootOrganizationId?: bigint | undefined;
}
/** Request to check if a username is available for registration. */
export interface CheckUsernameAvailabilityRequest {
    /** The username to check for availability. */
    username: string;
}
/** Response indicating whether the username is available. */
export interface CheckUsernameAvailabilityResponse {
    /** Whether the username is available for registration. */
    available: boolean;
    /** Optional message providing additional context (e.g., "Username already taken", "Username is reserved"). */
    message: string;
}
export declare const UserSettings: MessageFns<UserSettings>;
export declare const User: MessageFns<User>;
export declare const PublicUser: MessageFns<PublicUser>;
export declare const GetCurrentUserResponse: MessageFns<GetCurrentUserResponse>;
export declare const CheckUsernameAvailabilityRequest: MessageFns<CheckUsernameAvailabilityRequest>;
export declare const CheckUsernameAvailabilityResponse: MessageFns<CheckUsernameAvailabilityResponse>;
type Builtin = Date | Function | Uint8Array | string | number | boolean | bigint | undefined;
type DeepPartial<T> = T extends bigint ? string | number | bigint : T extends Builtin ? T : T extends globalThis.Array<infer U> ? globalThis.Array<DeepPartial<U>> : T extends ReadonlyArray<infer U> ? ReadonlyArray<DeepPartial<U>> : T extends {} ? {
    [K in keyof T]?: DeepPartial<T[K]>;
} : Partial<T>;
type KeysOfUnion<T> = T extends T ? keyof T : never;
type Exact<P, I extends P> = P extends Builtin ? P : P & {
    [K in keyof P]: Exact<P[K], I[K]>;
} & {
    [K in Exclude<keyof I, KeysOfUnion<P>>]: never;
};
interface MessageFns<T> {
    encode(message: T, writer?: BinaryWriter): BinaryWriter;
    decode(input: BinaryReader | Uint8Array, length?: number): T;
    fromJSON(object: any): T;
    toJSON(message: T): unknown;
    create<I extends Exact<DeepPartial<T>, I>>(base?: I): T;
    fromPartial<I extends Exact<DeepPartial<T>, I>>(object: I): T;
}
export {};
//# sourceMappingURL=user.d.ts.map