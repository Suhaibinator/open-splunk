export * as go_common from "./index.go_common";
export * as google from "./index.google";
//# sourceMappingURL=index.d.ts.map