import { BinaryReader, BinaryWriter } from "@bufbuild/protobuf/wire";
import { AttachmentMetadata, AttachmentUploadInfo } from "./attachment";
import { AgentInputReceipt, AgentQueuedInput, AgentSessionInteraction, AgentSessionSummary, AgentSessionUsage, Channel, ChannelForkRules, ChannelNotificationMode, ChannelParticipant, ChannelRole, ChannelType, ChatChannelPublicRead, ChatInferenceCall, ChatInferenceTotals, ChatMessageEditHistoryEntry, Message, MessageInferenceSummary, MessageReaction, ThreadAgentRunStatus } from "./chat";
import { PaginationRequest, PaginationResponse, SortRequest } from "./pagination";
export declare enum ListMessagesSortBy {
    LIST_MESSAGES_SORT_BY_UNSPECIFIED = 0,
    LIST_MESSAGES_SORT_BY_ID = 1,
    UNRECOGNIZED = -1
}
export declare function listMessagesSortByFromJSON(object: any): ListMessagesSortBy;
export declare function listMessagesSortByToJSON(object: ListMessagesSortBy): string;
export interface CreateChannelRequest {
    /** Omitted defaults to true. */
    unreadNotificationsEnabled?: boolean | undefined;
    name: string;
    description: string;
    channelType: ChannelType;
    participantUserIds: bigint[];
    contextId?: bigint | undefined;
    contextDisplayName?: string | undefined;
    contextEntityId?: bigint | undefined;
    /** Fork rules of the new channel. Omitted disables forking. They cannot be changed later. */
    forkRules?: ChannelForkRules | undefined;
}
export interface CreateChannelResponse {
    channel?: Channel | undefined;
}
/** ForkChannelRequest copies a channel's history up to and including a message into a new channel. */
export interface ForkChannelRequest {
    /** source channel */
    channelId: bigint;
    /**
     * Requested fork point, on the main timeline or inside a thread. History is copied up to it,
     * but in-flight agent work at the fork point is cut, so it may not be copied.
     */
    forkPointMessageId: bigint;
    name: string;
    /**
     * Members besides the forker, who is always the OWNER. The source's member_pool limits them;
     * bot users of cloned agent sessions are added automatically.
     */
    memberUserIds: bigint[];
    /** Honored only when the source's matching carry-over rule is FORKER_CHOOSES. */
    keepOrgAccess: boolean;
    keepContext: boolean;
    /**
     * Optional forker-chosen idempotency key. A retry that reuses it returns the fork it created
     * instead of forking again. Empty disables idempotency. A replay is matched on channel_id and
     * fork_point_message_id only: a reused key naming a different source or fork point is
     * rejected. name, member_user_ids and keep_* on a replay are still validated against current
     * limits but don't change the result: the original fork is returned.
     */
    clientRequestId: string;
}
export interface ForkChannelResponse {
    channel?: Channel | undefined;
}
/**
 * Get-or-create a channel unique for the exact member tuple.
 * The backend will implicitly include the authenticated caller in the tuple.
 */
export interface GetOrCreateChannelByMembersUniqueRequest {
    memberUserIds: bigint[];
    contextId?: bigint | undefined;
    contextDisplayName?: string | undefined;
    contextEntityId?: bigint | undefined;
}
export interface GetOrCreateChannelByMembersUniqueResponse {
    channel?: Channel | undefined;
    created: boolean;
}
export interface GetChannelRequest {
    channelId: bigint;
}
export interface GetChannelResponse {
    channel?: Channel | undefined;
}
/** SetChannelPublicRead sets who beyond participants may read a channel. Owner only. */
export interface SetChannelPublicReadRequest {
    channelId: bigint;
    publicRead: ChatChannelPublicRead;
}
export interface SetChannelPublicReadResponse {
    channel?: Channel | undefined;
}
/**
 * GetPublicChannel reads a CHAT_CHANNEL_PUBLIC_READ_ANYONE channel without signing in. Any other
 * channel, or any channel while public reads are disabled, answers as not found.
 */
export interface GetPublicChannelRequest {
    channelId: bigint;
}
export interface GetPublicChannelResponse {
    channel?: Channel | undefined;
}
/**
 * ListPublicMessages lists an ANYONE channel's visible messages without signing in. Pagination,
 * parent_message_id, sort and sort_by behave as in ListMessagesRequest; hidden and deleted
 * messages are never returned.
 */
export interface ListPublicMessagesRequest {
    channelId: bigint;
    pagination?: PaginationRequest | undefined;
    /** If set, lists messages in this thread (thread root ID) */
    parentMessageId: bigint;
    sort?: SortRequest | undefined;
    sortBy: ListMessagesSortBy;
}
export interface ListPublicMessagesResponse {
    messages: Message[];
    pagination?: PaginationResponse | undefined;
}
export interface UpdateChannelRequest {
    /** Omitted preserves the current setting. */
    unreadNotificationsEnabled?: boolean | undefined;
    channelId: bigint;
    name?: string | undefined;
    description?: string | undefined;
    avatarAttachmentId?: bigint | undefined;
    isArchived?: boolean | undefined;
}
export interface UpdateChannelResponse {
    channel?: Channel | undefined;
}
export interface ListChannelsRequest {
    pagination?: PaginationRequest | undefined;
    includeArchived: boolean;
}
export interface ListChannelsResponse {
    channels: Channel[];
    pagination?: PaginationResponse | undefined;
}
export interface LeaveChannelRequest {
    channelId: bigint;
}
export interface LeaveChannelResponse {
}
export interface AddParticipantsRequest {
    channelId: bigint;
    userIds: bigint[];
}
export interface AddParticipantsResponse {
    addedParticipants: ChannelParticipant[];
}
export interface RemoveParticipantRequest {
    channelId: bigint;
    userId: bigint;
}
export interface RemoveParticipantResponse {
}
export interface UpdateParticipantRoleRequest {
    channelId: bigint;
    userId: bigint;
    role: ChannelRole;
}
export interface UpdateParticipantRoleResponse {
    participant?: ChannelParticipant | undefined;
}
export interface UpdateParticipantPreferencesRequest {
    channelId: bigint;
    isPinned?: boolean | undefined;
    /** Omission preserves the current mode; unspecified and unknown modes are invalid. */
    notificationMode?: ChannelNotificationMode | undefined;
}
export interface UpdateParticipantPreferencesResponse {
    participant?: ChannelParticipant | undefined;
}
export interface ListParticipantsRequest {
    channelId: bigint;
    pagination?: PaginationRequest | undefined;
}
export interface ListParticipantsResponse {
    participants: ChannelParticipant[];
    pagination?: PaginationResponse | undefined;
    /**
     * The caller's active membership, independent of roster pagination.
     * Absent for readers who are not channel participants.
     */
    currentParticipant?: ChannelParticipant | undefined;
}
export interface ListParticipantsBatchRequest {
    channelIds: bigint[];
    pagination?: PaginationRequest | undefined;
}
export interface ChannelParticipantsBatchItem {
    channelId: bigint;
    participants: ChannelParticipant[];
    pagination?: PaginationResponse | undefined;
}
export interface ListParticipantsBatchResponse {
    items: ChannelParticipantsBatchItem[];
}
export interface CreateMessageEmbedRequest {
    embedType: number;
    embedData: Uint8Array;
    fallbackText: string;
    position: number;
}
export interface SendMessageRequest {
    channelId: bigint;
    content: string;
    /** Thread root ID (0 = main timeline) */
    parentMessageId: bigint;
    embeds: CreateMessageEmbedRequest[];
    /** Reply reference (0 = none) */
    replyToMessageId: bigint;
    attachments: AttachmentMetadata[];
    /**
     * Also show this thread reply on the main timeline. Requires parent_message_id != 0
     * and a channel with threads enabled; rejected with 400 otherwise.
     */
    broadcastToChannel: boolean;
    /**
     * Optional sender-chosen idempotency key, unique per sender and channel. A retry that reuses it
     * returns what the original send left, the queued input or, once delivered, the message, with
     * its receipts and fresh upload instructions, instead of sending again, even when the agent
     * session would now reject or cap a new send. Current hot send limits still apply to retries.
     * Empty keys disable idempotency; removing a queued input forgets its key.
     */
    clientMessageId: string;
}
/**
 * A send answers with exactly one of message and queued_input. message is the message the send
 * wrote, or, when it joined input already queued for an idle session, the message its input was
 * delivered as. queued_input is set instead when the location's agent session is busy or suspended:
 * the input waits in the session's queue and becomes a message only when the agent receives it.
 */
export interface SendMessageResponse {
    message?: Message | undefined;
    /**
     * Upload instructions for the send's attachments, which belong to the message or the queued
     * input; a queued input's attachments move to its message when it is delivered.
     */
    newAttachments: AttachmentUploadInfo[];
    /**
     * One receipt per agent session the send reached; empty outside agent sessions. RUN_STARTED or
     * ADMITTED with message, PENDING or HELD with queued_input.
     */
    agentInputReceipts: AgentInputReceipt[];
    queuedInput?: AgentQueuedInput | undefined;
}
export interface EditMessageRequest {
    messageId: bigint;
    content: string;
    /** Applied only when replace_embeds is true. */
    embeds: CreateMessageEmbedRequest[];
    /** Optional: when provided and replace_attachments is true, replaces the attachment list (empty = remove all). */
    attachments: AttachmentMetadata[];
    /** When true, replaces the entire opaque embed list (empty = remove all). */
    replaceEmbeds: boolean;
    /** When true, replaces attachment list with attachments (empty = remove all). */
    replaceAttachments: boolean;
}
export interface EditMessageResponse {
    message?: Message | undefined;
    newAttachments: AttachmentUploadInfo[];
}
export interface DeleteMessageRequest {
    messageId: bigint;
}
export interface DeleteMessageResponse {
}
export interface GetMessageRequest {
    messageId: bigint;
    /**
     * Honored only for bot/service-authority callers and admin tooling; lets them
     * read hidden_from_users rows (compaction summaries, agent notes).
     */
    includeHidden: boolean;
}
export interface GetMessageResponse {
    message?: Message | undefined;
}
export interface BatchGetMessagesRequest {
    channelId: bigint;
    messageIds: bigint[];
    /** bot/service-authority + admin tooling only */
    includeHidden: boolean;
}
export interface BatchGetMessagesResponse {
    messages: Message[];
    /** not found / not visible / not in channel */
    missingMessageIds: bigint[];
}
export interface ListMessagesRequest {
    channelId: bigint;
    /** Usually cursor-based for chat history */
    pagination?: PaginationRequest | undefined;
    /** If set, lists messages in this thread (thread root ID) */
    parentMessageId: bigint;
    includeDeleted: boolean;
    /**
     * Controls chronological direction for cursor pagination.
     * Recommended/default for chat history: sort_by=LIST_MESSAGES_SORT_BY_ID, sort_desc=true (newest-first).
     * When using cursor pagination, treat PaginationRequest.cursor as a message-id boundary:
     * - sort_desc=true  => return messages with id < cursor (older); cursor=0 starts from newest
     * - sort_desc=false => return messages with id > cursor (newer); cursor=0 starts from oldest
     */
    sort?: SortRequest | undefined;
    sortBy: ListMessagesSortBy;
    /** bot/service-authority + admin tooling only */
    includeHidden: boolean;
}
export interface ListMessagesResponse {
    messages: Message[];
    pagination?: PaginationResponse | undefined;
}
export interface ListMessageEditHistoryRequest {
    messageId: bigint;
    pagination?: PaginationRequest | undefined;
}
export interface ListMessageEditHistoryResponse {
    entries: ChatMessageEditHistoryEntry[];
    pagination?: PaginationResponse | undefined;
}
export interface AddReactionRequest {
    messageId: bigint;
    emoji: string;
}
export interface AddReactionResponse {
    reaction?: MessageReaction | undefined;
}
export interface RemoveReactionRequest {
    messageId: bigint;
    emoji: string;
}
export interface RemoveReactionResponse {
}
export interface ListReactionsRequest {
    messageId: bigint;
    pagination?: PaginationRequest | undefined;
    /** Optional: list reactions for specific emoji */
    emojiFilter?: string | undefined;
}
export interface ListReactionsResponse {
    reactions: MessageReaction[];
    pagination?: PaginationResponse | undefined;
}
/**
 * ResolveToolCall approves or denies a TOOL_CALL message that is awaiting
 * human-in-the-loop approval (approval_status == PENDING). Authority is
 * enforced server-side: the triggering user, configured site tool-approval admins,
 * or channel admins when the run's captured policy allows them; application vetoes apply.
 * On deny/expiry the service auto-writes the paired error TOOL_RESULT.
 */
export interface ResolveToolCallRequest {
    messageId: bigint;
    approve: boolean;
    /** optional human-readable denial/approval reason */
    reason?: string | undefined;
}
export interface ResolveToolCallResponse {
    /** the updated TOOL_CALL row */
    message?: Message | undefined;
}
/** GetChatInferenceTotals reads the cheap per-channel totals cache. */
export interface GetChatInferenceTotalsRequest {
    channelId: bigint;
}
export interface GetChatInferenceTotalsResponse {
    totals?: ChatInferenceTotals | undefined;
}
/**
 * GetAgentSessionUsage returns totals scoped to the agent session/channel plus
 * breakdowns by run, purpose, provider, and model; run/model axes are independently paginated.
 */
export interface GetAgentSessionUsageRequest {
    agentSessionId: bigint;
    byRunPagination?: PaginationRequest | undefined;
    byModelPagination?: PaginationRequest | undefined;
    /**
     * include_children aggregates a delegation parent together with its delegated child sessions
     * and fills AgentSessionUsage.by_session. Ignored for a session with no children.
     */
    includeChildren: boolean;
}
export interface GetAgentSessionUsageResponse {
    usage?: AgentSessionUsage | undefined;
    byRunPagination?: PaginationResponse | undefined;
    byModelPagination?: PaginationResponse | undefined;
}
/**
 * ListAgentRunInferenceCalls returns the append-only call ledger for one run
 * (debugging/audit). Paginated.
 */
export interface ListAgentRunInferenceCallsRequest {
    agentRunId: bigint;
    pagination?: PaginationRequest | undefined;
}
export interface ListAgentRunInferenceCallsResponse {
    calls: ChatInferenceCall[];
    pagination?: PaginationResponse | undefined;
}
/**
 * GetAgentRunStatus returns the authoritative run status for thread locations of one
 * channel. Any channel reader may call it, including read-only organization readers.
 */
export interface GetAgentRunStatusRequest {
    channelId: bigint;
    /** Thread roots to report (0 = main timeline). Empty means the main timeline. At most chat_agent_run_status_max_locations (default 50). */
    parentMessageIds: bigint[];
    /** Older runs to include per location besides the latest. At most chat_agent_run_status_max_history (default 10). */
    historyLimit: number;
    /**
     * Append delegated child-session threads, deduplicated against parent_message_ids,
     * up to chat_agent_run_status_max_locations; active runs come first, then newest children.
     */
    includeDelegatedThreads: boolean;
}
/**
 * ListChannelAgentSessions returns the agent sessions bound to one channel, including
 * delegated child sessions. Any channel reader may call it. At most chat_agent_sessions_by_channel_max sessions (default 200).
 */
export interface ListChannelAgentSessionsRequest {
    channelId: bigint;
}
export interface ListChannelAgentSessionsResponse {
    sessions: AgentSessionSummary[];
    /** Server clock when this snapshot was read. */
    serverTime?: Date | undefined;
}
export interface GetAgentRunStatusResponse {
    threads: ThreadAgentRunStatus[];
    /** Server clock when this snapshot was read. */
    serverTime?: Date | undefined;
    /**
     * With include_delegated_threads: at least one delegated child thread with an active run is in
     * neither parent_message_ids nor the appended threads (the request left no room, or more
     * children are active than fit). Clients that count active children treat their count as a
     * lower bound and ask again naming fewer threads, so the server can append the active ones.
     */
    activeDelegatedThreadsIncomplete: boolean;
}
/**
 * StopAgentRun stops one active run of a session whose policy allows user Stop and suspends the
 * session until Resume. Naming the run keeps a stale client from stopping a newer run.
 */
export interface StopAgentRunRequest {
    agentRunId: bigint;
}
export interface StopAgentRunResponse {
    interaction?: AgentSessionInteraction | undefined;
}
/**
 * ResumeAgentSession lifts a suspension. Input held while suspended starts one new run; the
 * stopped run is not restarted.
 */
export interface ResumeAgentSessionRequest {
    agentSessionId: bigint;
}
export interface ResumeAgentSessionResponse {
    interaction?: AgentSessionInteraction | undefined;
    /** the run Resume started, if any */
    agentRunId?: bigint | undefined;
}
/**
 * ListAgentQueuedInputs pages one agent session's queue, oldest first, independent of transcript
 * pages. Anyone who can read the conversation may call it and sees everyone's queued input.
 * Paging is by cursor only (page must be 0 or 1); a page holds at most
 * chat_agent_max_pending_inputs entries.
 */
export interface ListAgentQueuedInputsRequest {
    agentSessionId: bigint;
    /** cursor: the previous page's next_cursor; 0 starts at the oldest */
    pagination?: PaginationRequest | undefined;
}
export interface ListAgentQueuedInputsResponse {
    queuedInputs: AgentQueuedInput[];
    pagination?: PaginationResponse | undefined;
}
/**
 * EditAgentQueuedInput rewords a queued input before the agent receives it. Only its sender may
 * edit it while participating in a non-archived channel, subject to application authorization.
 * attachments replaces the whole list (an attachment left out is removed); embeds and the
 * reply target are kept. It fails with 409 once the input is no longer queued (delivered, removed
 * or discarded) or the channel is archived.
 */
export interface EditAgentQueuedInputRequest {
    queuedInputId: bigint;
    content: string;
    attachments: AttachmentMetadata[];
}
export interface EditAgentQueuedInputResponse {
    queuedInput?: AgentQueuedInput | undefined;
    /** Upload instructions for the attachments the edit added. */
    newAttachments: AttachmentUploadInfo[];
}
/**
 * RemoveAgentQueuedInput withdraws a queued input before the agent receives it. Its sender and the
 * channel's admins may remove it while participating, subject to application authorization.
 * It fails with 409 once the input is no longer queued (delivered,
 * removed or discarded) or the channel is archived.
 */
export interface RemoveAgentQueuedInputRequest {
    queuedInputId: bigint;
}
export interface RemoveAgentQueuedInputResponse {
}
/**
 * GetMessageInferenceSummary returns derived usage for one assistant/compaction
 * message by aggregating linked ledger rows. Derived data, not stored on Message.
 */
export interface GetMessageInferenceSummaryRequest {
    messageId: bigint;
}
export interface GetMessageInferenceSummaryResponse {
    summary?: MessageInferenceSummary | undefined;
}
/**
 * BatchGetMessageInferenceSummaries returns derived summaries for a bounded set
 * of message IDs in one request, so token badges do not issue one HTTP call per
 * visible assistant message. Each summary includes its message_id; omitted IDs
 * mean no ledger rows or no visible/authorized message.
 */
export interface BatchGetMessageInferenceSummariesRequest {
    channelId: bigint;
    messageIds: bigint[];
}
export interface BatchGetMessageInferenceSummariesResponse {
    summaries: MessageInferenceSummary[];
}
export declare const CreateChannelRequest: MessageFns<CreateChannelRequest>;
export declare const CreateChannelResponse: MessageFns<CreateChannelResponse>;
export declare const ForkChannelRequest: MessageFns<ForkChannelRequest>;
export declare const ForkChannelResponse: MessageFns<ForkChannelResponse>;
export declare const GetOrCreateChannelByMembersUniqueRequest: MessageFns<GetOrCreateChannelByMembersUniqueRequest>;
export declare const GetOrCreateChannelByMembersUniqueResponse: MessageFns<GetOrCreateChannelByMembersUniqueResponse>;
export declare const GetChannelRequest: MessageFns<GetChannelRequest>;
export declare const GetChannelResponse: MessageFns<GetChannelResponse>;
export declare const SetChannelPublicReadRequest: MessageFns<SetChannelPublicReadRequest>;
export declare const SetChannelPublicReadResponse: MessageFns<SetChannelPublicReadResponse>;
export declare const GetPublicChannelRequest: MessageFns<GetPublicChannelRequest>;
export declare const GetPublicChannelResponse: MessageFns<GetPublicChannelResponse>;
export declare const ListPublicMessagesRequest: MessageFns<ListPublicMessagesRequest>;
export declare const ListPublicMessagesResponse: MessageFns<ListPublicMessagesResponse>;
export declare const UpdateChannelRequest: MessageFns<UpdateChannelRequest>;
export declare const UpdateChannelResponse: MessageFns<UpdateChannelResponse>;
export declare const ListChannelsRequest: MessageFns<ListChannelsRequest>;
export declare const ListChannelsResponse: MessageFns<ListChannelsResponse>;
export declare const LeaveChannelRequest: MessageFns<LeaveChannelRequest>;
export declare const LeaveChannelResponse: MessageFns<LeaveChannelResponse>;
export declare const AddParticipantsRequest: MessageFns<AddParticipantsRequest>;
export declare const AddParticipantsResponse: MessageFns<AddParticipantsResponse>;
export declare const RemoveParticipantRequest: MessageFns<RemoveParticipantRequest>;
export declare const RemoveParticipantResponse: MessageFns<RemoveParticipantResponse>;
export declare const UpdateParticipantRoleRequest: MessageFns<UpdateParticipantRoleRequest>;
export declare const UpdateParticipantRoleResponse: MessageFns<UpdateParticipantRoleResponse>;
export declare const UpdateParticipantPreferencesRequest: MessageFns<UpdateParticipantPreferencesRequest>;
export declare const UpdateParticipantPreferencesResponse: MessageFns<UpdateParticipantPreferencesResponse>;
export declare const ListParticipantsRequest: MessageFns<ListParticipantsRequest>;
export declare const ListParticipantsResponse: MessageFns<ListParticipantsResponse>;
export declare const ListParticipantsBatchRequest: MessageFns<ListParticipantsBatchRequest>;
export declare const ChannelParticipantsBatchItem: MessageFns<ChannelParticipantsBatchItem>;
export declare const ListParticipantsBatchResponse: MessageFns<ListParticipantsBatchResponse>;
export declare const CreateMessageEmbedRequest: MessageFns<CreateMessageEmbedRequest>;
export declare const SendMessageRequest: MessageFns<SendMessageRequest>;
export declare const SendMessageResponse: MessageFns<SendMessageResponse>;
export declare const EditMessageRequest: MessageFns<EditMessageRequest>;
export declare const EditMessageResponse: MessageFns<EditMessageResponse>;
export declare const DeleteMessageRequest: MessageFns<DeleteMessageRequest>;
export declare const DeleteMessageResponse: MessageFns<DeleteMessageResponse>;
export declare const GetMessageRequest: MessageFns<GetMessageRequest>;
export declare const GetMessageResponse: MessageFns<GetMessageResponse>;
export declare const BatchGetMessagesRequest: MessageFns<BatchGetMessagesRequest>;
export declare const BatchGetMessagesResponse: MessageFns<BatchGetMessagesResponse>;
export declare const ListMessagesRequest: MessageFns<ListMessagesRequest>;
export declare const ListMessagesResponse: MessageFns<ListMessagesResponse>;
export declare const ListMessageEditHistoryRequest: MessageFns<ListMessageEditHistoryRequest>;
export declare const ListMessageEditHistoryResponse: MessageFns<ListMessageEditHistoryResponse>;
export declare const AddReactionRequest: MessageFns<AddReactionRequest>;
export declare const AddReactionResponse: MessageFns<AddReactionResponse>;
export declare const RemoveReactionRequest: MessageFns<RemoveReactionRequest>;
export declare const RemoveReactionResponse: MessageFns<RemoveReactionResponse>;
export declare const ListReactionsRequest: MessageFns<ListReactionsRequest>;
export declare const ListReactionsResponse: MessageFns<ListReactionsResponse>;
export declare const ResolveToolCallRequest: MessageFns<ResolveToolCallRequest>;
export declare const ResolveToolCallResponse: MessageFns<ResolveToolCallResponse>;
export declare const GetChatInferenceTotalsRequest: MessageFns<GetChatInferenceTotalsRequest>;
export declare const GetChatInferenceTotalsResponse: MessageFns<GetChatInferenceTotalsResponse>;
export declare const GetAgentSessionUsageRequest: MessageFns<GetAgentSessionUsageRequest>;
export declare const GetAgentSessionUsageResponse: MessageFns<GetAgentSessionUsageResponse>;
export declare const ListAgentRunInferenceCallsRequest: MessageFns<ListAgentRunInferenceCallsRequest>;
export declare const ListAgentRunInferenceCallsResponse: MessageFns<ListAgentRunInferenceCallsResponse>;
export declare const GetAgentRunStatusRequest: MessageFns<GetAgentRunStatusRequest>;
export declare const ListChannelAgentSessionsRequest: MessageFns<ListChannelAgentSessionsRequest>;
export declare const ListChannelAgentSessionsResponse: MessageFns<ListChannelAgentSessionsResponse>;
export declare const GetAgentRunStatusResponse: MessageFns<GetAgentRunStatusResponse>;
export declare const StopAgentRunRequest: MessageFns<StopAgentRunRequest>;
export declare const StopAgentRunResponse: MessageFns<StopAgentRunResponse>;
export declare const ResumeAgentSessionRequest: MessageFns<ResumeAgentSessionRequest>;
export declare const ResumeAgentSessionResponse: MessageFns<ResumeAgentSessionResponse>;
export declare const ListAgentQueuedInputsRequest: MessageFns<ListAgentQueuedInputsRequest>;
export declare const ListAgentQueuedInputsResponse: MessageFns<ListAgentQueuedInputsResponse>;
export declare const EditAgentQueuedInputRequest: MessageFns<EditAgentQueuedInputRequest>;
export declare const EditAgentQueuedInputResponse: MessageFns<EditAgentQueuedInputResponse>;
export declare const RemoveAgentQueuedInputRequest: MessageFns<RemoveAgentQueuedInputRequest>;
export declare const RemoveAgentQueuedInputResponse: MessageFns<RemoveAgentQueuedInputResponse>;
export declare const GetMessageInferenceSummaryRequest: MessageFns<GetMessageInferenceSummaryRequest>;
export declare const GetMessageInferenceSummaryResponse: MessageFns<GetMessageInferenceSummaryResponse>;
export declare const BatchGetMessageInferenceSummariesRequest: MessageFns<BatchGetMessageInferenceSummariesRequest>;
export declare const BatchGetMessageInferenceSummariesResponse: MessageFns<BatchGetMessageInferenceSummariesResponse>;
type Builtin = Date | Function | Uint8Array | string | number | boolean | bigint | undefined;
type DeepPartial<T> = T extends bigint ? string | number | bigint : T extends Builtin ? T : T extends globalThis.Array<infer U> ? globalThis.Array<DeepPartial<U>> : T extends ReadonlyArray<infer U> ? ReadonlyArray<DeepPartial<U>> : T extends {} ? {
    [K in keyof T]?: DeepPartial<T[K]>;
} : Partial<T>;
type KeysOfUnion<T> = T extends T ? keyof T : never;
type Exact<P, I extends P> = P extends Builtin ? P : P & {
    [K in keyof P]: Exact<P[K], I[K]>;
} & {
    [K in Exclude<keyof I, KeysOfUnion<P>>]: never;
};
interface MessageFns<T> {
    encode(message: T, writer?: BinaryWriter): BinaryWriter;
    decode(input: BinaryReader | Uint8Array, length?: number): T;
    fromJSON(object: any): T;
    toJSON(message: T): unknown;
    create<I extends Exact<DeepPartial<T>, I>>(base?: I): T;
    fromPartial<I extends Exact<DeepPartial<T>, I>>(object: I): T;
}
export {};
//# sourceMappingURL=chat_api.d.ts.map