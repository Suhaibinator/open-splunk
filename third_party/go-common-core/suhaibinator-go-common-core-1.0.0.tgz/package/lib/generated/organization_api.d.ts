import { BinaryReader, BinaryWriter } from "@bufbuild/protobuf/wire";
import { Organization, OrganizationEmailDomain, OrganizationInvitation, OrganizationMemberDetails, OrganizationMembershipMaskFilter, OrganizationRole, OrganizationType, OrganizationUser, OrganizationWithUserRole } from "./organization";
import { FilterRequest, PaginationRequest, PaginationResponse, SortRequest } from "./pagination";
import { UserIdentifierType } from "./user";
export declare enum ListOrganizationsSortBy {
    LIST_ORGANIZATIONS_SORT_BY_UNSPECIFIED = 0,
    LIST_ORGANIZATIONS_SORT_BY_NAME = 1,
    LIST_ORGANIZATIONS_SORT_BY_SLUG = 2,
    LIST_ORGANIZATIONS_SORT_BY_ORGANIZATION_TYPE = 3,
    LIST_ORGANIZATIONS_SORT_BY_CREATED_AT = 4,
    LIST_ORGANIZATIONS_SORT_BY_UPDATED_AT = 5,
    LIST_ORGANIZATIONS_SORT_BY_JOINED_AT = 6,
    UNRECOGNIZED = -1
}
export declare function listOrganizationsSortByFromJSON(object: any): ListOrganizationsSortBy;
export declare function listOrganizationsSortByToJSON(object: ListOrganizationsSortBy): string;
export declare enum AdminListAllOrganizationsSortBy {
    ADMIN_LIST_ALL_ORGANIZATIONS_SORT_BY_UNSPECIFIED = 0,
    ADMIN_LIST_ALL_ORGANIZATIONS_SORT_BY_NAME = 1,
    ADMIN_LIST_ALL_ORGANIZATIONS_SORT_BY_SLUG = 2,
    ADMIN_LIST_ALL_ORGANIZATIONS_SORT_BY_ORGANIZATION_TYPE = 3,
    ADMIN_LIST_ALL_ORGANIZATIONS_SORT_BY_CREATED_AT = 4,
    ADMIN_LIST_ALL_ORGANIZATIONS_SORT_BY_UPDATED_AT = 5,
    UNRECOGNIZED = -1
}
export declare function adminListAllOrganizationsSortByFromJSON(object: any): AdminListAllOrganizationsSortBy;
export declare function adminListAllOrganizationsSortByToJSON(object: AdminListAllOrganizationsSortBy): string;
export interface CreateOrganizationRequest {
    name: string;
    /** URL-friendly organization identifier */
    slug: string;
    description?: string | undefined;
    /** URL to the organization's avatar/logo */
    avatarUrl?: string | undefined;
    parentOrganizationId?: bigint | undefined;
}
export interface CreateOrganizationResponse {
    organization?: Organization | undefined;
}
export interface AdminCreateOrganizationRequest {
    name: string;
    /** URL-friendly organization identifier */
    slug: string;
    description?: string | undefined;
    /** URL to the organization's avatar/logo */
    avatarUrl?: string | undefined;
    parentOrganizationId?: bigint | undefined;
    /** Defaults when omitted */
    organizationType?: OrganizationType | undefined;
}
export interface AdminCreateOrganizationResponse {
    organization?: Organization | undefined;
}
export interface GetOrganizationRequest {
    organizationId: bigint;
}
export interface GetOrganizationResponse {
    organization?: Organization | undefined;
}
export interface GetOrganizationBySlugRequest {
    slug: string;
}
export interface GetOrganizationBySlugResponse {
    organization?: Organization | undefined;
}
/**
 * Request to get the authenticated user's role in an organization by id or slug.
 * Exactly one identifier should be provided.
 */
export interface GetMyOrganizationRoleRequest {
    organizationId?: bigint | undefined;
    slug?: string | undefined;
}
/** Response containing the authenticated user's role in the organization. */
export interface GetMyOrganizationRoleResponse {
    explicitRole: OrganizationRole;
    inheritedFromOrganizationId?: bigint | undefined;
    effectiveRole: OrganizationRole;
    /** Absolute depth of org that supplied effective_role (0=root) */
    effectiveRoleDepth?: number | undefined;
}
export interface UpdateOrganizationRequest {
    organizationId: bigint;
    name: string;
    /** URL-friendly organization identifier */
    slug: string;
    description?: string | undefined;
    /** URL to the organization's avatar/logo */
    avatarUrl?: string | undefined;
}
export interface UpdateOrganizationResponse {
    organization?: Organization | undefined;
}
export interface DeleteOrganizationRequest {
    organizationId: bigint;
}
export interface DeleteOrganizationResponse {
}
export interface AddUserToOrganizationRequest {
    organizationId: bigint;
    userId: bigint;
    role: OrganizationRole;
}
/**
 * Add a user to an organization by identifier (email or username).
 * This is the direct add flow:
 * - If the user exists, they are added immediately (no acceptance needed).
 * - If the user does not exist, a pending auto-add entry is created and will be applied when they register.
 */
export interface AddUserToOrganizationByIdentifierRequest {
    organizationId: bigint;
    /** Must be EMAIL or USERNAME */
    identifierType: UserIdentifierType;
    /** Email address or username */
    identifier: string;
    /** Role to assign upon joining */
    role: OrganizationRole;
}
/** Response for direct add by identifier. */
export interface AddUserToOrganizationByIdentifierResponse {
    /** True if user was added immediately */
    userAdded: boolean;
    /** True if a pending auto-add entry was created */
    autoAddPending: boolean;
    /** Membership details if user_added is true */
    organizationUser?: OrganizationUser | undefined;
    /** Pending auto-add entry if user does not yet exist */
    autoAddEntry?: OrganizationInvitation | undefined;
}
export interface AddUserToOrganizationResponse {
    organizationUser?: OrganizationUser | undefined;
}
export interface RemoveUserFromOrganizationRequest {
    organizationId: bigint;
    userId: bigint;
}
export interface RemoveUserFromOrganizationResponse {
}
export interface UpdateUserRoleInOrganizationRequest {
    organizationId: bigint;
    userId: bigint;
    role: OrganizationRole;
}
export interface UpdateUserRoleInOrganizationResponse {
    organizationUser?: OrganizationUser | undefined;
}
export interface ListOrganizationUsersRequest {
    organizationId: bigint;
    /** Standard pagination parameters */
    pagination?: PaginationRequest | undefined;
}
export interface ListOrganizationUsersResponse {
    /** Enriched member data with user profile info */
    members: OrganizationMemberDetails[];
    /** Standard pagination metadata */
    pagination?: PaginationResponse | undefined;
}
export interface ListOrganizationsRequest {
    pagination?: PaginationRequest | undefined;
    sort?: SortRequest | undefined;
    /** Optional filtering parameters */
    filter?: FilterRequest | undefined;
    sortBy: ListOrganizationsSortBy;
    organizationMembershipMaskFilters: OrganizationMembershipMaskFilter[];
    /** ORGANIZATION_TYPE_UNSPECIFIED means no filter */
    organizationTypeFilter: OrganizationType;
    parentOrganizationIdFilter?: bigint | undefined;
    depthFilter?: number | undefined;
}
export interface ListOrganizationsResponse {
    organizations: OrganizationWithUserRole[];
    /** Standard pagination metadata */
    pagination?: PaginationResponse | undefined;
}
export interface AdminListAllOrganizationsRequest {
    /** Standard pagination parameters */
    pagination?: PaginationRequest | undefined;
    /** Optional sorting parameters */
    sort?: SortRequest | undefined;
    /** Optional filtering parameters */
    filter?: FilterRequest | undefined;
    /** ORGANIZATION_TYPE_UNSPECIFIED means no filter */
    organizationTypeFilter: OrganizationType;
    sortBy: AdminListAllOrganizationsSortBy;
    parentOrganizationIdFilter?: bigint | undefined;
    depthFilter?: number | undefined;
}
export interface AdminListAllOrganizationsResponse {
    organizations: Organization[];
    /** Standard pagination metadata */
    pagination?: PaginationResponse | undefined;
    /** Parents referenced by this page only */
    parentOptions: AdminOrganizationParentOption[];
}
export interface AdminOrganizationParentOption {
    id: bigint;
    name: string;
    slug: string;
}
export interface AdminListAllOrganizationsFilterMetadataRequest {
    /** Optional filtering parameters */
    filter?: FilterRequest | undefined;
    /** ORGANIZATION_TYPE_UNSPECIFIED means no filter */
    organizationTypeFilter: OrganizationType;
}
export interface AdminListAllOrganizationsFilterMetadataResponse {
    maxDepth: number;
}
export interface AdminListOrganizationParentOptionsRequest {
    /** Page/limit; limit defaults to and may not exceed organization_parent_options_max_limit */
    pagination?: PaginationRequest | undefined;
    /** Search parent organization name or slug */
    filter?: FilterRequest | undefined;
    /** Current organization-table filters */
    tableFilter?: FilterRequest | undefined;
    /** Current organization-table type filter */
    organizationTypeFilter: OrganizationType;
}
export interface AdminListOrganizationParentOptionsResponse {
    parentOptions: AdminOrganizationParentOption[];
    hasMore: boolean;
}
export interface AdminChangeOrganizationTypeRequest {
    organizationId: bigint;
    newOrganizationType: OrganizationType;
    /** Reason for change */
    reason: string;
}
export interface AdminChangeOrganizationTypeResponse {
}
/** List organizations by parent organization (null/empty for roots). */
export interface ListOrganizationsByParentRequest {
    parentOrganizationId?: bigint | undefined;
    /** Standard pagination parameters */
    pagination?: PaginationRequest | undefined;
}
export interface ListOrganizationsByParentResponse {
    organizations: Organization[];
    /** Standard pagination metadata */
    pagination?: PaginationResponse | undefined;
}
/** Hierarchy node used for tree responses. */
export interface OrganizationHierarchyNode {
    organization?: Organization | undefined;
    children: OrganizationHierarchyNode[];
}
export interface GetOrganizationHierarchyRequest {
    organizationId: bigint;
    includeDescendants: boolean;
    /** Pages immediate children when include_descendants is false */
    pagination?: PaginationRequest | undefined;
}
export interface GetOrganizationHierarchyResponse {
    hierarchy?: OrganizationHierarchyNode | undefined;
    /** Immediate-child pagination; omitted for full descendants */
    pagination?: PaginationResponse | undefined;
    /** True when more children/nodes are available */
    truncated: boolean;
}
export interface GetOrganizationMemberRequest {
    organizationId: bigint;
    userId: bigint;
}
export interface GetOrganizationMemberResponse {
    memberDetails?: OrganizationMemberDetails | undefined;
}
export interface CreateOrganizationEmailDomainRequest {
    organizationId: bigint;
    domain: string;
}
export interface CreateOrganizationEmailDomainResponse {
    emailDomain?: OrganizationEmailDomain | undefined;
}
export interface DeleteOrganizationEmailDomainRequest {
    organizationId: bigint;
    organizationEmailDomainId: bigint;
}
export interface DeleteOrganizationEmailDomainResponse {
}
export interface ListOrganizationEmailDomainsRequest {
    organizationId: bigint;
    pagination?: PaginationRequest | undefined;
}
export interface ListOrganizationEmailDomainsResponse {
    emailDomains: OrganizationEmailDomain[];
    pagination?: PaginationResponse | undefined;
}
/**
 * Request to invite a user to an organization by email or username.
 * Existing users receive an invitation requiring acceptance. For an unknown
 * email, the invitation remains pending and can be accepted after registration.
 */
export interface InviteUserToOrganizationRequest {
    organizationId: bigint;
    /** Must be EMAIL or USERNAME */
    identifierType: UserIdentifierType;
    /** Email address or username */
    identifier: string;
    /** Role to assign upon joining */
    role: OrganizationRole;
}
/** Response from an invitation request. */
export interface InviteUserToOrganizationResponse {
    /** ID of the created invitation */
    invitationId: bigint;
}
/**
 * Request to list pending invitations for the authenticated user.
 * Uses the authenticated user's email to find matching invitations.
 */
export interface ListPendingInvitationsRequest {
    pagination?: PaginationRequest | undefined;
}
/** Response containing pending invitations for the user. */
export interface ListPendingInvitationsResponse {
    invitations: OrganizationInvitation[];
    pagination?: PaginationResponse | undefined;
}
/** Request to accept an organization invitation. */
export interface AcceptInvitationRequest {
    invitationId: bigint;
}
/** Response after accepting an invitation. */
export interface AcceptInvitationResponse {
    /** The newly created membership */
    organizationUser?: OrganizationUser | undefined;
}
/** Request to decline an organization invitation. */
export interface DeclineInvitationRequest {
    invitationId: bigint;
}
/** Response after declining an invitation. */
export interface DeclineInvitationResponse {
}
/**
 * Request to cancel a pending invitation (admin action).
 * Requires the configured CancelInvitation permission (organization role or site
 * user type) and organization capability; it does not reuse InviteMembers.
 */
export interface CancelInvitationRequest {
    organizationId: bigint;
    invitationId: bigint;
}
/** Response after cancelling an invitation. */
export interface CancelInvitationResponse {
}
/**
 * Request to list pending invitations sent by the organization.
 * Used by org admins to view and manage outgoing invitations.
 */
export interface ListOrganizationInvitationsRequest {
    organizationId: bigint;
    pagination?: PaginationRequest | undefined;
}
/** Response containing pending invitations sent by the organization. */
export interface ListOrganizationInvitationsResponse {
    invitations: OrganizationInvitation[];
    pagination?: PaginationResponse | undefined;
}
/** Request to check if an organization slug is available. */
export interface CheckOrganizationSlugAvailabilityRequest {
    /** The slug to check for availability. */
    slug: string;
}
/** Response indicating whether the organization slug is available. */
export interface CheckOrganizationSlugAvailabilityResponse {
    /** Whether the slug is available for use. */
    available: boolean;
    /** Optional message providing additional context (e.g., "Slug already taken", "Slug is reserved"). */
    message: string;
}
/**
 * Complete-access subtree pages for admin deletion previews. The root is excluded.
 * Pages are ordered by organization ID; pass the last returned ID as the cursor.
 */
export interface AdminGetOrganizationDeletionImpactRequest {
    organizationId: bigint;
    afterOrganizationId: bigint;
    /** 0 or above max_pagination_limit (default 100) is clamped to it. */
    limit: number;
}
export interface AdminGetOrganizationDeletionImpactResponse {
    organizations: Organization[];
    hasMore: boolean;
}
export declare const CreateOrganizationRequest: MessageFns<CreateOrganizationRequest>;
export declare const CreateOrganizationResponse: MessageFns<CreateOrganizationResponse>;
export declare const AdminCreateOrganizationRequest: MessageFns<AdminCreateOrganizationRequest>;
export declare const AdminCreateOrganizationResponse: MessageFns<AdminCreateOrganizationResponse>;
export declare const GetOrganizationRequest: MessageFns<GetOrganizationRequest>;
export declare const GetOrganizationResponse: MessageFns<GetOrganizationResponse>;
export declare const GetOrganizationBySlugRequest: MessageFns<GetOrganizationBySlugRequest>;
export declare const GetOrganizationBySlugResponse: MessageFns<GetOrganizationBySlugResponse>;
export declare const GetMyOrganizationRoleRequest: MessageFns<GetMyOrganizationRoleRequest>;
export declare const GetMyOrganizationRoleResponse: MessageFns<GetMyOrganizationRoleResponse>;
export declare const UpdateOrganizationRequest: MessageFns<UpdateOrganizationRequest>;
export declare const UpdateOrganizationResponse: MessageFns<UpdateOrganizationResponse>;
export declare const DeleteOrganizationRequest: MessageFns<DeleteOrganizationRequest>;
export declare const DeleteOrganizationResponse: MessageFns<DeleteOrganizationResponse>;
export declare const AddUserToOrganizationRequest: MessageFns<AddUserToOrganizationRequest>;
export declare const AddUserToOrganizationByIdentifierRequest: MessageFns<AddUserToOrganizationByIdentifierRequest>;
export declare const AddUserToOrganizationByIdentifierResponse: MessageFns<AddUserToOrganizationByIdentifierResponse>;
export declare const AddUserToOrganizationResponse: MessageFns<AddUserToOrganizationResponse>;
export declare const RemoveUserFromOrganizationRequest: MessageFns<RemoveUserFromOrganizationRequest>;
export declare const RemoveUserFromOrganizationResponse: MessageFns<RemoveUserFromOrganizationResponse>;
export declare const UpdateUserRoleInOrganizationRequest: MessageFns<UpdateUserRoleInOrganizationRequest>;
export declare const UpdateUserRoleInOrganizationResponse: MessageFns<UpdateUserRoleInOrganizationResponse>;
export declare const ListOrganizationUsersRequest: MessageFns<ListOrganizationUsersRequest>;
export declare const ListOrganizationUsersResponse: MessageFns<ListOrganizationUsersResponse>;
export declare const ListOrganizationsRequest: MessageFns<ListOrganizationsRequest>;
export declare const ListOrganizationsResponse: MessageFns<ListOrganizationsResponse>;
export declare const AdminListAllOrganizationsRequest: MessageFns<AdminListAllOrganizationsRequest>;
export declare const AdminListAllOrganizationsResponse: MessageFns<AdminListAllOrganizationsResponse>;
export declare const AdminOrganizationParentOption: MessageFns<AdminOrganizationParentOption>;
export declare const AdminListAllOrganizationsFilterMetadataRequest: MessageFns<AdminListAllOrganizationsFilterMetadataRequest>;
export declare const AdminListAllOrganizationsFilterMetadataResponse: MessageFns<AdminListAllOrganizationsFilterMetadataResponse>;
export declare const AdminListOrganizationParentOptionsRequest: MessageFns<AdminListOrganizationParentOptionsRequest>;
export declare const AdminListOrganizationParentOptionsResponse: MessageFns<AdminListOrganizationParentOptionsResponse>;
export declare const AdminChangeOrganizationTypeRequest: MessageFns<AdminChangeOrganizationTypeRequest>;
export declare const AdminChangeOrganizationTypeResponse: MessageFns<AdminChangeOrganizationTypeResponse>;
export declare const ListOrganizationsByParentRequest: MessageFns<ListOrganizationsByParentRequest>;
export declare const ListOrganizationsByParentResponse: MessageFns<ListOrganizationsByParentResponse>;
export declare const OrganizationHierarchyNode: MessageFns<OrganizationHierarchyNode>;
export declare const GetOrganizationHierarchyRequest: MessageFns<GetOrganizationHierarchyRequest>;
export declare const GetOrganizationHierarchyResponse: MessageFns<GetOrganizationHierarchyResponse>;
export declare const GetOrganizationMemberRequest: MessageFns<GetOrganizationMemberRequest>;
export declare const GetOrganizationMemberResponse: MessageFns<GetOrganizationMemberResponse>;
export declare const CreateOrganizationEmailDomainRequest: MessageFns<CreateOrganizationEmailDomainRequest>;
export declare const CreateOrganizationEmailDomainResponse: MessageFns<CreateOrganizationEmailDomainResponse>;
export declare const DeleteOrganizationEmailDomainRequest: MessageFns<DeleteOrganizationEmailDomainRequest>;
export declare const DeleteOrganizationEmailDomainResponse: MessageFns<DeleteOrganizationEmailDomainResponse>;
export declare const ListOrganizationEmailDomainsRequest: MessageFns<ListOrganizationEmailDomainsRequest>;
export declare const ListOrganizationEmailDomainsResponse: MessageFns<ListOrganizationEmailDomainsResponse>;
export declare const InviteUserToOrganizationRequest: MessageFns<InviteUserToOrganizationRequest>;
export declare const InviteUserToOrganizationResponse: MessageFns<InviteUserToOrganizationResponse>;
export declare const ListPendingInvitationsRequest: MessageFns<ListPendingInvitationsRequest>;
export declare const ListPendingInvitationsResponse: MessageFns<ListPendingInvitationsResponse>;
export declare const AcceptInvitationRequest: MessageFns<AcceptInvitationRequest>;
export declare const AcceptInvitationResponse: MessageFns<AcceptInvitationResponse>;
export declare const DeclineInvitationRequest: MessageFns<DeclineInvitationRequest>;
export declare const DeclineInvitationResponse: MessageFns<DeclineInvitationResponse>;
export declare const CancelInvitationRequest: MessageFns<CancelInvitationRequest>;
export declare const CancelInvitationResponse: MessageFns<CancelInvitationResponse>;
export declare const ListOrganizationInvitationsRequest: MessageFns<ListOrganizationInvitationsRequest>;
export declare const ListOrganizationInvitationsResponse: MessageFns<ListOrganizationInvitationsResponse>;
export declare const CheckOrganizationSlugAvailabilityRequest: MessageFns<CheckOrganizationSlugAvailabilityRequest>;
export declare const CheckOrganizationSlugAvailabilityResponse: MessageFns<CheckOrganizationSlugAvailabilityResponse>;
export declare const AdminGetOrganizationDeletionImpactRequest: MessageFns<AdminGetOrganizationDeletionImpactRequest>;
export declare const AdminGetOrganizationDeletionImpactResponse: MessageFns<AdminGetOrganizationDeletionImpactResponse>;
type Builtin = Date | Function | Uint8Array | string | number | boolean | bigint | undefined;
type DeepPartial<T> = T extends bigint ? string | number | bigint : T extends Builtin ? T : T extends globalThis.Array<infer U> ? globalThis.Array<DeepPartial<U>> : T extends ReadonlyArray<infer U> ? ReadonlyArray<DeepPartial<U>> : T extends {} ? {
    [K in keyof T]?: DeepPartial<T[K]>;
} : Partial<T>;
type KeysOfUnion<T> = T extends T ? keyof T : never;
type Exact<P, I extends P> = P extends Builtin ? P : P & {
    [K in keyof P]: Exact<P[K], I[K]>;
} & {
    [K in Exclude<keyof I, KeysOfUnion<P>>]: never;
};
interface MessageFns<T> {
    encode(message: T, writer?: BinaryWriter): BinaryWriter;
    decode(input: BinaryReader | Uint8Array, length?: number): T;
    fromJSON(object: any): T;
    toJSON(message: T): unknown;
    create<I extends Exact<DeepPartial<T>, I>>(base?: I): T;
    fromPartial<I extends Exact<DeepPartial<T>, I>>(object: I): T;
}
export {};
//# sourceMappingURL=organization_api.d.ts.map