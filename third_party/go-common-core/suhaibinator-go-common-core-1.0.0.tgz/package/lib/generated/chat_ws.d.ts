import { BinaryReader, BinaryWriter } from "@bufbuild/protobuf/wire";
import { AgentRunActivity, Channel, ChannelParticipant, ChatAgentRunStatus, ChatAgentRunStatusReason, ChatEventType, ChatInferenceUsageUpdate, Message, MessageReaction, ToolCallApprovalStatus, ToolCallExecutionState } from "./chat";
import { InferenceUsage } from "./inference_api";
/**
 * ChatWebSocketEvent is chat's realtime payload message: it is serialized into
 * RealtimeEvent.payload (see realtime_ws.proto) and delivered to participant user
 * topics and authorized open-channel realtime subscriptions.
 *
 * Notes:
 * - This is a payload, not a transport envelope. Topic, event type and timestamp
 *   routing metadata live on the surrounding RealtimeEvent.
 * - Payload messages are re-used from chat.proto (Channel/Message/Reaction/etc).
 * - The payload may be partial depending on the event type (e.g. delete events may
 *   omit the full entity and only provide ids).
 */
export interface ChatWebSocketEvent {
    /** High-level event type (created/updated/deleted, reaction added/removed, etc.) */
    type: ChatEventType;
    /** When the event occurred (server time). */
    occurredAt?: Date | undefined;
    /** Actor user ID; 0 when the producer has no user actor. */
    actorUserId: bigint;
    /** Created indicates whether the underlying object was newly created as part of a get-or-create flow. */
    created: boolean;
    /** Member tuple for events where the exact participants are relevant (e.g. unique channel creation). */
    memberUserIds: bigint[];
    /** Optional convenience fields for id-only payloads or routing. */
    channelId: bigint;
    messageId: bigint;
    channel?: Channel | undefined;
    message?: Message | undefined;
    reaction?: MessageReaction | undefined;
    participant?: ChannelParticipant | undefined;
    typing?: TypingEvent | undefined;
    messageStream?: MessageStreamEvent | undefined;
    toolCallResolution?: ToolCallResolutionEvent | undefined;
    contextCompaction?: ContextCompactionEvent | undefined;
    agentRunState?: AgentRunStateEvent | undefined;
    agentSessionInteraction?: AgentSessionInteractionEvent | undefined;
    inferenceUsage?: ChatInferenceUsageUpdate | undefined;
}
/**
 * AgentSessionInteractionEvent says an agent session's interaction state changed
 * (CHAT_EVENT_TYPE_AGENT_SESSION_INTERACTION), published after commit. It carries only the
 * session's identity and location: the interaction depends on the viewer, so a client re-reads it.
 */
export interface AgentSessionInteractionEvent {
    channelId: bigint;
    /** 0 for the channel's main transcript */
    parentMessageId: bigint;
    agentSessionId: bigint;
}
/**
 * AgentRunStateEvent reports one agent run's lifecycle status and observable activity
 * (CHAT_EVENT_TYPE_AGENT_RUN_STATE). Status transitions are published after commit; activity
 * changes are ephemeral and re-published on the run's drive heartbeat. Consumers must scope it
 * by (channel_id, parent_message_id, agent_run_id): activity in one thread says nothing about
 * another.
 */
export interface AgentRunStateEvent {
    channelId: bigint;
    /** 0 for the channel's main transcript */
    parentMessageId: bigint;
    agentRunId: bigint;
    status: ChatAgentRunStatus;
    statusReason: ChatAgentRunStatusReason;
    statusReasonCode: string;
    activity: AgentRunActivity;
    activityStartedAt?: Date | undefined;
    /** TOOL_CALL message behind the activity; omitted when that row is hidden from users. */
    activityMessageId?: bigint | undefined;
}
/**
 * ContextCompactionEvent is the ephemeral "summarizing context" indicator for one agent run
 * (CHAT_EVENT_TYPE_CONTEXT_COMPACTION). active=true when the summary call starts, false when it
 * ends for any reason.
 */
export interface ContextCompactionEvent {
    channelId: bigint;
    /** 0 for the channel's main transcript */
    parentMessageId: bigint;
    agentRunId: bigint;
    active: boolean;
}
/**
 * ToolCallResolutionEvent is fanned out (server -> client) when a TOOL_CALL's
 * approval state transitions, so every session can patch the cached TOOL_CALL
 * message in place without a refetch (CHAT_EVENT_TYPE_TOOL_CALL_RESOLUTION).
 */
export interface ToolCallResolutionEvent {
    messageId: bigint;
    channelId: bigint;
    approvalStatus: ToolCallApprovalStatus;
    /**
     * execution_state lets clients patch the approval/execution card from the
     * event without a refetch (Decision 6 / Known Proto Drift).
     */
    executionState: ToolCallExecutionState;
    resolvedByUserId: bigint;
    resolvedAt?: Date | undefined;
    resolutionReason: string;
}
export interface MessageStreamEvent {
    messageId: bigint;
    channelId: bigint;
    streamId: string;
    sequence: bigint;
    textDelta: string;
    accumulatedText: string;
    finalUsage?: InferenceUsage | undefined;
    /**
     * Present on every stream event: zero identifies the channel root; a positive ID
     * identifies the thread. Absence means placement is unknown (older producers).
     */
    parentMessageId?: bigint | undefined;
}
/**
 * TypingCommand indicates the user is typing in a channel. It is chat's payload for
 * the "chat.typing" RealtimeCommand (see realtime_ws.proto).
 */
export interface TypingCommand {
    /** Channel where the user is typing. */
    channelId: bigint;
    /** Whether the user started (true) or stopped (false) typing. */
    isTyping: boolean;
}
/**
 * TypingEvent indicates a user is typing in a channel.
 * The typing user's ID is carried in ChatWebSocketEvent.actor_user_id.
 */
export interface TypingEvent {
    /** Channel where the user is typing. */
    channelId: bigint;
    /** Whether the user started (true) or stopped (false) typing. */
    isTyping: boolean;
}
export declare const ChatWebSocketEvent: MessageFns<ChatWebSocketEvent>;
export declare const AgentSessionInteractionEvent: MessageFns<AgentSessionInteractionEvent>;
export declare const AgentRunStateEvent: MessageFns<AgentRunStateEvent>;
export declare const ContextCompactionEvent: MessageFns<ContextCompactionEvent>;
export declare const ToolCallResolutionEvent: MessageFns<ToolCallResolutionEvent>;
export declare const MessageStreamEvent: MessageFns<MessageStreamEvent>;
export declare const TypingCommand: MessageFns<TypingCommand>;
export declare const TypingEvent: MessageFns<TypingEvent>;
type Builtin = Date | Function | Uint8Array | string | number | boolean | bigint | undefined;
type DeepPartial<T> = T extends bigint ? string | number | bigint : T extends Builtin ? T : T extends globalThis.Array<infer U> ? globalThis.Array<DeepPartial<U>> : T extends ReadonlyArray<infer U> ? ReadonlyArray<DeepPartial<U>> : T extends {} ? {
    [K in keyof T]?: DeepPartial<T[K]>;
} : Partial<T>;
type KeysOfUnion<T> = T extends T ? keyof T : never;
type Exact<P, I extends P> = P extends Builtin ? P : P & {
    [K in keyof P]: Exact<P[K], I[K]>;
} & {
    [K in Exclude<keyof I, KeysOfUnion<P>>]: never;
};
interface MessageFns<T> {
    encode(message: T, writer?: BinaryWriter): BinaryWriter;
    decode(input: BinaryReader | Uint8Array, length?: number): T;
    fromJSON(object: any): T;
    toJSON(message: T): unknown;
    create<I extends Exact<DeepPartial<T>, I>>(base?: I): T;
    fromPartial<I extends Exact<DeepPartial<T>, I>>(object: I): T;
}
export {};
//# sourceMappingURL=chat_ws.d.ts.map