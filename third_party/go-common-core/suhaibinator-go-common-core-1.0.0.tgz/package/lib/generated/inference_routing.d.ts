import { BinaryReader, BinaryWriter } from "@bufbuild/protobuf/wire";
import { InferenceAPI } from "./inference";
export declare enum InferenceOperationOrgModelChoice {
    INFERENCE_OPERATION_ORG_MODEL_CHOICE_UNSPECIFIED = 0,
    INFERENCE_OPERATION_ORG_MODEL_CHOICE_NEVER = 1,
    INFERENCE_OPERATION_ORG_MODEL_CHOICE_SITE_ADMIN_DECIDES = 2,
    UNRECOGNIZED = -1
}
export declare function inferenceOperationOrgModelChoiceFromJSON(object: any): InferenceOperationOrgModelChoice;
export declare function inferenceOperationOrgModelChoiceToJSON(object: InferenceOperationOrgModelChoice): string;
/**
 * Application gate on moving an existing agent session's pinned model, set per
 * operation in code. UNSPECIFIED is treated as NEVER.
 */
export declare enum InferenceSessionRetarget {
    INFERENCE_SESSION_RETARGET_UNSPECIFIED = 0,
    /** INFERENCE_SESSION_RETARGET_NEVER - No re-targeting of any kind, including site overrides and policy MOVE actions. */
    INFERENCE_SESSION_RETARGET_NEVER = 1,
    /**
     * INFERENCE_SESSION_RETARGET_MANAGERS - Site inference administrators and organization ManageInferencePolicy holders
     * may move sessions; members may not.
     */
    INFERENCE_SESSION_RETARGET_MANAGERS = 2,
    /**
     * INFERENCE_SESSION_RETARGET_ORG_DECIDES - Managers may move sessions; the organization's member_retarget policy
     * decides whether members may move their own.
     */
    INFERENCE_SESSION_RETARGET_ORG_DECIDES = 3,
    UNRECOGNIZED = -1
}
export declare function inferenceSessionRetargetFromJSON(object: any): InferenceSessionRetarget;
export declare function inferenceSessionRetargetToJSON(object: InferenceSessionRetarget): string;
export declare enum InferenceModelPayerEligibility {
    INFERENCE_MODEL_PAYER_ELIGIBILITY_UNSPECIFIED = 0,
    INFERENCE_MODEL_PAYER_ELIGIBILITY_PLATFORM_OR_CONNECTION = 1,
    INFERENCE_MODEL_PAYER_ELIGIBILITY_PLATFORM_ONLY = 2,
    INFERENCE_MODEL_PAYER_ELIGIBILITY_CONNECTION_ONLY = 3,
    UNRECOGNIZED = -1
}
export declare function inferenceModelPayerEligibilityFromJSON(object: any): InferenceModelPayerEligibility;
export declare function inferenceModelPayerEligibilityToJSON(object: InferenceModelPayerEligibility): string;
export declare enum InferenceSelectionSource {
    INFERENCE_SELECTION_SOURCE_UNSPECIFIED = 0,
    INFERENCE_SELECTION_SOURCE_PLATFORM_DEFAULT = 1,
    INFERENCE_SELECTION_SOURCE_ORG_DEFAULT = 2,
    INFERENCE_SELECTION_SOURCE_USER_CHOICE = 3,
    INFERENCE_SELECTION_SOURCE_SITE_OVERRIDE = 4,
    INFERENCE_SELECTION_SOURCE_RETARGET = 5,
    UNRECOGNIZED = -1
}
export declare function inferenceSelectionSourceFromJSON(object: any): InferenceSelectionSource;
export declare function inferenceSelectionSourceToJSON(object: InferenceSelectionSource): string;
export declare enum InferenceBlockReason {
    INFERENCE_BLOCK_REASON_UNSPECIFIED = 0,
    INFERENCE_BLOCK_REASON_MODEL_NOT_IN_OPERATION_LIST = 1,
    INFERENCE_BLOCK_REASON_MODEL_NOT_PERMITTED_BY_ORG = 2,
    INFERENCE_BLOCK_REASON_MEMBER_CHOICE_CLOSED = 3,
    INFERENCE_BLOCK_REASON_PROVIDER_NOT_ALLOWED = 4,
    INFERENCE_BLOCK_REASON_CAPABILITY_MISSING = 5,
    INFERENCE_BLOCK_REASON_BELOW_OPERATION_MINIMUM = 6,
    INFERENCE_BLOCK_REASON_MODEL_UNAVAILABLE = 7,
    INFERENCE_BLOCK_REASON_PROVIDER_UNAVAILABLE = 8,
    INFERENCE_BLOCK_REASON_NO_ELIGIBLE_MODEL = 9,
    INFERENCE_BLOCK_REASON_PAYER_NOT_PERMITTED = 10,
    INFERENCE_BLOCK_REASON_CONNECTION_REQUIRED = 11,
    INFERENCE_BLOCK_REASON_AUTHORITY_REVOKED = 12,
    INFERENCE_BLOCK_REASON_INVALID_MODEL_SETTINGS = 13,
    UNRECOGNIZED = -1
}
export declare function inferenceBlockReasonFromJSON(object: any): InferenceBlockReason;
export declare function inferenceBlockReasonToJSON(object: InferenceBlockReason): string;
export declare enum InferencePolicySessionAction {
    INFERENCE_POLICY_SESSION_ACTION_UNSPECIFIED = 0,
    INFERENCE_POLICY_SESSION_ACTION_KEEP = 1,
    INFERENCE_POLICY_SESSION_ACTION_BLOCK = 2,
    INFERENCE_POLICY_SESSION_ACTION_MOVE = 3,
    UNRECOGNIZED = -1
}
export declare function inferencePolicySessionActionFromJSON(object: any): InferencePolicySessionAction;
export declare function inferencePolicySessionActionToJSON(object: InferencePolicySessionAction): string;
export interface InferenceOperationModelOption {
    inferenceModelId: bigint;
    payerEligibility: InferenceModelPayerEligibility;
}
export interface InferenceOperationModelList {
    operation: number;
    defaultModelId: bigint;
    models: InferenceOperationModelOption[];
    version: bigint;
    orgModelChoice: InferenceOperationOrgModelChoice;
    /** Application re-target gate for the operation; read-only. */
    sessionRetarget: InferenceSessionRetarget;
}
export interface OrganizationInferenceOperationPolicy {
    organizationId: bigint;
    operation: number;
    inferenceModelIds: bigint[];
    defaultModelId?: bigint | undefined;
    memberChoice: boolean;
    version: bigint;
    parked: boolean;
    blockReason: InferenceBlockReason;
    effectiveModels: InferenceModelChoice[];
    /**
     * Site-listed models the organization may narrow to, before its own narrowing
     * and provider allowlists: active, provider configured, platform-payable.
     * is_default marks the platform default. Lets editors re-add removed models.
     */
    availableModels: InferenceModelChoice[];
    /**
     * True when the application opened this operation to organizations and the
     * site list has more than one model. False means locked; stored preferences
     * are then parked and do not apply.
     */
    choiceOpen: boolean;
    /**
     * Stored organization preference letting members move their own sessions.
     * Applies only when session_retarget is ORG_DECIDES; otherwise it is parked.
     */
    memberRetarget: boolean;
    /** Application re-target gate for the operation; read-only. */
    sessionRetarget: InferenceSessionRetarget;
}
export interface InferenceProviderSummary {
    id: string;
    displayName: string;
}
export interface OrganizationInferencePolicy {
    organizationId: bigint;
    providerIds: string[];
    version: bigint;
    operations: OrganizationInferenceOperationPolicy[];
    /** Configured providers an organization may name in its provider allowlist. */
    availableProviders: InferenceProviderSummary[];
    /**
     * Intersection of the ancestors' non-empty provider allowlists, sorted.
     * Meaningful only when inherited_provider_restriction is true.
     */
    inheritedProviderIds: string[];
    /** True when any ancestor organization restricts providers. */
    inheritedProviderRestriction: boolean;
}
export interface InferenceModelChoice {
    inferenceModelId: bigint;
    providerId: string;
    providerModelId: string;
    displayName: string;
    api: InferenceAPI;
    isDefault: boolean;
    /**
     * Set in an organization's available_models when an ancestor organization's
     * provider allowlist excludes the model's provider (PROVIDER_NOT_ALLOWED).
     */
    blockReason: InferenceBlockReason;
}
export interface InferencePolicyImpact {
    operation: number;
    blockReason: InferenceBlockReason;
    affectedSessions: bigint;
    sessionCountComplete: boolean;
    parked: boolean;
    /**
     * Models the save removes from the operation's effective list, ascending: the
     * set a BLOCK or MOVE session action applies to. Set on site operation-list and
     * organization operation-policy saves; empty for provider allowlist saves.
     */
    removedModelIds: bigint[];
}
export interface InferencePolicyPreview {
    impacts: InferencePolicyImpact[];
}
export interface GetInferenceOperationModelsRequest {
    operation: number;
}
export interface GetInferenceOperationModelsResponse {
    modelList?: InferenceOperationModelList | undefined;
}
export interface UpdateInferenceOperationModelsRequest {
    operation: number;
    models: InferenceOperationModelOption[];
    expectedVersion: bigint;
    dryRun: boolean;
    sessionAction: InferencePolicySessionAction;
    moveToModelId?: bigint | undefined;
}
export interface UpdateInferenceOperationModelsResponse {
    modelList?: InferenceOperationModelList | undefined;
    preview?: InferencePolicyPreview | undefined;
}
export interface GetOrganizationInferencePolicyRequest {
    organizationId: bigint;
}
export interface GetOrganizationInferencePolicyResponse {
    policy?: OrganizationInferencePolicy | undefined;
}
export interface UpdateOrganizationInferencePolicyRequest {
    organizationId: bigint;
    providerIds: string[];
    expectedVersion: bigint;
    dryRun: boolean;
}
export interface UpdateOrganizationInferencePolicyResponse {
    policy?: OrganizationInferencePolicy | undefined;
    preview?: InferencePolicyPreview | undefined;
}
export interface UpdateOrganizationInferenceOperationPolicyRequest {
    organizationId: bigint;
    operation: number;
    inferenceModelIds: bigint[];
    defaultModelId?: bigint | undefined;
    memberChoice: boolean;
    expectedVersion: bigint;
    dryRun: boolean;
    sessionAction: InferencePolicySessionAction;
    moveToModelId?: bigint | undefined;
    /** Valid only when the operation's session_retarget gate is ORG_DECIDES. */
    memberRetarget: boolean;
}
export interface UpdateOrganizationInferenceOperationPolicyResponse {
    policy?: OrganizationInferenceOperationPolicy | undefined;
    preview?: InferencePolicyPreview | undefined;
}
export interface ListInferenceModelChoicesRequest {
    organizationId: bigint;
    operation: number;
}
export interface ListInferenceModelChoicesResponse {
    choices: InferenceModelChoice[];
    memberChoice: boolean;
    blockReason: InferenceBlockReason;
    /**
     * True when members may move their own sessions: the gate is ORG_DECIDES, the
     * organization enabled member_retarget, and member choice is open.
     */
    memberRetarget: boolean;
    /** Application re-target gate for the operation. */
    sessionRetarget: InferenceSessionRetarget;
    /**
     * True when the viewer is a re-targeting manager: site inference administration
     * or the organization's ManageInferencePolicy.
     */
    management: boolean;
    /**
     * True when the viewer holds the organization's ChooseInferenceModel. Member
     * pickers offer choices only when member_choice and can_choose are both true.
     */
    canChoose: boolean;
}
export declare const InferenceOperationModelOption: MessageFns<InferenceOperationModelOption>;
export declare const InferenceOperationModelList: MessageFns<InferenceOperationModelList>;
export declare const OrganizationInferenceOperationPolicy: MessageFns<OrganizationInferenceOperationPolicy>;
export declare const InferenceProviderSummary: MessageFns<InferenceProviderSummary>;
export declare const OrganizationInferencePolicy: MessageFns<OrganizationInferencePolicy>;
export declare const InferenceModelChoice: MessageFns<InferenceModelChoice>;
export declare const InferencePolicyImpact: MessageFns<InferencePolicyImpact>;
export declare const InferencePolicyPreview: MessageFns<InferencePolicyPreview>;
export declare const GetInferenceOperationModelsRequest: MessageFns<GetInferenceOperationModelsRequest>;
export declare const GetInferenceOperationModelsResponse: MessageFns<GetInferenceOperationModelsResponse>;
export declare const UpdateInferenceOperationModelsRequest: MessageFns<UpdateInferenceOperationModelsRequest>;
export declare const UpdateInferenceOperationModelsResponse: MessageFns<UpdateInferenceOperationModelsResponse>;
export declare const GetOrganizationInferencePolicyRequest: MessageFns<GetOrganizationInferencePolicyRequest>;
export declare const GetOrganizationInferencePolicyResponse: MessageFns<GetOrganizationInferencePolicyResponse>;
export declare const UpdateOrganizationInferencePolicyRequest: MessageFns<UpdateOrganizationInferencePolicyRequest>;
export declare const UpdateOrganizationInferencePolicyResponse: MessageFns<UpdateOrganizationInferencePolicyResponse>;
export declare const UpdateOrganizationInferenceOperationPolicyRequest: MessageFns<UpdateOrganizationInferenceOperationPolicyRequest>;
export declare const UpdateOrganizationInferenceOperationPolicyResponse: MessageFns<UpdateOrganizationInferenceOperationPolicyResponse>;
export declare const ListInferenceModelChoicesRequest: MessageFns<ListInferenceModelChoicesRequest>;
export declare const ListInferenceModelChoicesResponse: MessageFns<ListInferenceModelChoicesResponse>;
type Builtin = Date | Function | Uint8Array | string | number | boolean | bigint | undefined;
type DeepPartial<T> = T extends bigint ? string | number | bigint : T extends Builtin ? T : T extends globalThis.Array<infer U> ? globalThis.Array<DeepPartial<U>> : T extends ReadonlyArray<infer U> ? ReadonlyArray<DeepPartial<U>> : T extends {} ? {
    [K in keyof T]?: DeepPartial<T[K]>;
} : Partial<T>;
type KeysOfUnion<T> = T extends T ? keyof T : never;
type Exact<P, I extends P> = P extends Builtin ? P : P & {
    [K in keyof P]: Exact<P[K], I[K]>;
} & {
    [K in Exclude<keyof I, KeysOfUnion<P>>]: never;
};
interface MessageFns<T> {
    encode(message: T, writer?: BinaryWriter): BinaryWriter;
    decode(input: BinaryReader | Uint8Array, length?: number): T;
    fromJSON(object: any): T;
    toJSON(message: T): unknown;
    create<I extends Exact<DeepPartial<T>, I>>(base?: I): T;
    fromPartial<I extends Exact<DeepPartial<T>, I>>(object: I): T;
}
export {};
//# sourceMappingURL=inference_routing.d.ts.map