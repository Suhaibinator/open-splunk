import { BinaryReader, BinaryWriter } from "@bufbuild/protobuf/wire";
/**
 * InferenceAPI selects the wire shape independently of the destination provider.
 * UNSPECIFIED selects the provider's configured default. Explicit selections may
 * use any wire or native API supported by the configured provider.
 */
export declare enum InferenceAPI {
    INFERENCE_API_UNSPECIFIED = 0,
    INFERENCE_API_CHAT_COMPLETIONS = 1,
    INFERENCE_API_ANTHROPIC_MESSAGES = 2,
    INFERENCE_API_RESPONSES = 3,
    INFERENCE_API_GOOGLE_NATIVE = 4,
    INFERENCE_API_AZURE_NATIVE = 5,
    UNRECOGNIZED = -1
}
export declare function inferenceAPIFromJSON(object: any): InferenceAPI;
export declare function inferenceAPIToJSON(object: InferenceAPI): string;
/**
 * InferenceHTTPAuth selects how an HTTP inference provider presents its
 * credential. UNSPECIFIED uses X-API-Key for Anthropic Messages and bearer for
 * other HTTP APIs; API_KEY uses the configured auth header (default X-API-Key);
 * NONE sends no credential.
 */
export declare enum InferenceHTTPAuth {
    INFERENCE_HTTP_AUTH_UNSPECIFIED = 0,
    INFERENCE_HTTP_AUTH_BEARER = 1,
    INFERENCE_HTTP_AUTH_API_KEY = 2,
    INFERENCE_HTTP_AUTH_NONE = 3,
    UNRECOGNIZED = -1
}
export declare function inferenceHTTPAuthFromJSON(object: any): InferenceHTTPAuth;
export declare function inferenceHTTPAuthToJSON(object: InferenceHTTPAuth): string;
/**
 * InferenceProviderAdapter selects the client family that talks to a provider.
 * UNSPECIFIED is invalid configuration.
 */
export declare enum InferenceProviderAdapter {
    INFERENCE_PROVIDER_ADAPTER_UNSPECIFIED = 0,
    INFERENCE_PROVIDER_ADAPTER_HTTP = 1,
    INFERENCE_PROVIDER_ADAPTER_GOOGLE_GENAI = 2,
    INFERENCE_PROVIDER_ADAPTER_AZURE_FOUNDRY = 3,
    UNRECOGNIZED = -1
}
export declare function inferenceProviderAdapterFromJSON(object: any): InferenceProviderAdapter;
export declare function inferenceProviderAdapterToJSON(object: InferenceProviderAdapter): string;
/**
 * InferenceGoogleBackend selects the Google GenAI service. UNSPECIFIED is
 * invalid configuration.
 */
export declare enum InferenceGoogleBackend {
    INFERENCE_GOOGLE_BACKEND_UNSPECIFIED = 0,
    INFERENCE_GOOGLE_BACKEND_AI_STUDIO = 1,
    INFERENCE_GOOGLE_BACKEND_VERTEX_AI = 2,
    UNRECOGNIZED = -1
}
export declare function inferenceGoogleBackendFromJSON(object: any): InferenceGoogleBackend;
export declare function inferenceGoogleBackendToJSON(object: InferenceGoogleBackend): string;
/**
 * InferenceGoogleAuth selects how a Google GenAI provider authenticates.
 * API_KEY uses the provider's credential binding; APPLICATION_DEFAULT uses
 * Google application-default credentials and requires the Vertex AI backend.
 * UNSPECIFIED is invalid configuration.
 */
export declare enum InferenceGoogleAuth {
    INFERENCE_GOOGLE_AUTH_UNSPECIFIED = 0,
    INFERENCE_GOOGLE_AUTH_API_KEY = 1,
    INFERENCE_GOOGLE_AUTH_APPLICATION_DEFAULT = 2,
    UNRECOGNIZED = -1
}
export declare function inferenceGoogleAuthFromJSON(object: any): InferenceGoogleAuth;
export declare function inferenceGoogleAuthToJSON(object: InferenceGoogleAuth): string;
/**
 * OpenRouterProviderSort orders OpenRouter's upstream providers. UNSPECIFIED
 * omits the field so OpenRouter applies its default routing policy.
 */
export declare enum OpenRouterProviderSort {
    OPEN_ROUTER_PROVIDER_SORT_UNSPECIFIED = 0,
    OPEN_ROUTER_PROVIDER_SORT_PRICE = 1,
    OPEN_ROUTER_PROVIDER_SORT_LATENCY = 2,
    OPEN_ROUTER_PROVIDER_SORT_THROUGHPUT = 3,
    UNRECOGNIZED = -1
}
export declare function openRouterProviderSortFromJSON(object: any): OpenRouterProviderSort;
export declare function openRouterProviderSortToJSON(object: OpenRouterProviderSort): string;
/**
 * OpenRouterDataCollection controls whether OpenRouter may route to providers
 * that store or train on request data. UNSPECIFIED omits the field.
 */
export declare enum OpenRouterDataCollection {
    OPEN_ROUTER_DATA_COLLECTION_UNSPECIFIED = 0,
    OPEN_ROUTER_DATA_COLLECTION_ALLOW = 1,
    OPEN_ROUTER_DATA_COLLECTION_DENY = 2,
    UNRECOGNIZED = -1
}
export declare function openRouterDataCollectionFromJSON(object: any): OpenRouterDataCollection;
export declare function openRouterDataCollectionToJSON(object: OpenRouterDataCollection): string;
/** InferenceModel captures one DB-backed inference model catalog row. */
export interface InferenceModel {
    id: bigint;
    providerId: string;
    providerModelId: string;
    displayName: string;
    active: boolean;
}
export declare const InferenceModel: MessageFns<InferenceModel>;
type Builtin = Date | Function | Uint8Array | string | number | boolean | bigint | undefined;
type DeepPartial<T> = T extends bigint ? string | number | bigint : T extends Builtin ? T : T extends globalThis.Array<infer U> ? globalThis.Array<DeepPartial<U>> : T extends ReadonlyArray<infer U> ? ReadonlyArray<DeepPartial<U>> : T extends {} ? {
    [K in keyof T]?: DeepPartial<T[K]>;
} : Partial<T>;
type KeysOfUnion<T> = T extends T ? keyof T : never;
type Exact<P, I extends P> = P extends Builtin ? P : P & {
    [K in keyof P]: Exact<P[K], I[K]>;
} & {
    [K in Exclude<keyof I, KeysOfUnion<P>>]: never;
};
interface MessageFns<T> {
    encode(message: T, writer?: BinaryWriter): BinaryWriter;
    decode(input: BinaryReader | Uint8Array, length?: number): T;
    fromJSON(object: any): T;
    toJSON(message: T): unknown;
    create<I extends Exact<DeepPartial<T>, I>>(base?: I): T;
    fromPartial<I extends Exact<DeepPartial<T>, I>>(object: I): T;
}
export {};
//# sourceMappingURL=inference.d.ts.map