export * as v1 from "./index.go_common.v1";
//# sourceMappingURL=index.go_common.d.ts.map