import { BinaryReader, BinaryWriter } from "@bufbuild/protobuf/wire";
import { Language } from "./language";
import { PaginationRequest, PaginationResponse } from "./pagination";
import { PublicUser, User, UserSettings } from "./user";
/** Scope for user search requests. */
export declare enum UserSearchScope {
    USER_SEARCH_SCOPE_UNSPECIFIED = 0,
    USER_SEARCH_SCOPE_GLOBAL = 1,
    USER_SEARCH_SCOPE_ORGANIZATION = 2,
    UNRECOGNIZED = -1
}
export declare function userSearchScopeFromJSON(object: any): UserSearchScope;
export declare function userSearchScopeToJSON(object: UserSearchScope): string;
/** Request message for creating a profile picture upload URL */
export interface CreateProfilePictureUploadURLRequest {
    /** Filename of the image to upload */
    filename: string;
    /** Optional content type (MIME type) of the image */
    contentType?: string | undefined;
}
/** Response message for profile picture upload URL creation */
export interface CreateProfilePictureUploadURLResponse {
    /** Presigned URL for uploading the file to MinIO */
    uploadUrl: string;
    /** Form data fields required for the upload */
    formData: {
        [key: string]: string;
    };
    /** The attachment ID for tracking */
    attachmentId: bigint;
    /** When the upload URL expires */
    expiry?: Date | undefined;
}
export interface CreateProfilePictureUploadURLResponse_FormDataEntry {
    key: string;
    value: string;
}
/** Request message for removing profile picture */
export interface RemoveProfilePictureRequest {
}
/** Response message for profile picture removal */
export interface RemoveProfilePictureResponse {
}
/**
 * Request message for partially updating user settings.
 * Only fields that are present are applied; absent (unset) fields leave the
 * stored value unchanged. This avoids a read-modify-write round-trip on the
 * client and the lost-update race between concurrent partial updates.
 */
export interface UpdateUserSettingsRequest {
    /** Whether dark mode is enabled */
    darkMode?: boolean | undefined;
    /** Preferred language */
    language?: Language | undefined;
    /** Whether email notifications are enabled */
    emailNotifications?: boolean | undefined;
    /** Whether push notifications are enabled */
    pushNotifications?: boolean | undefined;
    /** Whether marketing emails are enabled */
    marketingEmails?: boolean | undefined;
    /** Email for new chats */
    chatEmailNotifications?: boolean | undefined;
    /** Push for new chats */
    chatPushNotifications?: boolean | undefined;
}
/** Request message for updating user language preference */
export interface UpdateLanguagePreferenceRequest {
    /** The new language preference */
    language: Language;
}
/** Response message for language preference update */
export interface UpdateLanguagePreferenceResponse {
    /** The updated user settings (includes the new language preference) */
    userSettings?: UserSettings | undefined;
}
/** Request message for removing user phone number (secure operation) */
export interface RemovePhoneNumberRequest {
}
/** Response message for phone number removal */
export interface RemovePhoneNumberResponse {
    /** The updated user without phone number */
    user?: User | undefined;
}
/** Request message for updating user username (secure operation) */
export interface UpdateUsernameRequest {
    /** The new username to set */
    username: string;
}
/** Response message for username update */
export interface UpdateUsernameResponse {
    /** The updated user with new username */
    user?: User | undefined;
}
/** Request to search for public users. */
export interface SearchPublicUsersRequest {
    pagination?: PaginationRequest | undefined;
    query: string;
    scope: UserSearchScope;
    organizationId?: bigint | undefined;
    /** If true and query is empty, return suggestions. */
    suggestionsOnly: boolean;
    /** If true, exclude the caller from results. */
    excludeSelf: boolean;
}
/** Response for public user search. */
export interface SearchPublicUsersResponse {
    users: PublicUser[];
    pagination?: PaginationResponse | undefined;
}
export declare const CreateProfilePictureUploadURLRequest: MessageFns<CreateProfilePictureUploadURLRequest>;
export declare const CreateProfilePictureUploadURLResponse: MessageFns<CreateProfilePictureUploadURLResponse>;
export declare const CreateProfilePictureUploadURLResponse_FormDataEntry: MessageFns<CreateProfilePictureUploadURLResponse_FormDataEntry>;
export declare const RemoveProfilePictureRequest: MessageFns<RemoveProfilePictureRequest>;
export declare const RemoveProfilePictureResponse: MessageFns<RemoveProfilePictureResponse>;
export declare const UpdateUserSettingsRequest: MessageFns<UpdateUserSettingsRequest>;
export declare const UpdateLanguagePreferenceRequest: MessageFns<UpdateLanguagePreferenceRequest>;
export declare const UpdateLanguagePreferenceResponse: MessageFns<UpdateLanguagePreferenceResponse>;
export declare const RemovePhoneNumberRequest: MessageFns<RemovePhoneNumberRequest>;
export declare const RemovePhoneNumberResponse: MessageFns<RemovePhoneNumberResponse>;
export declare const UpdateUsernameRequest: MessageFns<UpdateUsernameRequest>;
export declare const UpdateUsernameResponse: MessageFns<UpdateUsernameResponse>;
export declare const SearchPublicUsersRequest: MessageFns<SearchPublicUsersRequest>;
export declare const SearchPublicUsersResponse: MessageFns<SearchPublicUsersResponse>;
type Builtin = Date | Function | Uint8Array | string | number | boolean | bigint | undefined;
type DeepPartial<T> = T extends bigint ? string | number | bigint : T extends Builtin ? T : T extends globalThis.Array<infer U> ? globalThis.Array<DeepPartial<U>> : T extends ReadonlyArray<infer U> ? ReadonlyArray<DeepPartial<U>> : T extends {} ? {
    [K in keyof T]?: DeepPartial<T[K]>;
} : Partial<T>;
type KeysOfUnion<T> = T extends T ? keyof T : never;
type Exact<P, I extends P> = P extends Builtin ? P : P & {
    [K in keyof P]: Exact<P[K], I[K]>;
} & {
    [K in Exclude<keyof I, KeysOfUnion<P>>]: never;
};
interface MessageFns<T> {
    encode(message: T, writer?: BinaryWriter): BinaryWriter;
    decode(input: BinaryReader | Uint8Array, length?: number): T;
    fromJSON(object: any): T;
    toJSON(message: T): unknown;
    create<I extends Exact<DeepPartial<T>, I>>(base?: I): T;
    fromPartial<I extends Exact<DeepPartial<T>, I>>(object: I): T;
}
export {};
//# sourceMappingURL=user_api.d.ts.map